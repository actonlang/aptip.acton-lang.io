// Acton Base System Builder
// Performs the final build of the Acton base system by compiling the generated C code.

const std = @import("std");
const print = @import("std").debug.print;
const ArrayList = std.ArrayList;

pub const FilePath = struct {
    filename: []const u8,
    full_path: []const u8,
    dir: []const u8,
    file_path: []const u8,
};

// We have an absolute path we want to get to, but we have to provide it as a
// relative path from the current position. The easiest way to do this is to go
// up the directory tree until we're at the root, and then the absolute path is
// relative to the root and can be used. It would be more elegant to figure out
// if there are actual commonalities between the paths and only traverse
// upwards as far as necessary.

fn joinPath(allocator: std.mem.Allocator, base: []const u8, relative: []const u8) []const u8 {
    const path = allocator.alloc(u8, base.len + relative.len + 1) catch @panic("OOM");
    _ = std.fmt.bufPrint(path, "{s}/{s}", .{base, relative}) catch @panic("Error joining paths");
    return path;
}

pub fn build(b: *std.Build) void {
    const buildroot_path = b.build_root.handle.realpathAlloc(b.allocator, ".") catch unreachable;
    const optimize = b.standardOptimizeOption(.{});
    const target = b.standardTargetOptions(.{});
    const cpedantic = b.option(bool, "cpedantic", "") orelse false;
    const use_db = b.option(bool, "db", "") orelse false;
    const no_threads = b.option(bool, "no_threads", "") orelse false;

    const projpath_outtypes = joinPath(b.allocator, buildroot_path, "out/types");

    print("Acton Base Builder\nBuilding in {s}\n", .{buildroot_path});

    const dep_libbsdnt = b.dependency("libbsdnt", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libgc = b.dependency("libgc", .{
        .target = target,
        .optimize = optimize,
        .BUILD_SHARED_LIBS = false,
        .enable_large_config = true,
        .enable_mmap = true,
    });

    const dep_libmbedtls = b.dependency("libmbedtls", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libnetstring = b.dependency("libnetstring", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libpcre2 = b.dependency("libpcre2", .{
        .target = target,
        .optimize = optimize,
        .linkage = .static,
    });

    const dep_libsnappy_c = b.dependency("libsnappy", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libtlsuv = b.dependency("libtlsuv", .{
        .target = target,
        .optimize = optimize,
        .http = false,
        .keychain = false,
    });

    const dep_libprotobuf_c = b.dependency("libprotobuf_c", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libutf8proc = b.dependency("libutf8proc", .{
        .target = target,
        .optimize = optimize,
        .BUILD_SHARED_LIBS = false,
    });

    const dep_libuv = b.dependency("libuv", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libxml2 = b.dependency("libxml2", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libyyjson = b.dependency("libyyjson", .{
        .target = target,
        .optimize = optimize,
    });

    var iter_dir = b.build_root.handle.openDir(
        "out/types/",
        .{
            .iterate = true
        },
    ) catch |err| {
        std.log.err("Error opening iterable dir: {}", .{err});
        std.posix.exit(1);
    };

    var c_files = ArrayList([]const u8).empty;
    var root_c_files = ArrayList(*FilePath).empty;
    defer c_files.deinit(b.allocator);
    defer root_c_files.deinit(b.allocator);
    var walker = iter_dir.walk(b.allocator) catch |err| {
        std.log.err("Error walking dir: {}", .{err});
        std.posix.exit(1);
    };
    defer walker.deinit();

    // Find all .c files
    while (true) {
        const next_result = walker.next() catch |err| {
            std.log.err("Error getting next: {}", .{err});
            std.posix.exit(1);
        };
        if (next_result) |entry| {
            if (entry.kind == .file) {
                if (std.mem.endsWith(u8, entry.basename, ".c")) {
                    const fPath = b.allocator.create(FilePath) catch |err| {
                        std.log.err("Error allocating FilePath entry: {}", .{err});
                        std.posix.exit(1);
                    };
                    const full_path = entry.dir.realpathAlloc(b.allocator, entry.basename) catch |err| {
                        std.log.err("Error getting dir name: {}", .{err});
                        std.posix.exit(1);
                    };
                    const dir = entry.dir.realpathAlloc(b.allocator, ".") catch |err| {
                        std.log.err("Error getting dir name: {}", .{err});
                        std.posix.exit(1);
                    };
                    fPath.full_path = full_path;
                    fPath.dir = dir;
                    fPath.filename = b.allocator.dupe(u8, entry.basename) catch |err| {
                        std.log.err("Error allocating filename entry: {}", .{err});
                        std.posix.exit(1);
                    };
                    const file_path = b.allocator.alloc(u8, full_path.len - projpath_outtypes.len) catch |err| {
                        std.log.err("Error allocating file_path entry: {}", .{err});
                        std.posix.exit(1);
                    };
                    @memcpy(file_path, full_path[projpath_outtypes.len..]);
                    fPath.file_path = file_path;

                    print("-- filename : {s}\n", .{fPath.filename});
                    print("   full_path: {s}\n", .{fPath.full_path});
                    print("   dir      : {s}\n", .{fPath.dir});
                    print("   file_path: {s}\n", .{fPath.file_path});

                    if (std.mem.endsWith(u8, entry.basename, ".root.c")) {
                        root_c_files.append(b.allocator, fPath) catch |err| {
                            std.log.err("Error appending to root .c files: {}", .{err});
                            std.posix.exit(1);
                        };
                    } else {
                        // Store relative path from build root, not absolute path
                        const rel_path = b.allocator.alloc(u8, 9 + fPath.file_path.len) catch |err| {
                            std.log.err("Error allocating relative path: {}", .{err});
                            std.posix.exit(1);
                        };
                        @memcpy(rel_path[0..9], "out/types");
                        @memcpy(rel_path[9..], fPath.file_path);
                        c_files.append(b.allocator, rel_path) catch |err| {
                            std.log.err("Error appending to .c files: {}", .{err});
                            std.posix.exit(1);
                        };
                    }
                }
            }
        } else {
            break;
        }
    }

    var flags = std.ArrayList([]const u8).empty;
    defer flags.deinit(b.allocator);
    flags.append(b.allocator, "-DUTF8PROC_STATIC") catch unreachable;

    var file_prefix_map = std.ArrayList(u8).empty;
    defer file_prefix_map.deinit(b.allocator);
    const file_prefix_path = b.build_root.handle.openDir("..", .{}) catch unreachable;
    const file_prefix_path_path = file_prefix_path.realpathAlloc(b.allocator, ".") catch unreachable;
    file_prefix_map.appendSlice(b.allocator, "-ffile-prefix-map=") catch unreachable;
    file_prefix_map.appendSlice(b.allocator, file_prefix_path_path) catch unreachable;
    file_prefix_map.appendSlice(b.allocator, "/=") catch unreachable;
    flags.append(b.allocator, file_prefix_map.items) catch unreachable;
    flags.append(b.allocator, "-Wno-error=parentheses-equality") catch unreachable;
    flags.append(b.allocator, "-Wno-parentheses-equality") catch unreachable;
    if (cpedantic) {
        flags.append(b.allocator, "-Werror") catch unreachable;
    }

    if (optimize == .Debug) {
        print("Debug build\n", .{});
        flags.appendSlice(b.allocator, &.{
            "-DDEV",
        }) catch |err| {
            std.log.err("Error appending flags: {}", .{err});
            std.posix.exit(1);
        };
    }

    if (use_db) {
        print("Building with DB backend support\n", .{});
        flags.append(b.allocator, "-DACTON_DB") catch unreachable;
    }

    if (no_threads) {
        print("No threads\n", .{});
    } else {
        print("Threads enabled\n", .{});
        flags.appendSlice(b.allocator, &.{
            "-DACTON_THREADS",
        }) catch |err| {
            std.log.err("Error appending flags: {}", .{err});
            std.posix.exit(1);
        };
    }

    flags.appendSlice(b.allocator, &.{
        "-fno-sanitize=signed-integer-overflow",
    }) catch unreachable;

    const libActon = b.addLibrary(.{
        .name = "Acton",
        .linkage = .static,
        .root_module = b.createModule(.{
            .root_source_file = b.path("__root.zig"),
            .target = target,
            .optimize = optimize,
        }),
    });
    for (c_files.items) |entry| {
        libActon.addCSourceFile(.{ .file = b.path(entry), .flags = flags.items });
    }
    libActon.installHeadersDirectory(b.path("builtin"), "builtin", .{});

    // TODO: We should install out/types/*.h with installHeadersDirectory, but
    // it's not working, we get cache issue where out-of-date files are being
    // used. It works the first time but changes to the headers are often not
    // picked up. Iterating and installing each file separately seems to work.
    // Rather surprisingly, I don't see the same issue with the header files
    // from builtin above, but if errors were to occur, we could do the same
    // for those files as well. Obviously, this is not ideal and we should
    // investigate further, find the root cause and address it.
    libActon.installHeadersDirectory(b.path("out/types"), "out/types", .{});

    var hiter_dir = b.build_root.handle.openDir("out/types/", .{ .iterate = true }) catch unreachable;
    var hwalker = hiter_dir.walk(b.allocator) catch unreachable;
    defer hwalker.deinit();

    // Find all .h files
    while (true) {
        const next_result = hwalker.next() catch unreachable;
        if (next_result) |entry| {
            if (entry.kind == .file) {
                if (std.mem.endsWith(u8, entry.basename, ".h")) {
                    const full_path = entry.dir.realpathAlloc(b.allocator, entry.basename) catch unreachable;
                    const file_path = b.allocator.alloc(u8, full_path.len - buildroot_path.len - 1) catch unreachable;
                    @memcpy(file_path, full_path[buildroot_path.len+1..]);
                    libActon.installHeader(b.path(file_path), file_path);
                }
            }
        } else {
            break;
        }
    }


    libActon.installHeader(b.path("rts/common.h"), "rts/common.h");
    libActon.installHeader(b.path("rts/q.h"), "rts/q.h");
    libActon.installHeader(b.path("rts/rts.h"), "rts/rts.h");
    libActon.installHeader(b.path("rts/log.h"), "rts/log.h");

    libActon.addIncludePath(.{ .cwd_relative = buildroot_path });
    libActon.addIncludePath(dep_libtlsuv.path("include"));

    if (use_db) {
        const libactondb_dep = b.dependency("actondb", .{
            .target = target,
            .optimize = optimize,
        });
        libActon.linkLibrary(libactondb_dep.artifact("ActonDB"));
    }

    libActon.linkLibrary(dep_libbsdnt.artifact("bsdnt"));
    libActon.linkLibrary(dep_libgc.artifact("gc"));
    libActon.linkLibrary(dep_libmbedtls.artifact("mbedcrypto"));
    libActon.linkLibrary(dep_libmbedtls.artifact("mbedtls"));
    libActon.linkLibrary(dep_libmbedtls.artifact("mbedx509"));
    libActon.linkLibrary(dep_libnetstring.artifact("netstring"));
    libActon.linkLibrary(dep_libpcre2.artifact("pcre2-8"));
    libActon.linkLibrary(dep_libprotobuf_c.artifact("protobuf-c")); // TODO: remove, once telemetrify/prw is fixed
    libActon.linkLibrary(dep_libsnappy_c.artifact("snappy-c"));
    libActon.linkLibrary(dep_libtlsuv.artifact("tlsuv"));
    libActon.linkLibrary(dep_libutf8proc.artifact("utf8proc"));
    libActon.linkLibrary(dep_libuv.artifact("uv"));
    libActon.linkLibrary(dep_libxml2.artifact("xml2"));
    libActon.linkLibrary(dep_libyyjson.artifact("yyjson"));

    libActon.installLibraryHeaders(dep_libbsdnt.artifact("bsdnt"));
    libActon.installLibraryHeaders(dep_libgc.artifact("gc"));
    libActon.installLibraryHeaders(dep_libprotobuf_c.artifact("protobuf-c")); // TODO: remove, once telemetrify/prw is fixed
    libActon.installLibraryHeaders(dep_libuv.artifact("uv"));

    libActon.linkLibC();
    libActon.linkLibCpp();
    b.installArtifact(libActon);

    const base_tests = b.addTest(.{
        .root_module = b.createModule(.{
            .root_source_file = b.path("acton.zig"),
            .target = target,
            .optimize = optimize,
        }),
    });
    base_tests.addIncludePath(.{ .cwd_relative = buildroot_path });
    base_tests.linkLibrary(dep_libbsdnt.artifact("bsdnt"));
    base_tests.linkLibrary(dep_libgc.artifact("gc"));
    base_tests.linkLibC();
    const run_base_tests = b.addRunArtifact(base_tests);
    const test_step = b.step("test", "Run tests");
    test_step.dependOn(&run_base_tests.step);
}
