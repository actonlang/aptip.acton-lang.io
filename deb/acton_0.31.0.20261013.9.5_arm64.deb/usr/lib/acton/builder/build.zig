// Acton Project Builder
// Performs the final build of the project by compiling the generated C code.

const std = @import("std");
const print = @import("std").debug.print;
const ArrayList = std.ArrayList;

pub const FilePath = struct {
    filename: []const u8,
    full_path: []const u8,
    dir: []const u8,
    file_path: []const u8,
    test_root: bool
};

// We have an absolute path we want to get to, but we have to provide it as a
// relative path from the current position. The easiest way to do this is to go
// up the directory tree until we're at the root, and then the absolute path is
// relative to the root and can be used. It would be more elegant to figure out
// if there are actual commonalities between the paths and only traverse
// upwards as far as necessary.
fn relJoinPath(allocator: std.mem.Allocator, dots: []const u8, base: []const u8, relative: []const u8) []const u8 {
    const path = allocator.alloc(u8, dots.len + base.len + relative.len + 1) catch @panic("OOM");
    _ = std.fmt.bufPrint(path, "{s}{s}/{s}", .{dots, base, relative}) catch @panic("Error joining paths");
    return path;
}

fn joinPath(allocator: std.mem.Allocator, base: []const u8, relative: []const u8) []const u8 {
    const path = allocator.alloc(u8, base.len + relative.len + 1) catch @panic("OOM");
    _ = std.fmt.bufPrint(path, "{s}/{s}", .{base, relative}) catch @panic("Error joining paths");
    return path;
}

fn selectedSourceExists(b: *std.Build, project_dir: std.Io.Dir, project_path: std.Build.LazyPath, source: []const u8) !bool {
    const io = b.graph.io;
    project_dir.access(io, source, .{}) catch |err| switch (err) {
        error.FileNotFound => {
            // Configure dependencies must exist. Track the nearest existing
            // parent so creating the source or its directories invalidates it.
            var parent = std.fs.path.dirname(source) orelse ".";
            while (true) {
                if (project_dir.openDir(io, parent, .{})) |dir| {
                    dir.close(io);
                    b.dependOnDirectoryContents(project_path.path(b, parent));
                    return false;
                } else |parent_err| switch (parent_err) {
                    error.FileNotFound, error.NotDir => {
                        const next_parent = std.fs.path.dirname(parent) orelse ".";
                        if (std.mem.eql(u8, parent, next_parent)) return parent_err;
                        parent = next_parent;
                    },
                    else => return parent_err,
                }
            }
        },
        else => return err,
    };
    b.dependOnFileContents(project_path.path(b, source));
    return true;
}

pub fn build(b: *std.Build) void {
    const io = b.graph.io;
    // Normalize the serialized package root so C inputs and prefix maps agree.
    if (b.root.root_dir.path) |path| {
        b.root.root_dir.path = b.pathResolve(&.{path});
    }
    // Acton generates this file into <project>/out/zig, so the project root,
    // which holds the generated C sources under out/types, is two levels up
    // from the build root. Resolve it lexically so the paths we hand to the C
    // compiler carry no out/zig/../.. segments; -ffile-prefix-map below only
    // matches the normalized form.
    const buildroot_path = b.root.joinString(b.allocator, "") catch unreachable;
    const project_root = b.pathResolve(&.{ buildroot_path, "..", ".." });
    const project_path = b.graph.cwdRelativePath(project_root);
    const project_dir = std.Io.Dir.cwd().openDir(io, project_root, .{}) catch |err| {
        std.log.err("Error opening project root {s}: {}", .{ project_root, err });
        std.process.exit(1);
    };
    defer project_dir.close(io);
    const optimize = b.standardOptimizeOption(.{});
    const target = b.standardTargetOptions(.{});
    // LTO = ThinLTO, set in all packages explicitly
    const enable_lto = optimize != .debug and target.result.os.tag != .macos;
    const db = b.option(bool, "db", "") orelse false;
    const no_threads = b.option(bool, "no_threads", "") orelse false;
    const malloc = b.option(enum { libc, mimalloc }, "malloc", "Allocator for C malloc/free: libc, mimalloc") orelse .libc;
    const gc_use_mark_bits = b.option(bool, "gc_use_mark_bits", "Use packed GC mark bits") orelse false;
    const gc_mark_bit_per_object = b.option(bool, "gc_mark_bit_per_object", "Track GC marks per object") orelse false;
    const gc_dirty_tracking_backend = b.option([]const u8, "gc_dirty_tracking_backend", "GC dirty tracking backend: auto, soft_dirty, userfaultfd") orelse "auto";
    const gc_page_hash_table_log2 = b.option(u8, "gc_page_hash_table_log2", "Log2 of GC page-hash entries (0 keeps the default)") orelse 0;
    const gc_heap_growth_divisor = b.option(u32, "gc_heap_growth_divisor", "Limit automatic GC heap growth to the heap size divided by this (default 4; 0 keeps the fixed increment)") orelse 4;
    const gc_alloc_budget_percent = b.option(u32, "gc_alloc_budget_percent", "Collect after allocating this percentage of the live data (default 67; 0 selects the free space divisor policy)") orelse 67;
    const gc_block_size = b.option(u32, "gc_block_size", "GC heap block size in bytes: a power of two from 4096 to 65536 (0 keeps the default)") orelse 0;
    const gc_mark_range_stealing = b.option(bool, "gc_mark_range_stealing", "Let parallel GC markers claim ranges of the global mark stack (default: true on targets with threads)") orelse !target.result.cpu.arch.isWasm();
    const gc_initial_mark_stack_size = b.option(u32, "gc_initial_mark_stack_size", "Initial number of GC mark stack entries: a power of two, 4096 at least (default: 1048576; 0 keeps the collector's default of as many entries as a heap block has bytes)") orelse 1048576;
    const gc_no_end_padding = b.option(bool, "gc_no_end_padding", "Do not pad GC objects by a byte to keep them alive through pointers just past their end") orelse false;
    const gc_thread_local_size_limit = b.option(u32, "gc_thread_local_size_limit", "Largest GC object size in bytes served from thread-local free lists: a multiple of 16 up to half the block size (0 keeps the default)") orelse 0;
    const gc_realloc_no_free = b.option(bool, "gc_realloc_no_free", "Leave a small collectable object moved by GC_realloc to the collector instead of freeing it (default: true)") orelse true;
    const gc_no_thread_local_warmup = b.option(bool, "gc_no_thread_local_warmup", "Let a new thread use its own GC free list of each size from its first allocation of that size (default: true on targets with threads)") orelse !target.result.cpu.arch.isWasm();
    const gc_disable_thp = b.option(bool, "gc_disable_thp", "Disable transparent huge pages for GC memory on Linux") orelse false;
    const acton_libraries = b.option([]const u8, "acton_libraries", "") orelse "";
    const acton_modules = b.option([]const u8, "acton_modules", "") orelse {
        std.log.err("Missing required build option -Dacton_modules=...", .{});
        std.process.exit(1);
    };
    const acton_root_stubs = b.option([]const u8, "acton_root_stubs", "") orelse {
        std.log.err("Missing required build option -Dacton_root_stubs=...", .{});
        std.process.exit(1);
    };
    // Zig caches the configuration made here keyed on the -D options and on
    // input paths relative to the build root, not on where the build root is.
    // The configuration holds absolute paths into the project though, so
    // acton passes the project root to give each project directory a cache
    // entry of its own.
    _ = b.option([]const u8, "acton_project_root", "Absolute project root, only keys the configure cache");

    print("Acton Project Builder - building {s}\n", .{project_root});

    const actonbase_dep = b.dependency("base", .{
        .target = target,
        .optimize = optimize,
        .no_threads = no_threads,
        .db = db,
        .gc_use_mark_bits = gc_use_mark_bits,
        .gc_mark_bit_per_object = gc_mark_bit_per_object,
        .gc_dirty_tracking_backend = gc_dirty_tracking_backend,
        .gc_page_hash_table_log2 = gc_page_hash_table_log2,
        .gc_heap_growth_divisor = gc_heap_growth_divisor,
        .gc_alloc_budget_percent = gc_alloc_budget_percent,
        .gc_block_size = gc_block_size,
        .gc_mark_range_stealing = gc_mark_range_stealing,
        .gc_initial_mark_stack_size = gc_initial_mark_stack_size,
        .gc_no_end_padding = gc_no_end_padding,
        .gc_thread_local_size_limit = gc_thread_local_size_limit,
        .gc_realloc_no_free = gc_realloc_no_free,
        .gc_no_thread_local_warmup = gc_no_thread_local_warmup,
        .gc_disable_thp = gc_disable_thp,
    });

    // Dependencies from Build.act

    const mimalloc = if (malloc == .mimalloc) actonbase_dep.builder.dependency("mimalloc", .{
        .target = target,
        .optimize = optimize,
    }).artifact("mimalloc") else null;

    var c_files = ArrayList([]const u8).empty;
    var root_c_files = ArrayList(*FilePath).empty;
    defer c_files.deinit(b.allocator);
    defer root_c_files.deinit(b.allocator);

    var item_it = std.mem.splitScalar(u8, acton_modules, ',');
    while (item_it.next()) |raw_item| {
        const item = std.mem.trim(u8, raw_item, " \t\r");
        if (item.len == 0) continue;
        if (!std.mem.endsWith(u8, item, ".c")) continue;
        if (std.mem.endsWith(u8, item, ".root.c")) continue;
        if (std.mem.endsWith(u8, item, ".test_root.c")) continue;
        const exists = selectedSourceExists(b, project_dir, project_path, item) catch |err| {
            std.log.err("Error checking selected C source ({s}): {}", .{ item, err });
            std.process.exit(1);
        };
        if (!exists) {
            std.log.warn("Skipping missing selected C source: {s}", .{item});
            continue;
        }
        const rel = b.allocator.dupe(u8, item) catch |err| {
            std.log.err("Error allocating selected C source path: {}", .{err});
            std.process.exit(1);
        };
        c_files.append(b.allocator, rel) catch |err| {
            std.log.err("Error appending selected C source path: {}", .{err});
            std.process.exit(1);
        };
    }

    var root_it = std.mem.splitScalar(u8, acton_root_stubs, ',');
    while (root_it.next()) |raw_item| {
        const item = std.mem.trim(u8, raw_item, " \t\r");
        if (item.len == 0) continue;
        const is_test_root = std.mem.endsWith(u8, item, ".test_root.c");
        const is_root = std.mem.endsWith(u8, item, ".root.c");
        if (!is_root and !is_test_root) continue;
        if (!std.mem.startsWith(u8, item, "out/types/")) {
            std.log.err("Invalid root stub path (expected under out/types): {s}", .{item});
            std.process.exit(1);
        }
        const exists = selectedSourceExists(b, project_dir, project_path, item) catch |err| {
            std.log.err("Error checking selected root stub ({s}): {}", .{ item, err });
            std.process.exit(1);
        };
        if (!exists) {
            std.log.warn("Skipping missing selected root stub: {s}", .{item});
            continue;
        }
        const fPath = b.allocator.create(FilePath) catch |err| {
            std.log.err("Error allocating root FilePath entry: {}", .{err});
            std.process.exit(1);
        };
        fPath.full_path = joinPath(b.allocator, project_root, item);
        const item_dir = std.fs.path.dirname(item) orelse ".";
        fPath.dir = joinPath(b.allocator, project_root, item_dir);
        fPath.filename = b.allocator.dupe(u8, std.fs.path.basename(item)) catch |err| {
            std.log.err("Error allocating root filename entry: {}", .{err});
            std.process.exit(1);
        };
        fPath.file_path = b.allocator.dupe(u8, item["out/types".len..]) catch |err| {
            std.log.err("Error allocating root file_path entry: {}", .{err});
            std.process.exit(1);
        };
        fPath.test_root = is_test_root;
        root_c_files.append(b.allocator, fPath) catch |err| {
            std.log.err("Error appending selected root stub: {}", .{err});
            std.process.exit(1);
        };
    }

    if (c_files.items.len == 0) {
        b.graph.poisonCache();
        const dummy_rel = "out/types/acton_empty.c";
        const dummy_abs = joinPath(b.allocator, project_root, dummy_rel);
        project_dir.createDirPath(io, "out/types") catch |err| {
            std.log.err("Error creating out/types directory: {}", .{err});
            std.process.exit(1);
        };
        const dummy_file = project_dir.createFile(io, dummy_rel, .{}) catch |err| {
            std.log.err("Error creating dummy C file: {}", .{err});
            std.process.exit(1);
        };
        var write_buffer: [64]u8 = undefined;
        var dummy_writer = dummy_file.writer(io, &write_buffer);
        dummy_writer.interface.writeAll("int acton_empty(void) { return 0; }\n") catch |err| switch (err) {
            error.WriteFailed => {
                std.log.err("Error writing dummy C file: {}", .{dummy_writer.err.?});
                std.process.exit(1);
            },
        };
        dummy_writer.flush() catch |err| {
            std.log.err("Error flushing dummy C file: {}", .{err});
            std.process.exit(1);
        };
        dummy_file.close(io);
        c_files.append(b.allocator, dummy_rel) catch |err| {
            std.log.err("Error appending dummy C file path: {}", .{err});
            std.process.exit(1);
        };
        std.log.info("No generated C sources; added dummy {s}", .{dummy_abs});
    }

    const libActonProject = b.addLibrary(.{
        .name = "ActonProject",
        .linkage = .static,
        .root_module = b.createModule(.{
            .target = target,
            .optimize = optimize,
        }),
    });
    if (enable_lto) libActonProject.lto = .thin;
    var flags = std.ArrayList([]const u8).empty;
    defer flags.deinit(b.allocator);

    var file_prefix_map = std.ArrayList(u8).empty;
    defer file_prefix_map.deinit(b.allocator);
    const file_prefix_path_path = std.fs.path.dirname(project_root) orelse project_root;
    file_prefix_map.appendSlice(b.allocator, "-ffile-prefix-map=") catch unreachable;
    file_prefix_map.appendSlice(b.allocator, file_prefix_path_path) catch unreachable;
    file_prefix_map.appendSlice(b.allocator, "/=") catch unreachable;
    flags.append(b.allocator, file_prefix_map.items) catch unreachable;

    if (optimize == .debug) {
        print("Debug build\n", .{});
        flags.appendSlice(b.allocator, &.{
            "-DDEV",
        }) catch |err| {
            std.log.err("Error appending flags: {}", .{err});
            std.process.exit(1);
        };
    }

    if (db)
        flags.appendSlice(b.allocator, &.{"-DACTON_DB",}) catch unreachable;

    if (no_threads) {
        print("No threads\n", .{});
    } else {
        print("Threads enabled\n", .{});
        flags.appendSlice(b.allocator, &.{
            "-DACTON_THREADS",
        }) catch |err| {
            std.log.err("Error appending flags: {}", .{err});
            std.process.exit(1);
        };
    }

    // Acton subtyping shares object layouts across distinct C struct pointers.
    // Keep Clang 22's new error as a warning.
    flags.appendSlice(b.allocator, &.{
        "-fwrapv",
        "-Wno-error=incompatible-pointer-types",
    }) catch unreachable;

    for (c_files.items) |entry| {
        libActonProject.root_module.addCSourceFile(.{ .file = project_path.path(b, entry), .flags = flags.items });
    }

    libActonProject.root_module.addIncludePath(project_path.path(b, "."));

    var explicit_libraries = ArrayList(*std.Build.Step.Compile).empty;
    var explicit_static_libraries = ArrayList(*std.Build.Step.Compile).empty;
    var explicit_dynamic_library_names = ArrayList([]const u8).empty;
    var explicit_dynamic_library_installs = ArrayList(*std.Build.Step).empty;
    var has_dynamic_libraries = false;
    defer explicit_libraries.deinit(b.allocator);
    defer explicit_static_libraries.deinit(b.allocator);
    defer explicit_dynamic_library_names.deinit(b.allocator);
    defer explicit_dynamic_library_installs.deinit(b.allocator);

    var lib_it = std.mem.splitScalar(u8, acton_libraries, '|');
    while (lib_it.next()) |raw_lib| {
        const lib_spec = std.mem.trim(u8, raw_lib, " \t\r");
        if (lib_spec.len == 0) continue;

        var field_it = std.mem.splitScalar(u8, lib_spec, ':');
        const lib_name = std.mem.trim(u8, field_it.next() orelse "", " \t\r");
        const lib_linkage = std.mem.trim(u8, field_it.next() orelse "", " \t\r");
        const lib_sources = std.mem.trim(u8, field_it.next() orelse "", " \t\r");
        if (lib_name.len == 0 or lib_sources.len == 0) continue;

        const lib_dynamic = std.mem.eql(u8, lib_linkage, "dynamic");
        has_dynamic_libraries = has_dynamic_libraries or lib_dynamic;
        const libActonExplicit = b.addLibrary(.{
            .name = lib_name,
            .linkage = if (lib_dynamic) .dynamic else .static,
            .root_module = b.createModule(.{
                .target = target,
                .optimize = optimize,
            }),
        });
        if (enable_lto) libActonExplicit.lto = .thin;
        if (lib_dynamic) {
            libActonExplicit.linker_allow_shlib_undefined = true;
        }

        var source_it = std.mem.splitScalar(u8, lib_sources, ',');
        while (source_it.next()) |raw_source| {
            const source = std.mem.trim(u8, raw_source, " \t\r");
            if (source.len == 0) continue;
            libActonExplicit.root_module.addCSourceFile(.{ .file = project_path.path(b, source), .flags = flags.items });
        }
        libActonExplicit.root_module.addIncludePath(project_path.path(b, "."));
        libActonExplicit.root_module.include_dirs.append(b.allocator, .{ .other_step = actonbase_dep.artifact("Acton") }) catch |err| {
            std.log.err("Error appending base include path for explicit library: {}", .{err});
            std.process.exit(1);
        };
        explicit_libraries.append(b.allocator, libActonExplicit) catch |err| {
            std.log.err("Error appending explicit library: {}", .{err});
            std.process.exit(1);
        };
        if (!lib_dynamic) {
            explicit_static_libraries.append(b.allocator, libActonExplicit) catch |err| {
                std.log.err("Error appending explicit static library: {}", .{err});
                std.process.exit(1);
            };
        }
    }

    // lib: link with dependencies / get headers from Build.act

    libActonProject.root_module.linkLibrary(actonbase_dep.artifact("Acton"));
    libActonProject.root_module.link_libc = true;
    libActonProject.root_module.link_libcpp = true;
    b.installArtifact(libActonProject);

    for (explicit_static_libraries.items) |libActonExplicit| {
        libActonExplicit.root_module.linkLibrary(actonbase_dep.artifact("Acton"));
    }

    for (explicit_libraries.items) |libActonExplicit| {
        libActonExplicit.root_module.link_libc = true;
        libActonExplicit.root_module.link_libcpp = true;
        const install_lib = b.addInstallArtifact(libActonExplicit, .{});
        b.getInstallStep().dependOn(&install_lib.step);
        if (libActonExplicit.linkage == .dynamic) {
            explicit_dynamic_library_names.append(b.allocator, libActonExplicit.name) catch |err| {
                std.log.err("Error appending explicit dynamic library name: {}", .{err});
                std.process.exit(1);
            };
            explicit_dynamic_library_installs.append(b.allocator, &install_lib.step) catch |err| {
                std.log.err("Error appending explicit dynamic library install step: {}", .{err});
                std.process.exit(1);
            };
        }
    }

    // Register the produced header files in out/types using
    // libActonProject.installHeader / .installHeaderDirectory
    // TODO: We should install out/types/*.h with installHeadersDirectory, but
    // it's not working, we get cache issue where out-of-date files are being
    // used. It works the first time but changes to the headers are often not
    // picked up. Iterating and installing each file separately seems to work.
    // Rather surprisingly, I don't see the same issue with the header files
    // from builtin above, but if errors were to occur, we could do the same
    // for those files as well. Obviously, this is not ideal and we should
    // investigate further, find the root cause and address it.
    libActonProject.installHeadersDirectory(project_path.path(b, "out/types"), "out/types", .{});

    b.dependOnDirectoryContents(project_path.path(b, "out/types"));
    var hiter_dir = project_dir.openDir(io, "out/types/", .{ .iterate = true }) catch unreachable;
    var hwalker = hiter_dir.walk(b.allocator) catch unreachable;
    defer hwalker.deinit();

    // Find all .h files
    while (true) {
        const next_result = hwalker.next(io) catch unreachable;
        if (next_result) |entry| {
            if (entry.kind == .directory) {
                const dir_path = std.fs.path.join(b.allocator, &.{ "out/types", entry.path }) catch unreachable;
                b.dependOnDirectoryContents(project_path.path(b, dir_path));
            }
            if (entry.kind == .file) {
                if (std.mem.endsWith(u8, entry.basename, ".h")) {
                    const file_path = std.fs.path.join(b.allocator, &.{ "out/types", entry.path }) catch unreachable;
                    libActonProject.installHeader(project_path.path(b, file_path), file_path);
                }
            }
        } else {
            break;
        }
    }

    if (root_c_files.items.len > 0) {
        const maybe_actondb_dep = if (db) b.dependency("actondb", .{
            .target = target,
            .optimize = optimize,
            .gc_use_mark_bits = gc_use_mark_bits,
            .gc_mark_bit_per_object = gc_mark_bit_per_object,
            .gc_dirty_tracking_backend = gc_dirty_tracking_backend,
            .gc_page_hash_table_log2 = gc_page_hash_table_log2,
            .gc_heap_growth_divisor = gc_heap_growth_divisor,
            .gc_alloc_budget_percent = gc_alloc_budget_percent,
            .gc_block_size = gc_block_size,
            .gc_mark_range_stealing = gc_mark_range_stealing,
            .gc_initial_mark_stack_size = gc_initial_mark_stack_size,
            .gc_no_end_padding = gc_no_end_padding,
            .gc_thread_local_size_limit = gc_thread_local_size_limit,
            .gc_realloc_no_free = gc_realloc_no_free,
            .gc_no_thread_local_warmup = gc_no_thread_local_warmup,
        }) else null;

        for (root_c_files.items) |entry| {
            // Get the binary name, by removing .root.c from end and having it relative to the projpath_outtypes
            var nlen = ".root.c".len;
            if (entry.test_root)
                nlen = ".test_root.c".len - ".test_".len;
            nlen += 1; // for the null terminator
            const binname = b.allocator.alloc(u8, entry.file_path.len-nlen) catch |err| {
                std.log.info("Error allocating binname: {}", .{err});
                std.process.exit(1);
            };
            if (entry.test_root) {
                // Write '.test_' to start of binname
                const buf = b.allocator.print(".test_{s}", .{entry.file_path[1..entry.file_path.len - ".test_root.c".len]}) catch |err| {
                    std.log.err("Error allocating binname: {}", .{err});
                    std.process.exit(1);
                };
                @memcpy(binname, buf);
            } else {
                @memcpy(binname, entry.file_path[1..(entry.file_path.len - ".root.c".len)]);
            }
            // Replace / with . in the binary name
            for (binname) |*ch| {
                if (ch.* == '/') ch.* = '.';
            }

            print("Building executable from: {s} -> {s}\n", .{entry.full_path, binname});

            const executable = b.addExecutable(.{
                .name = binname,
                .root_module = b.createModule(.{
                    .target = target,
                    .optimize = optimize,
                }),
            });
            if (enable_lto) executable.lto = .thin;
            if (mimalloc) |allocator| executable.root_module.addObject(allocator);
            // Build relative path for the executable source file
            const exe_rel_path = b.allocator.alloc(u8, 9 + entry.file_path.len) catch @panic("OOM");
            @memcpy(exe_rel_path[0..9], "out/types");
            @memcpy(exe_rel_path[9..], entry.file_path);
            executable.root_module.addCSourceFile(.{ .file = project_path.path(b, exe_rel_path), .flags = flags.items });
            executable.root_module.addIncludePath(project_path.path(b, "."));
            executable.root_module.linkLibrary(libActonProject);
            for (explicit_libraries.items) |libActonExplicit| {
                if (libActonExplicit.linkage == .dynamic) {
                    if (target.result.os.tag != .linux) {
                        executable.root_module.addObjectFile(libActonExplicit.getEmittedBin());
                    }
                } else {
                    executable.root_module.linkLibrary(libActonExplicit);
                }
            }
            if (has_dynamic_libraries) {
                switch (target.result.os.tag) {
                    .macos => {
                        executable.root_module.addRPathSpecial("@executable_path/../lib");
                        executable.root_module.addRPathSpecial("@executable_path/lib");
                        executable.root_module.addRPathSpecial("@executable_path");
                    },
                    .linux => {
                        executable.rdynamic = true;
                        executable.root_module.addLibraryPath(project_path.path(b, "out/lib"));
                        for (explicit_dynamic_library_installs.items) |install_step| {
                            executable.step.dependOn(install_step);
                        }
                        for (explicit_dynamic_library_names.items) |lib_name| {
                            executable.root_module.linkSystemLibrary(lib_name, .{
                                .needed = true,
                                .use_pkg_config = .no,
                                .preferred_link_mode = .dynamic,
                            });
                        }
                        executable.root_module.addRPathSpecial("$ORIGIN/../lib");
                        executable.root_module.addRPathSpecial("$ORIGIN/lib");
                        executable.root_module.addRPathSpecial("$ORIGIN");
                    },
                    else => {},
                }
            }

            executable.root_module.linkLibrary(actonbase_dep.artifact("Acton"));
            if (maybe_actondb_dep) |actondb_dep| {
                executable.root_module.linkLibrary(actondb_dep.artifact("ActonDB"));
            }

            // exe: link with dependencies / get headers from Build.act

            executable.root_module.link_libc = true;
            executable.root_module.link_libcpp = true;
            b.installArtifact(executable);
        }
    }
}
