/*
 * Copyright (C) 2019-2021 Data Ductus AB
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdarg.h>

// print //////////////////////////////////////////////////////////////////////////////

static $WORD mkstr($WORD w) {
    B_value w1 = (B_value)w;
    return w1->$class->__str__(w);
}
 
B_str __str__(B_value x) {
    if (x == B_None)
        return B_None_str;
    else
        return x->$class->__str__(x);
}

B_NoneType B_print(B_tuple t, B_str sep_arg, B_str end_arg, bool stderr_arg, bool flush_arg) {
    FILE *outfd = stdout;
    if (stderr_arg) {
        outfd = stderr;
    }
    B_str sep = actStrFromCString(" ");
    if (sep_arg)
        sep = sep_arg;
    B_str end = actStrFromCString("\n");
    if (end_arg)
        end = end_arg;

    // Write to temporary buffer first, making us much less prone to interleaved
    // output from multiple threads. It costs a malloc and some copies but print
    // should not be used in performance critical code. Each element's str is
    // taken once, since taking it again can give a different str, and the
    // buffer is written by length, since a str can contain NUL.
    B_str *strs = acton_malloc(t->size * sizeof(B_str));
    int64_t tlen = end->nbytes;
    for (int i=0; i<t->size; i++) {
        strs[i] = __str__((B_value)t->components[i]);
        tlen += strs[i]->nbytes + (i > 0 ? sep->nbytes : 0);
    }
    char *s = acton_malloc_atomic(tlen);
    int64_t pos = 0;
    for (int i=0; i<t->size; i++) {
        if (i > 0) {
            memcpy(s+pos, sep->str, sep->nbytes);
            pos += sep->nbytes;
        }
        memcpy(s+pos, strs[i]->str, strs[i]->nbytes);
        pos += strs[i]->nbytes;
    }
    memcpy(s+pos, end->str, end->nbytes);
    pos += end->nbytes;
    fwrite(s, 1, pos, outfd);

    if (flush_arg)
        fflush(outfd);
    return B_None;
}

// enumerate //////////////////////////////////////////////////////////////////////////
/*
void B_IteratorD_enumerate_init(B_IteratorD_enumerate self, B_Iterator it, B_int n) {
    self->it = it;
    self->nxt = fromB_int(n);
}

bool B_IteratorD_enumerate_bool(B_IteratorD_enumerate self) {
    return true;
}

B_str B_IteratorD_enumerate_str(B_IteratorD_enumerate self) {
    return $FORMAT("<enumerate iterator object at %p>", self);
}

void B_IteratorD_enumerate_serialize(B_IteratorD_enumerate self,$Serial$state state) {
    $step_serialize(self->it,state);
    $step_serialize(toB_int(self->nxt),state);
}

B_IteratorD_enumerate B_IteratorD_enumerate$_deserialize(B_IteratorD_enumerate res,$Serial$state state) {
    if (!res)
        res = $DNEW(B_IteratorD_enumerate,state);
    ACTON_STORE(res, res->it, $step_deserialize(state));
    res->nxt = fromB_int((B_int)$step_deserialize(state));
    return res;
}

$WORD B_IteratorD_enumerate_next(B_IteratorD_enumerate it) {
    $WORD w = it->it->$class->__next__(it->it);
    return $NEWTUPLE(2,toB_int(it->nxt++),w);
}

struct B_IteratorD_enumerateG_class B_IteratorD_enumerateG_methods = {"B_IteratorD_enumerate",UNASSIGNED,($SuperG_class)&B_IteratorG_methods,B_IteratorD_enumerate_init,
                                                                B_IteratorD_enumerate_serialize, B_IteratorD_enumerate$_deserialize, 
                                                                B_IteratorD_enumerate_bool,B_IteratorD_enumerate_str,B_IteratorD_enumerate_str, B_IteratorD_enumerate_next};


B_IteratorD_enumerate B_IteratorD_enumerateG_new(B_Iterator it, B_int n) {
    return $NEW(B_IteratorD_enumerate, it, n);
}

B_Iterator B_enumerate(B_Iterable wit, $WORD iter, B_int start) {
    B_Iterator it = wit->$class->__iter__(wit,iter);
    if (!start)
        start = toB_int(0);
    return (B_Iterator)B_IteratorD_enumerateG_new(it,start); 
}
*/

B_list B_sorted(B_Ord wit, B_Iterable wit2, $WORD iter) {
    B_CollectionD_SequenceD_list w = B_CollectionD_SequenceD_listG_witness;
    B_list res = w->$class->__fromiter__(w, wit2, iter);
    B_tim_sort(wit, res->data, res->length);
    return res;
}

// EqOpt //////////////////////////////////////////////////////

extern struct $EqOptG_class $EqOptG_methods;

void $EqOptD___init__($EqOpt wit, B_Eq W_Eq$A) {
    wit->W_Eq$A = W_Eq$A;
}

bool $EqOptD_bool($EqOpt self) {
    return true;
}

B_str $EqOptD_str($EqOpt self) {
    return $FORMAT("<EqOpt witness at %p>", self);
}

void $EqOptD_serialize($EqOpt self,$Serial$state state) {
    $step_serialize(self->W_Eq$A,state);
}

$EqOpt $EqOptD_deserialize($EqOpt res, $Serial$state state) {
    if (!res)
        res = $DNEW($EqOpt,state);
    ACTON_STORE(res, res->W_Eq$A, $step_deserialize(state));
    return res;
}

bool $EqOptD___eq__($EqOpt wit, $WORD a, $WORD b) {
    if (a && b) {
        return wit->W_Eq$A->$class->__eq__(wit->W_Eq$A, a, b);
    }
    return (!a && !b) ? true : false;
}

bool $EqOptD___ne__($EqOpt wit, $WORD a, $WORD b) {
    if (a && b)
        return wit->W_Eq$A->$class->__ne__(wit->W_Eq$A, a, b);
    return (!a && !b) ? false : true;
}

struct $EqOptG_class $EqOptG_methods = {"$EqOpt", UNASSIGNED, NULL, $EqOptD___init__, $EqOptD_serialize, $EqOptD_deserialize, 
                                         $EqOptD_bool, $EqOptD_str, $EqOptD_str, $EqOptD___eq__, $EqOptD___ne__};


$EqOpt $EqOptG_new(B_Eq W_Eq$A) {
    return $NEW($EqOpt, W_Eq$A);
}


// EqTuple //////////////////////////////////////////////////////

// The tuple witnesses hold one witness per tuple component, in component
// order. Component-wise equality is shared by all three: the Eq slots sit at
// the same offsets in the Eq, Ord and Hashable witness class structs.

static bool $tupleWitD___eq__(B_tuple wits, $WORD a, $WORD b) {
    if (a == b)
        return true;
    B_tuple ta = (B_tuple)a;
    B_tuple tb = (B_tuple)b;
    for (int i = 0; i < wits->size; i++) {
        B_Eq w = (B_Eq)wits->components[i];
        if (!w->$class->__eq__(w, ta->components[i], tb->components[i]))
            return false;
    }
    return true;
}

void $EqTupleD___init__($EqTuple wit, B_tuple W_Eq) {
    wit->W_Eq = W_Eq;
}

bool $EqTupleD_bool($EqTuple self) {
    return true;
}

B_str $EqTupleD_str($EqTuple self) {
    return $FORMAT("<EqTuple witness at %p>", self);
}

void $EqTupleD_serialize($EqTuple self,$Serial$state state) {
    $step_serialize(self->W_Eq,state);
}

$EqTuple $EqTupleD_deserialize($EqTuple res, $Serial$state state) {
    if (!res)
        res = $DNEW($EqTuple,state);
    ACTON_STORE(res, res->W_Eq, $step_deserialize(state));
    return res;
}

bool $EqTupleD___eq__($EqTuple wit, $WORD a, $WORD b) {
    return $tupleWitD___eq__(wit->W_Eq, a, b);
}

bool $EqTupleD___ne__($EqTuple wit, $WORD a, $WORD b) {
    return !$tupleWitD___eq__(wit->W_Eq, a, b);
}

struct $EqTupleG_class $EqTupleG_methods = {"$EqTuple", UNASSIGNED, NULL, $EqTupleD___init__, $EqTupleD_serialize, $EqTupleD_deserialize,
                                             $EqTupleD_bool, $EqTupleD_str, $EqTupleD_str, $EqTupleD___eq__, $EqTupleD___ne__};


$EqTuple $EqTupleG_new(B_tuple W_Eq) {
    return $NEW($EqTuple, W_Eq);
}


// OrdTuple //////////////////////////////////////////////////////

extern struct $OrdTupleG_class $OrdTupleG_methods;

// W_Ord holds one Ord witness per tuple component, in component order.
// Comparison is lexicographic; operands always share one type, so sizes agree.

void $OrdTupleD___init__($OrdTuple wit, B_tuple W_Ord) {
    wit->W_Ord = W_Ord;
}

bool $OrdTupleD_bool($OrdTuple self) {
    return true;
}

B_str $OrdTupleD_str($OrdTuple self) {
    return $FORMAT("<OrdTuple witness at %p>", self);
}

void $OrdTupleD_serialize($OrdTuple self,$Serial$state state) {
    $step_serialize(self->W_Ord,state);
}

$OrdTuple $OrdTupleD_deserialize($OrdTuple res, $Serial$state state) {
    if (!res)
        res = $DNEW($OrdTuple,state);
    ACTON_STORE(res, res->W_Ord, $step_deserialize(state));
    return res;
}

bool $OrdTupleD___eq__($OrdTuple wit, $WORD a, $WORD b) {
    return $tupleWitD___eq__(wit->W_Ord, a, b);
}

bool $OrdTupleD___ne__($OrdTuple wit, $WORD a, $WORD b) {
    return !$tupleWitD___eq__(wit->W_Ord, a, b);
}

// Lexicographic comparison: the first component that is not equal decides;
// all-equal tuples satisfy only the non-strict comparisons.
static bool $tupleWitD_lex(B_tuple wits, $WORD a, $WORD b, bool strict) {
    B_tuple ta = (B_tuple)a;
    B_tuple tb = (B_tuple)b;
    for (int i = 0; i < wits->size; i++) {
        B_Ord w = (B_Ord)wits->components[i];
        if (w->$class->__lt__(w, ta->components[i], tb->components[i]))
            return true;
        if (w->$class->__ne__(w, ta->components[i], tb->components[i]))
            return false;
    }
    return !strict;
}

bool $OrdTupleD___lt__($OrdTuple wit, $WORD a, $WORD b) {
    return $tupleWitD_lex(wit->W_Ord, a, b, true);
}

bool $OrdTupleD___le__($OrdTuple wit, $WORD a, $WORD b) {
    return $tupleWitD_lex(wit->W_Ord, a, b, false);
}

bool $OrdTupleD___gt__($OrdTuple wit, $WORD a, $WORD b) {
    return $OrdTupleD___lt__(wit, b, a);
}

bool $OrdTupleD___ge__($OrdTuple wit, $WORD a, $WORD b) {
    return $OrdTupleD___le__(wit, b, a);
}

struct $OrdTupleG_class $OrdTupleG_methods = {"$OrdTuple", UNASSIGNED, NULL, $OrdTupleD___init__, $OrdTupleD_serialize, $OrdTupleD_deserialize,
                                               $OrdTupleD_bool, $OrdTupleD_str, $OrdTupleD_str, $OrdTupleD___eq__, $OrdTupleD___ne__,
                                               $OrdTupleD___lt__, $OrdTupleD___le__, $OrdTupleD___gt__, $OrdTupleD___ge__};


$OrdTuple $OrdTupleG_new(B_tuple W_Ord) {
    return $NEW($OrdTuple, W_Ord);
}


// HashableTuple //////////////////////////////////////////////////////

extern struct $HashableTupleG_class $HashableTupleG_methods;

// W_Hashable holds one Hashable witness per tuple component, in component order.

void $HashableTupleD___init__($HashableTuple wit, B_tuple W_Hashable) {
    wit->W_Hashable = W_Hashable;
}

bool $HashableTupleD_bool($HashableTuple self) {
    return true;
}

B_str $HashableTupleD_str($HashableTuple self) {
    return $FORMAT("<HashableTuple witness at %p>", self);
}

void $HashableTupleD_serialize($HashableTuple self,$Serial$state state) {
    $step_serialize(self->W_Hashable,state);
}

$HashableTuple $HashableTupleD_deserialize($HashableTuple res, $Serial$state state) {
    if (!res)
        res = $DNEW($HashableTuple,state);
    ACTON_STORE(res, res->W_Hashable, $step_deserialize(state));
    return res;
}

bool $HashableTupleD___eq__($HashableTuple wit, $WORD a, $WORD b) {
    return $tupleWitD___eq__(wit->W_Hashable, a, b);
}

bool $HashableTupleD___ne__($HashableTuple wit, $WORD a, $WORD b) {
    return !$tupleWitD___eq__(wit->W_Hashable, a, b);
}

B_NoneType $HashableTupleD_hash($HashableTuple wit, $WORD a, B_hasher h) {
    B_tuple wits = wit->W_Hashable;
    B_tuple ta = (B_tuple)a;
    for (int i = 0; i < wits->size; i++) {
        // We hash each component, followed by the number of bytes it
        // contributed, so component boundaries cannot shift: without this,
        // ("ab", "c") and ("a", "bc") would hash equal.
        B_Hashable w = (B_Hashable)wits->components[i];
        uint64_t before = zig_hash_wyhash_total_len(h->_hasher);
        w->$class->hash(w, ta->components[i], h);
        uint64_t n = zig_hash_wyhash_total_len(h->_hasher) - before;
        zig_hash_wyhash_update(h->_hasher, (const uint8_t *)&n, sizeof(n));
    }
    return B_None;
}

struct $HashableTupleG_class $HashableTupleG_methods = {"$HashableTuple", UNASSIGNED, NULL, $HashableTupleD___init__, $HashableTupleD_serialize,
                                                         $HashableTupleD_deserialize, $HashableTupleD_bool, $HashableTupleD_str, $HashableTupleD_str,
                                                         $HashableTupleD___eq__, $HashableTupleD___ne__, $HashableTupleD_hash};


$HashableTuple $HashableTupleG_new(B_tuple W_Hashable) {
    return $NEW($HashableTuple, W_Hashable);
}


// wEqNone //////////////////////////////////////////////////////

// The Eq witness for None: None is the only value of its type.

static bool $wEqNoneD___eq__(B_Eq wit, $WORD a, $WORD b) {
    return true;
}

static bool $wEqNoneD___ne__(B_Eq wit, $WORD a, $WORD b) {
    return false;
}

static void $wEqNoneD_serialize(B_Eq self, $Serial$state state) {
}

static struct B_Eq $wEqNone_instance;

static B_Eq $wEqNoneD_deserialize(B_Eq res, $Serial$state state) {
    if (!res) {
        res = &$wEqNone_instance;
        B_dictD_setitem(state->done, toB_int(state->row_no-1), res);
    }
    return res;
}

struct B_EqG_class $wEqNoneG_class = {"$wEqNone", UNASSIGNED, NULL,
    (B_NoneType (*)(B_Eq))$default__init__, $wEqNoneD_serialize, $wEqNoneD_deserialize,
    (bool (*)(B_Eq))$default__bool__, (B_str (*)(B_Eq))$default__str__, (B_str (*)(B_Eq))$default__str__,
    $wEqNoneD___eq__, $wEqNoneD___ne__};

static struct B_Eq $wEqNone_instance = {&$wEqNoneG_class};

B_Eq $wEqNone = &$wEqNone_instance;


// IdentityActor //////////////////////////////////////////////////////

extern struct $IdentityActorG_class $IdentityActorG_methods;

void $IdentityActorD___init__($IdentityActor wit) { }

bool $IdentityActorD_bool($IdentityActor self) {
    return true;
}

B_str $IdentityActorD_str($IdentityActor self) {
    return $FORMAT("<IdentityActor witness at %p>", self);
}

void $IdentityActorD_serialize($IdentityActor self,$Serial$state state) { }

$IdentityActor $IdentityActorD_deserialize($IdentityActor res, $Serial$state state) {
    if (!res)
        res = $DNEW($IdentityActor,state);
    return res;
}

bool $IdentityActorD___is__($IdentityActor wit, $WORD a, $WORD b) {
    return (a == b) ? true : false;
}

bool $IdentityActorD___isnot__($IdentityActor wit, $WORD a, $WORD b) {
    return (a == b) ? false : true;
}

struct $IdentityActorG_class $IdentityActorG_methods = {"$IdentityActor", UNASSIGNED, NULL, $IdentityActorD___init__, $IdentityActorD_serialize, $IdentityActorD_deserialize, 
                                         $IdentityActorD_bool, $IdentityActorD_str, $IdentityActorD_str, $IdentityActorD___is__, $IdentityActorD___isnot__};


$IdentityActor $IdentityActorG_new() {
    return $NEW($IdentityActor);
}


// Various small functions //////////////////////////////////////////////////////////////

// Code generated by actonc
/*
$WORD B_abs (B_Number W_149, B_Real W_148, $WORD x) {
    return W_149->$class->__abs__(W_149, x, W_148);
}

B_bool B_all (B_Iterable W_164, $WORD it) {
    B_Iterator nB_iter = W_164->$class->__iter__(W_164, it);
    $WORD n$1val = nB_iter->$class->__next__(nB_iter);
    while ($ISNOTNONE(n$1val)) {
        B_value x = (B_value)n$1val;
        if (!x->$class->__bool__(x)->val) {
            return (B_bool)B_False;
        }
        n$1val = nB_iter->$class->__next__(nB_iter);
    }
    return (B_bool)B_True;
}
B_bool B_any (B_Iterable W_179, $WORD it) {
    B_Iterator n$2iter = W_179->$class->__iter__(W_179, it);
    $WORD n$3val = n$2iter->$class->__next__(n$2iter);
    while ($ISNOTNONE(n$3val)) {
        B_value x = (B_value)n$3val;
        if (x->$class->__bool__(x)->val) {
            return (B_bool)B_True;
        }
        n$3val = n$2iter->$class->__next__(n$2iter);
    }
    return (B_bool)B_False;
}

B_tuple B_divmod (B_Integral W_225, $WORD a, $WORD b) {
    return W_225->$class->__divmod__(W_225, a, b);
}
B_Iterator B_iter (B_Iterable W_278, $WORD x) {
    return W_278->$class->__iter__(W_278, x);
}
int64_t B_len (B_Collection W_301, $WORD x) {
    return W_301->$class->__len__(W_301, x);
}

$WORD B_pow (B_Number W_344, $WORD a, $WORD b) {
    return W_344->$class->__pow__(W_344, a, b);
}

B_str B_repr(B_value x) {
    return x->$class->__repr__(x);
}

B_Iterator B_reversed (B_Sequence W_369, $WORD seq) {
    return W_369->$class->__reversed__(W_369, seq);
}
$WORD B_round (B_Real W_395, $WORD x, B_int n) {
    return W_395->$class->__round__(W_395, x, n);
}
*/

static struct B_AssertionError B_assert_error =
    STATIC_EXCEPTION(B_AssertionError, "");

$WORD $ASSERT(bool test, B_str msg) {
    if (!test) {
        if (msg)
            RAISE(B_AssertionError, msg);
        RAISE_EXC(&B_assert_error);
        return NULL; // to avoid compiler warning
    }
    return B_None;
}
