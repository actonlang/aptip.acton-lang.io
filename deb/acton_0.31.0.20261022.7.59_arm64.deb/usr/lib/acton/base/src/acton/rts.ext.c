#define GC_THREADS 1
#include <gc.h>
#include <acton_gc_config.h>

#include <time.h>
#include <uv.h>

#include "rts/io.h"
#include "rts/log.h"
#include "rts/perf.h"

void actonQ_rtsQ___ext_init__() {
    // NOP
}

B_NoneType actonQ_rtsQ_gc (B_SysCap cap) {
    GC_gcollect_and_unmap();
    return B_None;
}

B_NoneType actonQ_rtsQ_enable_gc (B_SysCap cap) {
    GC_enable();
    return B_None;
}

B_NoneType actonQ_rtsQ_disable_gc (B_SysCap cap) {
    GC_disable();
    return B_None;
}

// def start_gc_performance_measurement(cap: SysCap) -> None:
B_NoneType actonQ_rtsQ_start_gc_performance_measurement (B_SysCap cap) {
    GC_start_performance_measurement();
    return B_None;
}

// def get_gc_time(cap: SysCap) -> (total: u64, mark: u64, sweep: u64):
B_tuple actonQ_rtsQ_get_gc_time (B_SysCap cap) {
    unsigned long total = GC_get_full_gc_total_time();
    unsigned long mark = GC_get_stopped_mark_total_time();
    unsigned long sweep = total - mark;

    B_tuple res = $NEWTUPLE(3,
                            toB_u64(total),
                            toB_u64(mark),
                            toB_u64(sweep)
                            );
    return res;
}

struct acton_gc_info {
    struct GC_prof_stats_s stats;
    struct GC_timeval_s time_limit;
    unsigned backend;
    unsigned supported_backends;
    int incremental;
    GC_word free_space_divisor;
    int full_frequency;
    GC_word heap_growth_divisor;
    GC_word alloc_budget_percent;
    int realloc_no_free;
    int no_thread_local_warmup;
    unsigned tl_refill_max;
};

static void *GC_CALLBACK read_gc_info(void *data) {
    struct acton_gc_info *info = data;
#if ACTON_GC_THREADS
    GC_get_prof_stats_unsafe(&info->stats, sizeof(info->stats));
#else
    GC_get_prof_stats(&info->stats, sizeof(info->stats));
#endif
#if defined(__wasi__)
    info->time_limit.tv_ms = GC_get_time_limit();
    info->time_limit.tv_nsec = 0;
#else
    info->time_limit = GC_get_time_limit_tv();
#endif
    info->backend = GC_get_actual_vdb();
    info->supported_backends = GC_get_supported_vdbs();
    info->incremental = GC_is_incremental_mode();
    info->free_space_divisor = GC_get_free_space_divisor();
    info->full_frequency = GC_get_full_freq();
    info->heap_growth_divisor = GC_get_heap_growth_divisor();
    info->alloc_budget_percent = GC_get_alloc_budget_percent();
    info->realloc_no_free = GC_get_realloc_no_free();
    info->no_thread_local_warmup = GC_get_no_thread_local_warmup();
    info->tl_refill_max = GC_get_tl_refill_max();
    return NULL;
}

static const struct {
    unsigned flag;
    const char *name;
} gc_backends[] = {
    {GC_VDB_MPROTECT, "mprotect"},
    {GC_VDB_MANUAL, "manual"},
    {GC_VDB_DEFAULT, "default"},
    {GC_VDB_GWW, "get_write_watch"},
    {GC_VDB_PROC, "proc"},
    {GC_VDB_SOFT, "soft_dirty"},
    {GC_VDB_UFFDWP, "userfaultfd"},
};

B_tuple actonQ_rtsQ_get_gc_info (B_SysCap cap) {
    struct acton_gc_info info;
#if ACTON_GC_THREADS
    GC_call_with_reader_lock(read_gc_info, &info, 0);
#else
    read_gc_info(&info);
#endif
    // The getter takes the allocator lock itself.
    size_t bytes_per_marker = GC_get_bytes_per_marker();

    // Construct Acton values only after releasing the collector lock.
    const char *mode = !info.incremental ? "ordinary"
        : info.time_limit.tv_ms == GC_TIME_UNLIMITED ? "generational"
        : "incremental";
    const char *backend = info.backend == GC_VDB_NONE ? "none" : "unknown";
    B_list supported = B_listG_new(NULL, NULL);
    B_SequenceD_list sequence = B_SequenceD_listG_witness;
    for (size_t i = 0; i < sizeof(gc_backends) / sizeof(gc_backends[0]); i++) {
        if (info.backend == gc_backends[i].flag)
            backend = gc_backends[i].name;
        if (info.supported_backends & gc_backends[i].flag)
            sequence->$class->append(sequence, supported,
                                    actStrFromCString(gc_backends[i].name));
    }
    // The warm-up and refill settings have no effect without thread-local
    // allocation, which a zero limit tells.
    unsigned thread_local_size_limit = acton_gc_get_thread_local_size_limit();
    B_float pause_target = (B_float)B_None;
    if (info.incremental && info.time_limit.tv_ms != GC_TIME_UNLIMITED)
        pause_target = to$float((double)info.time_limit.tv_ms
                               + (double)info.time_limit.tv_nsec / 1000000.0);

    return $NEWTUPLE(24,
        actStrFromCString(mode), actStrFromCString(ACTON_GC_DIRTY_TRACKING_BACKEND),
        actStrFromCString(backend), supported,
        toB_u64(acton_gc_get_page_hash_table_log2()),
        toB_u64(acton_gc_get_block_size()),
        toB_bool(acton_gc_get_end_padding()),
        toB_u64(thread_local_size_limit),
        toB_bool(thread_local_size_limit != 0 && info.no_thread_local_warmup),
        toB_u64(thread_local_size_limit != 0 ? info.tl_refill_max : 0),
        toB_bool(info.realloc_no_free),
        toB_u64(info.stats.markers_m1 + 1), toB_u64(bytes_per_marker),
        toB_bool(acton_gc_get_mark_range_stealing()),
        toB_bool(acton_gc_get_mark_bits()),
        toB_u64(acton_gc_get_initial_mark_stack_size()), pause_target,
        toB_u64(info.free_space_divisor), toB_u64(info.full_frequency),
        toB_u64(info.heap_growth_divisor), toB_u64(info.alloc_budget_percent),
        toB_u64(info.stats.heapsize_full),
        toB_u64(info.stats.free_bytes_full),
        toB_u64(info.stats.unmapped_bytes));
}

B_u64 actonQ_rtsQ_get_heap_size (B_SysCap cap) {
    return toB_u64(GC_get_heap_size());
}

uint64_t actonQ_rtsQ_get_mem_usage (B_SysCap cap) {
    return GC_get_heap_size() - GC_get_free_bytes();
}

// def get_gc_total_bytes(cap: SysCap) -> u64:
uint64_t actonQ_rtsQ_get_gc_total_bytes (B_SysCap cap) {
    return GC_get_total_bytes();
}

//def get_gc_bytes_since_gc(cap: SysCap) -> u64:
uint64_t actonQ_rtsQ_get_gc_bytes_since_gc (B_SysCap cap) {
    return GC_get_bytes_since_gc();
}

// def get_rss(cap: SysCap) -> u64:
uint64_t actonQ_rtsQ_get_rss (B_SysCap cap) {
    size_t rsm;
    int r = uv_resident_set_memory(&rsm);
    return (uint64_t)rsm;
}

int64_t actonQ_rtsQ_rss (B_SysCap cap) {
    size_t rsm;
    int r = uv_resident_set_memory(&rsm);
    return (int64_t)rsm;
}

B_u64 actonQ_rtsQ_get_peak_rss (B_SysCap cap) {
    uint64_t bytes;
    if (!rts_perf_peak_rss(&bytes))
        return (B_u64)B_None;
    return toB_u64(bytes);
}

B_tuple actonQ_rtsQ_perf_snapshot (B_SysCap cap) {
    struct rts_perf_sample s;
    rts_perf_read(&s);
    return $NEWTUPLE(8,
        s.cpu_available ? toB_u64(s.user_ns) : (B_u64)B_None,
        s.cpu_available ? toB_u64(s.system_ns) : (B_u64)B_None,
        s.hardware_available ? toB_u64(s.instructions) : (B_u64)B_None,
        s.hardware_available ? toB_u64(s.cycles) : (B_u64)B_None,
        toB_u64(s.instructions_enabled), toB_u64(s.instructions_running),
        toB_u64(s.cycles_enabled), toB_u64(s.cycles_running));
}

B_dict actonQ_rtsQ_perf_info (B_SysCap cap) {
    B_Hashable wit = (B_Hashable)B_HashableD_strG_witness;
    B_dict info = $NEW(B_dict, wit, NULL, NULL);
    B_dictD_setitem(info, wit, actStrFromCString("version"), actStrFromCString("1"));
    B_dictD_setitem(info, wit, actStrFromCString("backend"), actStrFromCString(rts_perf_backend()));
    B_dictD_setitem(info, wit, actStrFromCString("scope"), actStrFromCString(rts_perf_scope()));
    B_dictD_setitem(info, wit, actStrFromCString("status"), actStrFromCString(rts_perf_status()));
    uv_utsname_t system;
    if (uv_os_uname(&system) == 0) {
        B_dictD_setitem(info, wit, actStrFromCString("os"), actStrFromCStringCopy(system.sysname));
        B_dictD_setitem(info, wit, actStrFromCString("release"), actStrFromCStringCopy(system.release));
        B_dictD_setitem(info, wit, actStrFromCString("arch"), actStrFromCStringCopy(system.machine));
    }
    uv_cpu_info_t *cpus;
    int count;
    if (uv_cpu_info(&cpus, &count) == 0) {
        if (count > 0)
            B_dictD_setitem(info, wit, actStrFromCString("cpu"), actStrFromCStringCopy(cpus[0].model));
        uv_free_cpu_info(cpus, count);
    }
    return info;
}

B_NoneType actonQ_rtsQ_sleep (B_SysCap cap, double sleep_time) {
    double st = sleep_time;
    struct timespec ts;
    ts.tv_sec = (int)st;
    ts.tv_nsec = (st - (float)ts.tv_sec)*1e9;

    // Handle overflow of nanoseconds into seconds
    if (ts.tv_nsec >= 1e9) {
        ts.tv_sec += 1;
        ts.tv_nsec -= 1e9;
    }

    // Use high precision nanosleep where available, otherwise fall back to uv_sleep.
#if defined(__linux__) || defined(__APPLE__)
    // Unlike usleep, nanosleep() tolerates signal interrupts and will write the
    // remaining time (that it didn't sleep) into the third argument. We spin
    // until it completes successfully.
    while (nanosleep(&ts, &ts) != 0) {
        // Continue sleeping with remaining time
    }
#else
    // For other platforms, fall back to uv_sleep (millisecond granularity)
    uv_sleep((uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
#endif
    return B_None;
}

struct actonQ_rtsQ_io_handles_walk_res {
    B_dict d;
    B_Hashable wit;
};

void actonQ_rtsQ_io_handles_walk_cb (uv_handle_t *handle, void *arg) {
    struct actonQ_rtsQ_io_handles_walk_res *walk_res = (struct actonQ_rtsQ_io_handles_walk_res *)arg;
    B_tuple val;
    if (uv_handle_get_type(handle) == UV_TCP) {
        $Actor hactor = handle->data;
        val = (B_tuple)$NEWTUPLE(2,
                                actStrFromCString(uv_handle_type_name(uv_handle_get_type(handle))),
                                toB_u64((unsigned long)hactor)
                                );
    } else {
        val = (B_tuple)$NEWTUPLE(2,
                                actStrFromCString(uv_handle_type_name(uv_handle_get_type(handle))),
                                toB_u64(0) // TODO: should be None type instead, right?
                                );
    }

    B_dictD_setitem(walk_res->d, walk_res->wit, toB_u64((long)handle), val);
}

B_dict actonQ_rtsQ__io_handles (B_SysCap cap) {
    B_Hashable wit = (B_Hashable)B_HashableD_u64G_witness;
    B_dict d = $NEW(B_dict, wit, NULL, NULL);

    struct actonQ_rtsQ_io_handles_walk_res walk_res;
    walk_res.wit = wit;
    walk_res.d = d;
    uv_walk(get_uv_loop(), actonQ_rtsQ_io_handles_walk_cb, (void *)&walk_res);

    return d;
}

B_dict actonQ_rtsQ_rts_stats (B_SysCap cap) {
    B_Hashable wit = (B_Hashable)B_HashableD_u64G_witness;
    B_dict d = $NEW(B_dict, wit, NULL, NULL);
#define WT(f) WT_STAT_GET(wt_stats[i].f)
    for (int i = 0; i <= num_wthreads; i++) {
        B_tuple stats = $NEWTUPLE(28,
                            actStrFromCString("TODO"), // state
                            toB_u64(WT(sleeps)),
                            toB_u64(WT(conts_count)),
                            toB_u64(WT(conts_sum)),
                            toB_u64(WT(conts_100ns)),
                            toB_u64(WT(conts_1us)),
                            toB_u64(WT(conts_10us)),
                            toB_u64(WT(conts_100us)),
                            toB_u64(WT(conts_1ms)),
                            toB_u64(WT(conts_10ms)),
                            toB_u64(WT(conts_100ms)),
                            toB_u64(WT(conts_1s)),
                            toB_u64(WT(conts_10s)),
                            toB_u64(WT(conts_100s)),
                            toB_u64(WT(conts_inf)),
                            toB_u64(WT(bkeep_count)),
                            toB_u64(WT(bkeep_sum)),
                            toB_u64(WT(bkeep_100ns)),
                            toB_u64(WT(bkeep_1us)),
                            toB_u64(WT(bkeep_10us)),
                            toB_u64(WT(bkeep_100us)),
                            toB_u64(WT(bkeep_1ms)),
                            toB_u64(WT(bkeep_10ms)),
                            toB_u64(WT(bkeep_100ms)),
                            toB_u64(WT(bkeep_1s)),
                            toB_u64(WT(bkeep_10s)),
                            toB_u64(WT(bkeep_100s)),
                            toB_u64(WT(bkeep_inf))
                            );
        B_dictD_setitem(d, wit, toB_u64(i), stats);
    }
#undef WT
    return d;
}

$R actonQ_rtsQ_WThreadMonitorD__initG_local (actonQ_rtsQ_WThreadMonitor self, $Cont C_cont) {
    set_actor_affinity((int)self->wthread_id);
    return $R_CONT(C_cont, B_None);
}
