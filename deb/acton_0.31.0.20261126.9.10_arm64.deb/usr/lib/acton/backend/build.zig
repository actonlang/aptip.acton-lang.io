const std = @import("std");
const print = @import("std").debug.print;
const ArrayList = std.ArrayList;

pub fn build(b: *std.Build) void {
    // Normalize the serialized package root so C inputs and prefix maps agree.
    if (b.root.root_dir.path) |path| {
        b.root.root_dir.path = b.pathResolve(&.{path});
    }
    const optimize = b.standardOptimizeOption(.{});
    const target = b.standardTargetOptions(.{});
    const enable_lto = optimize != .debug and target.result.os.tag != .macos;
    const no_threads = b.option(bool, "no_threads", "") orelse false;
    const only_actondb = b.option(bool, "only_actondb", "") orelse false;
    const gc_use_mark_bits = b.option(bool, "gc_use_mark_bits", "Use packed GC mark bits (default: true)") orelse true;
    const gc_mark_bit_per_object = b.option(bool, "gc_mark_bit_per_object", "Track GC marks per object") orelse false;
    const gc_page_hash_table_log2 = b.option(u8, "gc_page_hash_table_log2", "Log2 of GC page-hash entries (0 keeps the default)") orelse 0;
    const gc_heap_growth_divisor = b.option(u32, "gc_heap_growth_divisor", "Limit automatic GC heap growth to the heap size divided by this (default 4; 0 keeps the fixed increment)") orelse 4;
    const gc_alloc_budget_percent = b.option(u32, "gc_alloc_budget_percent", "Collect after allocating this percentage of the live data (default 250; 0 selects the free space divisor policy)") orelse 250;
    const gc_memory_limit = b.option(u64, "gc_memory_limit", "Memory limit in bytes for sizing the GC heap, used if smaller than the physical memory and the cgroup memory limit (default 0: none)") orelse 0;
    const gc_heap_ceiling_percent = b.option(u32, "gc_heap_ceiling_percent", "GC heap ceiling as a percentage of the memory limit: the allocation between collections shrinks as the live data approaches it (default 75; 0 turns the sizing of the heap by the memory limit off)") orelse 75;
    const gc_block_size = b.option(u32, "gc_block_size", "GC heap block size in bytes: a power of two from 4096 to 65536 (default 16384; 0 keeps the collector's 4096)") orelse 16384;
    const gc_mark_range_stealing = b.option(bool, "gc_mark_range_stealing", "Let parallel GC markers claim ranges of the global mark stack (default: true on targets with threads)") orelse !target.result.cpu.arch.isWasm();
    const gc_bytes_per_marker = b.option(u64, "gc_bytes_per_marker", "Give a parallel GC mark phase one marker per this many bytes it is estimated to scan (default 4194304; 0 gives every phase all the markers)") orelse 4194304;
    const gc_initial_mark_stack_size = b.option(u32, "gc_initial_mark_stack_size", "Initial number of GC mark stack entries: a power of two, 4096 at least (default: 4194304, 1048576 on Windows; 0 keeps the collector's default of as many entries as a heap block has bytes)") orelse @as(u32, if (target.result.os.tag == .windows) 1048576 else 4194304);
    const gc_no_end_padding = b.option(bool, "gc_no_end_padding", "Do not pad GC objects by a byte to keep them alive through pointers just past their end (default: true)") orelse true;
    const gc_thread_local_size_limit = b.option(u32, "gc_thread_local_size_limit", "Largest GC object size in bytes served from thread-local free lists: a multiple of 16 up to half the block size (default 2048 with blocks of 16384 bytes or more, else the collector's default, 384 on 64-bit targets; 0 keeps the collector's default)") orelse @as(u32, if (gc_block_size >= 16384) 2048 else 0);
    const gc_realloc_no_free = b.option(bool, "gc_realloc_no_free", "Leave a small collectable object moved by GC_realloc to the collector instead of freeing it (default: true)") orelse true;
    const gc_no_thread_local_warmup = b.option(bool, "gc_no_thread_local_warmup", "Let a new thread use its own GC free list of each size from its first allocation of that size (default: true on targets with threads)") orelse !target.result.cpu.arch.isWasm();
    const gc_thread_local_refill_blocks = b.option(u32, "gc_thread_local_refill_blocks", "Largest number of GC heap blocks that one refill of a thread-local free list takes under the allocator lock, from 1 to 32 (default 16)") orelse 16;

    const dep_libargp = b.dependency("libargp", .{
        .target = target,
        .optimize = optimize,
    });

    // Must match the collector options in base/build.zig, so that both
    // resolve to the same libgc.
    const dep_libgc = b.dependency("libgc", .{
        .target = target,
        .optimize = optimize,
        .linkage = .static,
        .enable_threads = !target.result.cpu.arch.isWasm(),
        .enable_large_config = true,
        .enable_mmap = true,
        .enable_mark_bits = gc_use_mark_bits,
        .enable_mark_bit_per_obj = gc_mark_bit_per_object,
        .dirty_tracking_backend = "manual",
        .page_hash_table_log2 = gc_page_hash_table_log2,
        .heap_growth_divisor = gc_heap_growth_divisor,
        .alloc_budget_percent = gc_alloc_budget_percent,
        .memory_limit = gc_memory_limit,
        .heap_ceiling_percent = gc_heap_ceiling_percent,
        .block_size = gc_block_size,
        .enable_mark_range_stealing = gc_mark_range_stealing,
        .bytes_per_marker = gc_bytes_per_marker,
        .initial_mark_stack_size = gc_initial_mark_stack_size,
        .enable_end_padding = !gc_no_end_padding,
        .tiny_freelists = gcTinyFreelists(target.result, gc_thread_local_size_limit),
        .disable_realloc_free = gc_realloc_no_free,
        .disable_thread_local_warmup = gc_no_thread_local_warmup,
        .tl_refill_max = gc_thread_local_refill_blocks,
        .CFLAGS_EXTRA = gcCflagsExtra(target.result),
    });
    const libgc = dep_libgc.artifact("gc");
    if (enable_lto) libgc.lto = .thin;

    const dep_libnetstring = b.dependency("libnetstring", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libprotobuf_c = b.dependency("libprotobuf_c", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libuuid = b.dependency("libuuid", .{
        .target = target,
        .optimize = optimize,
    });

    const dep_libyyjson = b.dependency("libyyjson", .{
        .target = target,
        .optimize = optimize,
    });

    const libactondb_sources = [_][]const u8 {
        "comm.c",
        "hash_ring.c",
        "queue_callback.c",
        "db.c",
        "queue.c",
        "queue_groups.c",
//        "log.c",
        "skiplist.c",
        "txn_state.c",
        "txns.c",
        "client_api.c",
        "failure_detector/db_messages.pb-c.c",
        "failure_detector/cells.c",
        "failure_detector/db_queries.c",
        "failure_detector/fd.c",
        "failure_detector/vector_clock.c",
    };

    var flags = std.ArrayList([]const u8).empty;
    defer flags.deinit(b.allocator);
    flags.append(b.allocator, "-fno-sanitize=undefined") catch unreachable;

    var file_prefix_map = std.ArrayList(u8).empty;
    defer file_prefix_map.deinit(b.allocator);
    const buildroot_path = b.root.joinString(b.allocator, "") catch unreachable;
    const file_prefix_path_path = std.fs.path.dirname(buildroot_path) orelse buildroot_path;
    file_prefix_map.appendSlice(b.allocator, "-ffile-prefix-map=") catch unreachable;
    file_prefix_map.appendSlice(b.allocator, file_prefix_path_path) catch unreachable;
    file_prefix_map.appendSlice(b.allocator, "/=") catch unreachable;
    flags.append(b.allocator, file_prefix_map.items) catch unreachable;

    if (no_threads) {
        print("No threads\n", .{});
    } else {
        print("Threads enabled\n", .{});
        flags.appendSlice(b.allocator, &.{
            "-DACTON_THREADS",
        }) catch |err| {
            std.log.err("Error appending flags: {}", .{err});
            std.process.exit(1);
        };
    }

    const libactondb = b.addLibrary(.{
        .name = "ActonDB",
        .linkage = .static,
        .root_module = b.createModule(.{
            .target = target,
            .optimize = optimize,
        }),
    });
    if (enable_lto) libactondb.lto = .thin;
    libactondb.root_module.addCSourceFiles(.{
        .files = &libactondb_sources,
        .flags = flags.items
    });
    libactondb.root_module.addCMacro("LOG_USER_COLOR", "");
    libactondb.root_module.linkLibrary(libgc);
    libactondb.root_module.linkLibrary(dep_libprotobuf_c.artifact("protobuf-c"));
    libactondb.root_module.linkLibrary(dep_libuuid.artifact("uuid"));
    libactondb.root_module.link_libc = true;
    libactondb.root_module.link_libcpp = true;
    libactondb.installLibraryHeaders(dep_libprotobuf_c.artifact("protobuf-c"));
    libactondb.installLibraryHeaders(dep_libuuid.artifact("uuid"));
    if (!only_actondb) {
        b.installArtifact(libactondb);
    }

    const actondb = b.addExecutable(.{
        .name = "actondb",
        .root_module = b.createModule(.{
            .target = target,
            .optimize = optimize,
        }),
    });
    if (enable_lto) actondb.lto = .thin;
    actondb.root_module.addCSourceFile(.{ .file = b.path("actondb.c"), .flags = &[_][]const u8{
        "-fno-sanitize=undefined",
    }});
    actondb.root_module.addCSourceFile(.{ .file = b.path("log.c"), .flags = flags.items });
    actondb.root_module.linkLibrary(libactondb);
    actondb.root_module.linkLibrary(dep_libargp.artifact("argp"));
    actondb.root_module.linkLibrary(dep_libnetstring.artifact("netstring"));
    actondb.root_module.linkLibrary(dep_libprotobuf_c.artifact("protobuf-c"));
    actondb.root_module.linkLibrary(dep_libyyjson.artifact("yyjson"));
    actondb.root_module.linkLibrary(dep_libuuid.artifact("uuid"));
    actondb.root_module.link_libc = true;
    actondb.root_module.link_libcpp = true;
    b.installArtifact(actondb);
}

// Same as gcTinyFreelists in base/build.zig.
fn gcTinyFreelists(t: std.Target, size_limit: u32) u32 {
    if (size_limit == 0) return 0;
    return size_limit / (2 * (t.ptrBitWidth() / 8)) + 1;
}

// Same as gcCflagsExtra in base/build.zig.
fn gcCflagsExtra(t: std.Target) []const u8 {
    if (t.os.tag != .windows) return "";
    return "-DCONSOLE_LOG -DNO_MSGBOX_ON_ERROR";
}
