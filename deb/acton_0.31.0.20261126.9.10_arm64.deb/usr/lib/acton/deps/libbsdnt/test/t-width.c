/*
  Copyright (C) 2013 William Hart

  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
	 documentation and/or other materials provided with the distribution.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE
  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <stdio.h>
#include <string.h>
#include "zz.h"

_Static_assert(sizeof(word_t) == sizeof(uintptr_t), "limbs match the target width");
_Static_assert(sizeof(sword_t) == sizeof(word_t), "signed limbs match unsigned limbs");
_Static_assert(sizeof(dword_t) == 2 * sizeof(word_t), "double limbs hold a full product");

#define CHECK(condition) do { \
   if (!(condition)) { \
      fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #condition); \
      return 1; \
   } \
} while (0)

int main(void)
{
   word_t high = WORD(1) << (WORD_BITS - 1);
   word_t words[4] = { WORD(1), high, ~(word_t) 0, WORD(0) };
   const char * values[] = {
      "0", "4294967296", "9223372036854775808", "18446744073709551615",
      "340282366920938463463374607431768211455", "-9223372036854775808"
   };
   size_t i;
   zz_t a, b, g, u, v, x, y;

   CHECK(high_zero_bits(high) == 0);
   CHECK(low_zero_bits(high) == WORD_BITS - 1);
   CHECK(popcount_bits(high) == 1);
   CHECK(popcount_bits(~(word_t) 0) == WORD_BITS);
#if WORD_BITS == 64
   CHECK(high_zero_bits(UINT64_C(0xffffffff00000000)) == 0);
   CHECK(low_zero_bits(UINT64_C(0xffffffff00000000)) == 32);
   CHECK(popcount_bits(UINT64_C(0xffffffff00000000)) == 32);
#endif
   nn_copyd(words + 1, words, 3);
   CHECK(words[1] == 1 && words[2] == high && words[3] == ~(word_t) 0);

   zz_init(a); zz_init(b); zz_init(g); zz_init(u);
   zz_init(v); zz_init(x); zz_init(y);
   for (i = 0; i < sizeof(values) / sizeof(values[0]); i++)
   {
      char * text;
      CHECK(zz_set_str(a, values[i]) == strlen(values[i]));
      text = zz_get_str(a);
      CHECK(strcmp(text, values[i]) == 0);
      bsdnt_free(text);
   }

   zz_set_str(a, "123456789012345678901234567890");
   zz_set_str(b, "9876543210987654321");
   zz_xgcd(g, u, v, a, b);
   CHECK(zz_cmpi(g, 9) == 0);
   zz_mul(x, u, a); zz_mul(y, v, b); zz_add(x, x, y);
   CHECK(zz_equal(x, g));
   zz_clear(a); zz_clear(b); zz_clear(g); zz_clear(u);
   zz_clear(v); zz_clear(x); zz_clear(y);
   puts("width portability: PASS");
   return 0;
}
