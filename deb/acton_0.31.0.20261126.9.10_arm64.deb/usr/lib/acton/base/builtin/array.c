static struct B_ValueError B_array_element_type_error =
    STATIC_EXCEPTION(B_ValueError, "array element type must be int or float");
static struct B_ValueError B_array_negative_length_error =
    STATIC_EXCEPTION(B_ValueError, "array length must be non-negative");
static struct B_MemoryError B_array_too_large_error =
    STATIC_EXCEPTION(B_MemoryError, "array is too large");
static struct B_MemoryError B_array_representation_too_large_error =
    STATIC_EXCEPTION(B_MemoryError, "array is too large to represent");
static struct B_MemoryError B_array_allocation_failed_error =
    STATIC_EXCEPTION(B_MemoryError, "memory allocation failed");
static struct B_ValueError B_array_serialization_too_large_error =
    STATIC_EXCEPTION(B_ValueError, "array is too large to serialize");
static struct B_ValueError B_array_invalid_serialized_error =
    STATIC_EXCEPTION(B_ValueError, "invalid serialized array");

static enum B_array_kind B_array_kind_from_witness(B_ArrayElement wit) {
    if ((void *)wit->$class == (void *)&B_ArrayElementD_intG_methods)
        return B_ARRAY_INT;
    if ((void *)wit->$class == (void *)&B_ArrayElementD_floatG_methods)
        return B_ARRAY_FLOAT;
    RAISE_EXC(&B_array_element_type_error);
    return B_ARRAY_INT; // unreachable; keeps conservative C compilers happy
}

static void B_array_init_storage(B_array self, enum B_array_kind kind, int64_t length,
                                 $WORD initial) {
    if (length < 0)
        RAISE_EXC(&B_array_negative_length_error);
    if ((uint64_t)length > SIZE_MAX / sizeof(uint64_t))
        RAISE_EXC(&B_array_too_large_error);

    self->kind = kind;
    self->length = length;
    if (length == 0) {
        self->data = NULL;
        return;
    }

    size_t nbytes = (size_t)length * sizeof(uint64_t);
    // The --db restore initializes an array that an earlier pass allocated
    void *buf = acton_malloc_atomic(nbytes);
    self->data = buf;
    ACTON_WBAR(self, &self->data, buf);
    if (initial == B_None) {
        memset(self->data, 0, nbytes);
    } else if (kind == B_ARRAY_INT) {
        int64_t value = fromB_int((B_int)initial);
        int64_t *data = self->data;
        for (int64_t i = 0; i < length; i++)
            data[i] = value;
    } else {
        double value = fromB_float((B_float)initial);
        double *data = self->data;
        for (int64_t i = 0; i < length; i++)
            data[i] = value;
    }
}

static int64_t B_array_checked_index(B_array self, int64_t index) {
    if (index < 0 || index >= self->length)
        RAISE(B_IndexError, index, actStrFromCString("array index out of range"));
    return index;
}

B_array B_arrayG_new(B_ArrayElement wit, int64_t length, $WORD initial) {
    B_array self = acton_malloc(sizeof(struct B_array));
    self->$class = &B_arrayG_methods;
    B_array_init_storage(self, B_array_kind_from_witness(wit), length, initial);
    return self;
}

B_NoneType B_arrayD___init__(B_array self, B_ArrayElement wit, int64_t length,
                            $WORD initial) {
    B_array_init_storage(self, B_array_kind_from_witness(wit), length, initial);
    return B_None;
}

bool B_arrayD___bool__(B_array self) {
    return self->length != 0;
}

B_str B_arrayD___str__(B_array self) {
    if (self->length > INT_MAX)
        RAISE_EXC(&B_array_representation_too_large_error);

    // $FORMAT allocates, and the array of parts is reached through parts,
    // so each store has a barrier.
    B_list parts = B_listD_new((int)self->length);
    if (self->kind == B_ARRAY_INT) {
        int64_t *data = self->data;
        for (int64_t i = 0; i < self->length; i++) {
            B_str s = $FORMAT("%lld", data[i]);
            ACTON_STORE(parts->data, parts->data[parts->length], s);
            parts->length++;
        }
    } else {
        double *data = self->data;
        for (int64_t i = 0; i < self->length; i++) {
            B_str s = $FORMAT("%g", data[i]);
            ACTON_STORE(parts->data, parts->data[parts->length], s);
            parts->length++;
        }
    }

    B_str bracketed = B_strD_join_par('[', parts, ']');
    return $FORMAT("[|%.*s|]", bracketed->nbytes - 2, bracketed->str + 1);
}

B_str B_arrayD___repr__(B_array self) {
    return B_arrayD___str__(self);
}

int64_t $arrayD_U__getitem_int(B_array self, int64_t index) {
    index = B_array_checked_index(self, index);
    return ((int64_t *)self->data)[index];
}

double $arrayD_U__getitem_float(B_array self, int64_t index) {
    index = B_array_checked_index(self, index);
    return ((double *)self->data)[index];
}

B_NoneType $arrayD_U__setitem_int(B_array self, int64_t index, int64_t value) {
    index = B_array_checked_index(self, index);
    ((int64_t *)self->data)[index] = value;
    return B_None;
}

B_NoneType $arrayD_U__setitem_float(B_array self, int64_t index, double value) {
    index = B_array_checked_index(self, index);
    ((double *)self->data)[index] = value;
    return B_None;
}

int64_t $arrayD_U__len(B_array self) {
    return self->length;
}

int64_t B_arrayD___len__(B_array self) {
    return self->length;
}

$WORD B_arrayD___getitem__(B_array self, int64_t index) {
    if (self->kind == B_ARRAY_INT)
        return toB_int($arrayD_U__getitem_int(self, index));
    return toB_float($arrayD_U__getitem_float(self, index));
}

B_NoneType B_arrayD___setitem__(B_array self, int64_t index, $WORD value) {
    if (self->kind == B_ARRAY_INT)
        return $arrayD_U__setitem_int(self, index, fromB_int((B_int)value));
    return $arrayD_U__setitem_float(self, index, ((B_float)value)->val);
}

// Protocol adapters retain boxed values at the polymorphic boundary; concrete
// array indexing is lowered to the raw workers above by the compiler.
$WORD B_MutIndexedD_arrayD___getitem__(B_MutIndexedD_array wit, B_array self,
                                      B_int index) {
    return B_arrayD___getitem__(self, index->val);
}

B_NoneType B_MutIndexedD_arrayD___setitem__(B_MutIndexedD_array wit,
                                            B_array self, B_int index,
                                            $WORD value) {
    return B_arrayD___setitem__(self, index->val, value);
}

// Container[A] ////////////////////////////////////////////////////////////////////////////////////

bool $arrayD_U__next_int(B_IteratorD_array self, int64_t *out) {
    if (self->next >= self->src->length)
        return false;
    *out = ((int64_t *)self->src->data)[self->next++];
    return true;
}

bool $arrayD_U__next_float(B_IteratorD_array self, double *out) {
    if (self->next >= self->src->length)
        return false;
    *out = ((double *)self->src->data)[self->next++];
    return true;
}

static bool B_IteratorD_arrayD_next(B_IteratorD_array self, $WORD *out) {
    if (self->src->kind == B_ARRAY_INT) {
        int64_t value;
        if (!$arrayD_U__next_int(self, &value))
            return false;
        *out = toB_int(value);
    } else {
        double value;
        if (!$arrayD_U__next_float(self, &value))
            return false;
        *out = toB_float(value);
    }
    return true;
}

B_IteratorD_array B_IteratorD_arrayG_new(B_array src) {
    return $NEW(B_IteratorD_array, src);
}

void B_IteratorD_arrayD_init(B_IteratorD_array self, B_array src) {
    self->src = src;
    self->next = 0;
}

B_Iterator $arrayD_U_iter_init(B_IteratorD_array iter, B_array src) {
    iter->$class = &B_IteratorD_arrayG_methods;
    B_IteratorD_arrayD_init(iter, src);
    return (B_Iterator)iter;
}

bool B_IteratorD_arrayD_bool(B_IteratorD_array self) {
    return true;
}

B_str B_IteratorD_arrayD_str(B_IteratorD_array self) {
    return $FORMAT("<array iterator object at %p>", self);
}

void B_IteratorD_arrayD_serialize(B_IteratorD_array self, $Serial$state state) {
    $step_serialize(self->src, state);
    $step_serialize(toB_int(self->next), state);
}

B_IteratorD_array B_IteratorD_arrayD_deserialize(B_IteratorD_array self,
                                                  $Serial$state state) {
    if (!self)
        self = $DNEW(B_IteratorD_array, state);
    ACTON_STORE(self, self->src, (B_array)$step_deserialize(state));
    self->next = fromB_int((B_int)$step_deserialize(state));
    return self;
}

struct B_IteratorD_arrayG_class B_IteratorD_arrayG_methods = {
    "B_IteratorD_array", UNASSIGNED, ($SuperG_class)&B_IteratorG_methods,
    B_IteratorD_arrayD_init, B_IteratorD_arrayD_serialize,
    B_IteratorD_arrayD_deserialize, B_IteratorD_arrayD_bool,
    B_IteratorD_arrayD_str, B_IteratorD_arrayD_str,
    B_IteratorD_arrayD_next
};

B_Iterator B_ContainerD_arrayD___iter__(B_ContainerD_array wit, B_array self) {
    return (B_Iterator)B_IteratorD_arrayG_new(self);
}

B_array B_ContainerD_arrayD___fromiter__(B_ContainerD_array wit,
                                         B_Iterable iter_wit, $WORD iterable) {
    B_array result = B_arrayG_new(wit->W_ArrayElementD_AD_ContainerD_array, 0,
                                  B_None);
    if (!iter_wit || !iterable)
        return result;

    // Grow the final unboxed buffer itself.  Previously this operation first
    // retained every boxed input in a list and only then allocated the array.
    // A producer may still yield boxed values through Iterable[A], but each is
    // now unboxed immediately and can become garbage before the next value.
    size_t capacity = 0;
    B_Iterator it = iter_wit->$class->__iter__(iter_wit, iterable);
    $WORD value;
    while (it->$class->__next__(it, &value)) {
        if ((uint64_t)result->length >= SIZE_MAX / sizeof(uint64_t) ||
            result->length == INT64_MAX)
            RAISE_EXC(&B_array_too_large_error);

        size_t needed = (size_t)result->length + 1;
        if (needed > capacity) {
            const size_t max_capacity = SIZE_MAX / sizeof(uint64_t);
            size_t new_capacity = capacity == 0 ? 16 : capacity;
            while (new_capacity < needed) {
                if (new_capacity > max_capacity / 2) {
                    new_capacity = max_capacity;
                    break;
                }
                new_capacity *= 2;
            }
            size_t nbytes = new_capacity * sizeof(uint64_t);
            result->data = acton_realloc_atomic(result->data, nbytes);
            if (result->data == NULL)
                RAISE_EXC(&B_array_allocation_failed_error);
            capacity = new_capacity;
        }

        if (result->kind == B_ARRAY_INT)
            ((int64_t *)result->data)[result->length] = fromB_int((B_int)value);
        else
            ((double *)result->data)[result->length] = fromB_float((B_float)value);
        result->length++;
    }
    return result;
}

int64_t B_ContainerD_arrayD___len__(B_ContainerD_array wit, B_array self) {
    return self->length;
}

bool B_ContainerD_arrayD___contains__(B_ContainerD_array wit, B_array self,
                                      $WORD value) {
    B_Eq eq_wit = wit->W_EqD_AD_ContainerD_array;
    for (int64_t i = 0; i < self->length; i++) {
        if (eq_wit->$class->__eq__(eq_wit, B_arrayD___getitem__(self, i), value))
            return true;
    }
    return false;
}

bool B_ContainerD_arrayD___containsnot__(B_ContainerD_array wit, B_array self,
                                         $WORD value) {
    return !B_ContainerD_arrayD___contains__(wit, self, value);
}

void B_arrayD___serialize__(B_array self, $Serial$state state) {
    if (self->length > INT_MAX - 2)
        RAISE_EXC(&B_array_serialization_too_large_error);

    // ARRAY_ID is above ITEM_ID, so the generic serializer has already emitted
    // the object header and installed self in its back-reference table.  This
    // row contains only array-specific payload, like iset/ilist/idict payloads.
    $ROW row = $add_header(ARRAY_ID, (int)self->length + 2, state);
    row->blob[0] = ($WORD)(intptr_t)self->kind;
    row->blob[1] = ($WORD)(intptr_t)self->length;
    if (self->length > 0)
        memcpy(&row->blob[2], self->data, (size_t)self->length * sizeof(uint64_t));
}

B_array B_arrayD___deserialize__(B_array self, $Serial$state state) {
    // The generic deserializer consumed the object header before dispatching
    // here.  Register the object at that row before consuming its payload.
    if (!self) {
        self = acton_malloc(sizeof(struct B_array));
        self->$class = &B_arrayG_methods;
        B_dictD_setitem(state->done, toB_int(state->row_no - 1), self);
    }

    $ROW row = state->row;
    if (!row || row->class_id != ARRAY_ID || row->blob_size < 2)
        RAISE_EXC(&B_array_invalid_serialized_error);
    state->row = row->next;
    state->row_no++;

    enum B_array_kind kind = (enum B_array_kind)(intptr_t)row->blob[0];
    int64_t length = (int64_t)(intptr_t)row->blob[1];
    if ((kind != B_ARRAY_INT && kind != B_ARRAY_FLOAT) ||
        length < 0 || length > INT_MAX - 2 || row->blob_size != length + 2)
        RAISE_EXC(&B_array_invalid_serialized_error);

    self->$class = &B_arrayG_methods;
    B_array_init_storage(self, kind, length, B_None);
    if (length > 0)
        memcpy(self->data, &row->blob[2], (size_t)length * sizeof(uint64_t));
    return self;
}
