B_list B_mk_list(int len, ...) {
    B_list res = B_listD_new(len);
    res->length = len;
    // The array is reached through res, not held in a local since its
    // allocation
    $WORD *data = res->data;
    ACTON_WBAR_RANGE(data, data, len * sizeof($WORD));
    va_list args;
    va_start(args, len);
    for (int i = 0; i < len; i++)
        data[i] = va_arg(args, $WORD);
    return res;
}

B_set B_mk_set(int len, B_Hashable w,...) {
    B_set res = B_setG_new(w, NULL, NULL);
    va_list args;
    va_start(args, w);
    for (int i=0; i < len; i++) {
        $WORD elem = va_arg(args, $WORD);
        B_set_add_entry(res, elem, B_hash(w, elem));
    }
    return res;
}

B_dict B_mk_dict(int len, B_Hashable w,...) {
    B_dict res = B_dictG_new(w, NULL, NULL);
    va_list args;
    va_start(args, w);
    for (int i=0; i < len; i++) {
        B_tuple t =  va_arg(args, B_tuple);
        B_dictD_setitem(res, t->components[0], t->components[1]);
    }
    return res;
}
