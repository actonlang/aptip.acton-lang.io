// THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
// OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
//
// Permission is hereby granted to use or copy this program
// for any purpose, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.

// A script to build and test the collector using Zig build system.
// This script matches `CMakeLists.txt` file logic as much as possible.

const builtin = @import("builtin");
const std = @import("std");

// The Zig version here should match that in file `build.zig.zon`.
const zig_min_required_version = "0.17.0";

// TODO: specify `PACKAGE_VERSION`.

// The version of the shared libraries.  These values should match the ones
// in `CMakeLists.txt` and `configure.ac` files.
const LIBCORD_SHARED_VERSION = "1.5.1";
const LIBGC_SHARED_VERSION = "1.5.3";
const LIBGCCPP_SHARED_VERSION = "1.5.0";

// Compared to the `cmake` script, some definitions and compiler options are
// hard-coded here, which is natural because `build.zig` is only built with
// the Zig build system and Zig ships with an embedded clang.
// As a consequence, we do not have to support lots of different compilers
// (a notable exception is msvc target which implies use of the corresponding
// native compiler).
// And, on the contrary, we know exactly what we get and thus we can align on
// clang's capabilities rather than having to discover compiler capabilities.
// Similarly, since Zig ships `libc` headers for many platforms, we can, with
// the knowledge of the platform, determine what capabilities should be
// enabled or not.

comptime {
    const required_ver = std.SemanticVersion.parse(zig_min_required_version) catch unreachable;
    if (builtin.zig_version.order(required_ver) == .lt) {
        @compileError(std.fmt.comptimePrint("Zig version {} does not meet the build requirement of {}", .{
            builtin.zig_version,
            required_ver,
        }));
    }
}

// The virtual dirty bits implementation used by the incremental and
// generational collection modes.
const DirtyTrackingBackend = enum {
    // Any of the implementations available for the target.
    auto,
    // Only the soft-dirty bits of Linux `/proc` (`SOFT_VDB`).
    soft_dirty,
    // Only Linux `userfaultfd` in the write-protect mode (`UFFDWP_VDB`).
    userfaultfd,
};

pub fn build(b: *std.Build) void {
    const optimize = b.standardOptimizeOption(.{});
    const target = b.standardTargetOptions(.{});
    const t = target.result;

    const default_enable_threads = !t.cpu.arch.isWasm(); // emscripten/wasi

    // Customize build by passing "-D<option_name>[=false]" in command line.
    const enable_cplusplus = b.option(bool, "enable_cplusplus", "C++ support") orelse false;
    const linkage = b.option(std.lang.LinkMode, "linkage", "Build shared libraries (otherwise static ones)") orelse .dynamic;
    const build_cord = b.option(bool, "build_cord", "Build cord library") orelse true;
    const cflags_extra = b.option([]const u8, "CFLAGS_EXTRA", "Extra user-defined cflags") orelse "";
    // TODO: support `enable_docs`
    const enable_threads = b.option(bool, "enable_threads", "Support threads") orelse default_enable_threads;
    const enable_parallel_mark = b.option(bool, "enable_parallel_mark", "Parallelize marking and free list construction") orelse true;
    const enable_thread_local_alloc = b.option(bool, "enable_thread_local_alloc", "Turn on thread-local allocation optimization") orelse true;
    const enable_rwlock = b.option(bool, "enable_rwlock", "Enable reader mode of the allocator lock") orelse false;
    const enable_throw_bad_alloc_library = b.option(bool, "enable_throw_bad_alloc_library", "Turn on C++ gctba library build") orelse true;
    const enable_gcj_support = b.option(bool, "enable_gcj_support", "Support for gcj") orelse true;
    const enable_sigrt_signals = b.option(bool, "enable_sigrt_signals", "Use SIGRTMIN-based signals for thread suspend/resume") orelse false;
    const enable_valgrind_tracking = b.option(bool, "enable_valgrind_tracking", "Support tracking GC_malloc and friends for heap profiling tools") orelse false;
    const enable_gc_debug = b.option(bool, "enable_gc_debug", "Support for pointer back-tracing") orelse false;
    const enable_gc_dump = b.option(bool, "enable_gc_dump", "Enable GC_dump and similar debugging facility") orelse true;
    const enable_java_finalization = b.option(bool, "enable_java_finalization", "Support for java finalization") orelse true;
    const enable_atomic_uncollectable = b.option(bool, "enable_atomic_uncollectable", "Support for atomic uncollectible allocation") orelse true;
    const enable_redirect_malloc = b.option(bool, "enable_redirect_malloc", "Redirect malloc and friends to collector routines") orelse false;
    const enable_uncollectable_redirection = b.option(bool, "enable_uncollectable_redirection", "Redirect to uncollectible malloc instead of garbage-collected one") orelse false;
    const enable_disclaim = b.option(bool, "enable_disclaim", "Support alternative finalization interface") orelse true;
    const enable_dynamic_pointer_mask = b.option(bool, "enable_dynamic_pointer_mask", "Support pointer mask/shift set at runtime") orelse false;
    const enable_large_config = b.option(bool, "enable_large_config", "Optimize for large heap or root set") orelse false;
    const enable_mark_bits = b.option(bool, "enable_mark_bits", "Use mark bits instead of mark bytes even if parallel marking") orelse false;
    const enable_mark_bit_per_obj = b.option(bool, "enable_mark_bit_per_obj", "Allocate a mark bit (or byte) per object instead of per granule") orelse false;
    const page_hash_table_log2 = b.option(u8, "page_hash_table_log2", "Log2 of the number of page hash table entries (0 keeps the default)") orelse 0;
    const dirty_tracking_backend = b.option(DirtyTrackingBackend, "dirty_tracking_backend", "Virtual dirty bits implementation used by incremental collection") orelse .auto;
    const enable_mprotect_vdb = b.option(bool, "enable_mprotect_vdb", "Build in the mprotect-based virtual dirty bits implementation") orelse true;
    const heap_growth_divisor = b.option(u32, "heap_growth_divisor", "Allow a heap expansion up to the heap size divided by this value (0 keeps the maximum heap increment fixed)") orelse 0;
    const block_size = b.option(u32, "block_size", "Heap block size in bytes, a power of two in range 4096..65536 (0 keeps the default)") orelse 0;
    const alloc_budget_percent = b.option(u32, "alloc_budget_percent", "Collect after allocating this percentage of the live data size (0 keeps the policy based on the free space divisor)") orelse 0;
    const enable_mark_range_stealing = b.option(bool, "enable_mark_range_stealing", "Let parallel markers claim ranges of the global mark stack by CAS") orelse false;
    const enable_end_padding = b.option(bool, "enable_end_padding", "Pad objects so that a pointer just past the end of an object keeps it alive") orelse true;
    const bytes_per_marker = b.option(u64, "bytes_per_marker", "Mark a mark phase by one marker per this many bytes it is estimated to scan (0 lets every parallel mark phase use all the markers)") orelse 0;
    const initial_mark_stack_size = b.option(u32, "initial_mark_stack_size", "Initial number of entries in the global mark stack, a power of two, 4096 at least (0 keeps the default of HBLKSIZE entries)") orelse 0;
    const tl_refill_max = b.option(u32, "tl_refill_max", "Maximum number of heap blocks taken by a single refill of a thread-local free list, in range 1..32 (unset keeps the default of 1)");
    const tiny_freelists = b.option(u32, "tiny_freelists", "Number of tiny (thread-local) free lists per kind, i.e. objects of up to this number minus one granules use them (0 keeps the default)") orelse 0;
    const disable_realloc_free = b.option(bool, "disable_realloc_free", "Leave a small collectable object moved by GC_realloc to the collector instead of freeing it") orelse false;
    const disable_thread_local_warmup = b.option(bool, "disable_thread_local_warmup", "Let a thread use its thread-local free list of each size from its first allocation of that size") orelse false;
    const enable_gc_assertions = b.option(bool, "enable_gc_assertions", "Enable collector-internal assertion checking") orelse false;
    const enable_mmap = b.option(bool, "enable_mmap", "Use mmap instead of sbrk to expand the heap") orelse false;
    const enable_munmap = b.option(bool, "enable_munmap", "Return page to the OS if empty for N collections") orelse true;
    const enable_dynamic_loading = b.option(bool, "enable_dynamic_loading", "Enable tracing of dynamic library data roots") orelse true;
    const enable_register_main_static_data = b.option(bool, "enable_register_main_static_data", "Perform the initial guess of data root sets") orelse true;
    const enable_checksums = b.option(bool, "enable_checksums", "Report erroneously cleared dirty bits") orelse false;
    const enable_werror = b.option(bool, "enable_werror", "Pass -Werror to the C compiler (treat warnings as errors)") orelse false;
    const enable_single_obj_compilation = b.option(bool, "enable_single_obj_compilation", "Compile all libgc source files into single .o") orelse false;
    const disable_single_obj_compilation = b.option(bool, "disable_single_obj_compilation", "Compile each libgc source file independently") orelse false;
    const enable_handle_fork = b.option(bool, "enable_handle_fork", "Attempt to ensure a usable collector after fork()") orelse true;
    const disable_handle_fork = b.option(bool, "disable_handle_fork", "Prohibit installation of pthread_atfork() handlers") orelse false;
    // TODO: support `enable_emscripten_asyncify`
    const install_headers = b.option(bool, "install_headers", "Install header and pkg-config metadata files") orelse true;
    // TODO: support `with_libatomic_ops`, `without_libatomic_ops`

    var source_files: std.ArrayListUnmanaged([]const u8) = .empty;
    defer source_files.deinit(b.allocator);
    var flags: std.ArrayListUnmanaged([]const u8) = .empty;
    defer flags.deinit(b.allocator);

    // Always enabled.
    flags.append(b.allocator, "-D ALL_INTERIOR_POINTERS") catch unreachable;
    flags.append(b.allocator, "-D NO_EXECUTE_PERMISSION") catch unreachable;

    // Output all warnings.
    flags.appendSlice(b.allocator, &.{
        "-Wall",
        "-Wextra",
        "-Wpedantic",
    }) catch unreachable;

    // Disable MS `crt` security warnings reported e.g. for `getenv`, `strcpy`.
    if (t.abi == .msvc) {
        flags.append(b.allocator, "-D _CRT_SECURE_NO_DEPRECATE") catch unreachable;
    }

    source_files.appendSlice(b.allocator, &.{
        "allchblk.c",
        "alloc.c",
        "blacklst.c",
        "dbg_mlc.c",
        "dyn_load.c",
        "finalize.c",
        "headers.c",
        "mach_dep.c",
        "malloc.c",
        "mallocx.c",
        "mark.c",
        "mark_rts.c",
        "misc.c",
        "new_hblk.c",
        "os_dep.c",
        "ptr_chck.c",
        "reclaim.c",
        "typd_mlc.c",
    }) catch unreachable;

    if (enable_threads) {
        flags.append(b.allocator, "-D GC_THREADS") catch unreachable;
        if (enable_parallel_mark) {
            flags.append(b.allocator, "-D PARALLEL_MARK") catch unreachable;
        }
        if (enable_thread_local_alloc) {
            flags.append(b.allocator, "-D THREAD_LOCAL_ALLOC") catch unreachable;
            source_files.appendSlice(b.allocator, &.{
                "specific.c",
                "thread_local_alloc.c",
            }) catch unreachable;
        }
        if (t.os.tag != .windows) { // assume `pthreads`
            // TODO: support cygwin when supported by zig
            // Zig comes with clang which supports GCC atomic intrinsics.
            flags.append(b.allocator, "-D GC_BUILTIN_ATOMIC") catch unreachable;
            // TODO: define and use `THREADDLLIBS_LIST`
            source_files.appendSlice(b.allocator, &.{
                "gc_dlopen.c",
                "pthread_start.c",
                "pthread_support.c",
            }) catch unreachable;
            if (t.os.tag.isDarwin()) {
                source_files.append(b.allocator, "darwin_stop_world.c") catch unreachable;
            } else {
                source_files.append(b.allocator, "pthread_stop_world.c") catch unreachable;
            }
            // Common defines for POSIX platforms.
            flags.append(b.allocator, "-D _REENTRANT") catch unreachable;
            // TODO: some targets might need `_PTHREADS` defined too.
            // Message for clients: Explicit `GC_INIT()` calls may be required.
            if (enable_handle_fork and !disable_handle_fork) {
                flags.append(b.allocator, "-D HANDLE_FORK") catch unreachable;
            }
        } else {
            // Assume the GCC atomic intrinsics are supported.
            flags.append(b.allocator, "-D GC_BUILTIN_ATOMIC") catch unreachable;
            flags.append(b.allocator, "-D EMPTY_GETENV_RESULTS") catch unreachable;
            source_files.appendSlice(b.allocator, &.{
                // Add `pthread_start.c` file just in case client defines
                // `GC_WIN32_PTHREADS` macro.
                "pthread_start.c",
                "pthread_support.c",
                "win32_threads.c",
            }) catch unreachable;
        }
    }

    // TODO: define/use `NEED_LIB_RT`

    if (disable_handle_fork) {
        // Ignore `enable_handle_fork` as its default value is true.
        flags.append(b.allocator, "-D NO_HANDLE_FORK") catch unreachable;
    }

    if (enable_gcj_support) {
        flags.append(b.allocator, "-D GC_GCJ_SUPPORT") catch unreachable;
        // TODO: do not define `GC_ENABLE_SUSPEND_THREAD` on kFreeBSD
        // if `enable_thread_local_alloc` (a workaround for some bug).
        flags.append(b.allocator, "-D GC_ENABLE_SUSPEND_THREAD") catch unreachable;
        source_files.append(b.allocator, "gcj_mlc.c") catch unreachable;
    }

    if (enable_disclaim) {
        flags.append(b.allocator, "-D ENABLE_DISCLAIM") catch unreachable;
        source_files.append(b.allocator, "fnlz_mlc.c") catch unreachable;
    }

    if (enable_dynamic_pointer_mask) {
        flags.append(b.allocator, "-D DYNAMIC_POINTER_MASK") catch unreachable;
    }

    if (enable_java_finalization) {
        flags.append(b.allocator, "-D JAVA_FINALIZATION") catch unreachable;
    }

    if (enable_atomic_uncollectable) {
        flags.append(b.allocator, "-D GC_ATOMIC_UNCOLLECTABLE") catch unreachable;
    }

    if (enable_valgrind_tracking) {
        flags.append(b.allocator, "-D VALGRIND_TRACKING") catch unreachable;
    }

    if (enable_gc_debug) {
        flags.append(b.allocator, "-D DBG_HDRS_ALL") catch unreachable;
        flags.append(b.allocator, "-D KEEP_BACK_PTRS") catch unreachable;
        if (t.os.tag == .linux) {
            flags.append(b.allocator, "-D MAKE_BACK_GRAPH") catch unreachable;
            // TODO: do not define `SAVE_CALL_COUNT` for e2k
            flags.append(b.allocator, "-D SAVE_CALL_COUNT=8") catch unreachable;
            source_files.append(b.allocator, "backgraph.c") catch unreachable;
        }
    }

    if (!enable_gc_dump) {
        flags.append(b.allocator, "-D NO_DEBUGGING") catch unreachable;
    }
    if (optimize != .debug) {
        flags.append(b.allocator, "-D NDEBUG") catch unreachable;
    }

    if (enable_redirect_malloc) {
        flags.append(b.allocator, "-D REDIRECT_MALLOC") catch unreachable;
        if (enable_gc_debug) {
            // Instruct the collector to redefine `malloc`, `realloc` and
            // `free` to the debug variant of the corresponding collector
            // routines.
            flags.append(b.allocator, "-D REDIRECT_MALLOC_DEBUG") catch unreachable;
        }
        if (enable_uncollectable_redirection) {
            // Instruct the collector to redefine `malloc` to the relevant
            // uncollectible variant of `GC_malloc` routine.
            flags.append(b.allocator, "-D REDIRECT_MALLOC_UNCOLLECTABLE") catch unreachable;
        }
        if (t.os.tag == .windows) {
            flags.append(b.allocator, "-D REDIRECT_MALLOC_IN_HEADER") catch unreachable;
        } else {
            flags.append(b.allocator, "-D GC_USE_DLOPEN_WRAP") catch unreachable;
        }
    } else if (enable_uncollectable_redirection) {
        @panic("Redirection of malloc is not enabled explicitly");
    }

    if (enable_mmap or enable_munmap) {
        flags.append(b.allocator, "-D USE_MMAP") catch unreachable;
    }

    if (enable_munmap) {
        flags.append(b.allocator, "-D USE_MUNMAP") catch unreachable;
    }

    if (!enable_dynamic_loading) {
        flags.append(b.allocator, "-D IGNORE_DYNAMIC_LOADING") catch unreachable;
    }

    if (!enable_register_main_static_data) {
        flags.append(b.allocator, "-D GC_DONT_REGISTER_MAIN_STATIC_DATA") catch unreachable;
    }

    if (enable_large_config) {
        flags.append(b.allocator, "-D LARGE_CONFIG") catch unreachable;
    }

    if (enable_mark_bits) {
        flags.append(b.allocator, "-D USE_MARK_BITS") catch unreachable;
    }

    if (enable_mark_bit_per_obj) {
        flags.append(b.allocator, "-D MARK_BIT_PER_OBJ") catch unreachable;
    }

    if (page_hash_table_log2 != 0) {
        if (page_hash_table_log2 > 30) {
            @panic("page_hash_table_log2 should be in range 1..30 (or 0 for the default)");
        }
        flags.append(b.allocator, b.fmt("-D LOG_PHT_ENTRIES={d}", .{page_hash_table_log2})) catch unreachable;
    }

    switch (dirty_tracking_backend) {
        .auto => {},
        .soft_dirty => {
            if (t.os.tag != .linux) {
                @panic("Soft-dirty bits are supported only on Linux");
            }
            // Exclude the other implementations, so that the collector does
            // not fall back to any of them silently.
            flags.append(b.allocator, "-D NO_MPROTECT_VDB") catch unreachable;
            flags.append(b.allocator, "-D NO_UFFDWP_VDB") catch unreachable;
            flags.append(b.allocator, "-D SOFT_VDB") catch unreachable;
        },
        .userfaultfd => {
            const glibc_version = if (t.os.tag == .linux and t.abi.isGnu())
                t.os.versionRange().gnuLibCVersion()
            else
                null;
            const supported_arch = switch (t.cpu.arch) {
                .aarch64, .x86, .x86_64 => true,
                else => false,
            };
            if (!supported_arch or glibc_version == null or glibc_version.?.order(.{ .major = 2, .minor = 34, .patch = 0 }) == .lt) {
                @panic("Userfaultfd write-protect mode is supported only on Linux/aarch64, x86 and x86_64 with glibc 2.34 or later");
            }
            if (!enable_threads) {
                @panic("Userfaultfd write-protect mode assumes multi-threading support");
            }
            if (enable_redirect_malloc) {
                @panic("Userfaultfd write-protect mode is incompatible with redirection of malloc");
            }
            // `UFFDWP_VDB` is defined by default for such targets, it takes
            // precedence over `SOFT_VDB`; exclude only the fallback.
            flags.append(b.allocator, "-D NO_MPROTECT_VDB") catch unreachable;
        },
    }
    if (!enable_mprotect_vdb and dirty_tracking_backend == .auto) {
        // The other choices of the backend exclude it already.
        flags.append(b.allocator, "-D NO_MPROTECT_VDB") catch unreachable;
    }

    if (heap_growth_divisor != 0) {
        flags.append(b.allocator, b.fmt("-D GC_HEAP_GROWTH_DIVISOR={d}", .{heap_growth_divisor})) catch unreachable;
    }

    if (block_size != 0) {
        if (block_size < 4096 or block_size > 65536 or !std.math.isPowerOfTwo(block_size)) {
            @panic("block_size should be a power of two in range 4096..65536 (or 0 for the default)");
        }
        if (block_size > 32768 and enable_mark_bit_per_obj) {
            @panic("block_size bigger than 32768 is not supported with enable_mark_bit_per_obj");
        }
        // Keep the minimum and maximum heap increments (which are set in
        // heap blocks) in bytes the same as for 4 KB heap blocks, but make
        // the minimum increment 4 blocks at least.
        const min_incr_bytes = @as(u32, if (enable_large_config) 64 else 16) * 4096;
        const max_incr_bytes = @as(u32, if (enable_large_config) 4096 else 2048) * 4096;
        flags.append(b.allocator, b.fmt("-D HBLKSIZE={d}", .{block_size})) catch unreachable;
        flags.append(b.allocator, b.fmt("-D MINHINCR={d}", .{@max(4, min_incr_bytes / block_size)})) catch unreachable;
        flags.append(b.allocator, b.fmt("-D MAXHINCR={d}", .{max_incr_bytes / block_size})) catch unreachable;
    }

    if (alloc_budget_percent != 0) {
        flags.append(b.allocator, b.fmt("-D GC_ALLOC_BUDGET_PERCENT={d}", .{alloc_budget_percent})) catch unreachable;
    }

    if (enable_mark_range_stealing) {
        if (!enable_threads or !enable_parallel_mark) {
            @panic("Mark stack range stealing assumes parallel marking support");
        }
        flags.append(b.allocator, "-D STEAL_MARK_STACK_RANGES") catch unreachable;
    }

    if (!enable_end_padding) {
        flags.append(b.allocator, "-D DONT_ADD_BYTE_AT_END") catch unreachable;
    }

    if (bytes_per_marker != 0) {
        // The value should fit in `size_t` of the target.
        if (bytes_per_marker > std.math.shl(u64, 1, t.ptrBitWidth()) -% 1) {
            @panic("bytes_per_marker is too big for the target: it should fit in size_t");
        }
        flags.append(b.allocator, b.fmt("-D GC_BYTES_PER_MARKER={d}", .{bytes_per_marker})) catch unreachable;
    }

    if (initial_mark_stack_size != 0) {
        // A mark stack entry consists of two pointers; the size of the
        // mark stack in bytes should be a multiple of `HBLKSIZE`.
        const mark_stack_bytes = @as(u64, initial_mark_stack_size) * 2 * (t.ptrBitWidth() / 8);
        if (initial_mark_stack_size < 4096 or !std.math.isPowerOfTwo(initial_mark_stack_size) or mark_stack_bytes % (if (block_size != 0) block_size else 4096) != 0) {
            @panic("initial_mark_stack_size should be a power of two, 4096 at least, and the mark stack size in bytes should be a multiple of the heap block size (or 0 for the default)");
        }
        // The mark stack size in bytes should fit in `size_t` of the target.
        if (mark_stack_bytes > std.math.shl(u64, 1, t.ptrBitWidth()) -% 1) {
            @panic("initial_mark_stack_size is too big for the target: the mark stack size in bytes should fit in size_t");
        }
        flags.append(b.allocator, b.fmt("-D INITIAL_MARK_STACK_SIZE={d}", .{initial_mark_stack_size})) catch unreachable;
    }

    if (tiny_freelists != 0) {
        // The last tiny free list should be for small objects, i.e. of
        // `MAXOBJGRANULES` (`HBLKSIZE/2` bytes) at most.
        const granule_bytes = 2 * (t.ptrBitWidth() / 8);
        const max_tiny_freelists = (if (block_size != 0) block_size else 4096) / 2 / granule_bytes + 1;
        if (tiny_freelists < 2 or tiny_freelists > max_tiny_freelists) {
            std.debug.panic("tiny_freelists should be in range 2..{d} (or 0 for the default)", .{max_tiny_freelists});
        }
        flags.append(b.allocator, b.fmt("-D GC_TINY_FREELISTS={d}", .{tiny_freelists})) catch unreachable;
    }

    if (tl_refill_max) |n| {
        // The value should be in range 1..`MAX_TL_REFILL_BLOCKS` (32, see
        // `mallocx.c` file).
        if (n < 1 or n > 32) {
            @panic("tl_refill_max should be in range 1..32");
        }
        flags.append(b.allocator, b.fmt("-D GC_TL_REFILL_MAX={d}", .{n})) catch unreachable;
    }

    if (disable_realloc_free) {
        flags.append(b.allocator, "-D GC_REALLOC_NO_FREE") catch unreachable;
    }

    if (disable_thread_local_warmup) {
        if (!enable_threads or !enable_thread_local_alloc) {
            @panic("Skipping thread-local free list warm-up assumes thread-local allocation support");
        }
        flags.append(b.allocator, "-D GC_NO_THREAD_LOCAL_WARMUP") catch unreachable;
    }

    if (enable_gc_assertions) {
        flags.append(b.allocator, "-D GC_ASSERTIONS") catch unreachable;
    }

    if (enable_sigrt_signals) {
        if (!enable_threads) {
            @panic("SIGRTMIN-based signals assumes multi-threading support");
        }
        if (t.os.tag != .windows) {
            flags.append(b.allocator, "-D GC_USESIGRT_SIGNALS") catch unreachable;
        }
    }

    if (enable_rwlock) {
        if (!enable_threads) {
            @panic("Lock with reader mode assumes multi-threading support");
        }
        flags.append(b.allocator, "-D USE_RWLOCK") catch unreachable;
    }

    if (enable_checksums) {
        if (enable_munmap or enable_threads) {
            @panic("CHECKSUMS not compatible with USE_MUNMAP or threads");
        }
        flags.append(b.allocator, "-D CHECKSUMS") catch unreachable;
        source_files.append(b.allocator, "checksums.c") catch unreachable;
    }

    if (enable_werror) {
        flags.append(b.allocator, "-Werror") catch unreachable;
    }

    if (enable_single_obj_compilation or (linkage == .dynamic and !disable_single_obj_compilation)) {
        if (disable_single_obj_compilation) {
            @panic("disable/enable_single_obj_compilation are mutually exclusive");
        }
        source_files.clearAndFree(b.allocator);
        source_files.append(b.allocator, "extra/gc.c") catch unreachable;
        if (enable_threads and !t.os.tag.isDarwin() and t.os.tag != .windows) {
            flags.append(b.allocator, "-D GC_PTHREAD_START_STANDALONE") catch unreachable;
            source_files.append(b.allocator, "pthread_start.c") catch unreachable;
        }
    }

    // Add implementation of `backtrace` and `backtrace_symbols`.
    if (t.abi == .msvc) {
        source_files.append(b.allocator, "extra/msvc_dbg.c") catch unreachable;
    }

    // TODO: declare that the libraries do not refer to external symbols
    // if dynamic linkage.

    // `zig cc` supports this flag.
    flags.appendSlice(b.allocator, &.{
        // TODO: `-Wno-unused-command-line-argument`
        // Prevent "__builtin_return_address with nonzero argument is unsafe".
        "-Wno-frame-address",
    }) catch unreachable;

    if (linkage == .dynamic) {
        flags.append(b.allocator, "-D GC_DLL") catch unreachable;
        if (t.abi != .msvc) {
            // `zig cc` supports these flags.
            flags.append(b.allocator, "-D GC_VISIBILITY_HIDDEN_SET") catch unreachable;
            flags.append(b.allocator, "-fvisibility=hidden") catch unreachable;
        }
    } else {
        flags.append(b.allocator, "-D GC_NOT_DLL") catch unreachable;
        if (t.os.tag == .windows) {
            // Do not require the clients to link with `user32` system library.
            flags.append(b.allocator, "-D DONT_USE_USER32_DLL") catch unreachable;
        }
    }

    // Note: Zig uses clang which ships with these so, unless another
    // sysroot/libc, etc. headers location is pointed out, it is fine to
    // hard-code enable this.
    // `-U GC_MISSING_EXECINFO_H`
    // `-U GC_NO_SIGSETJMP`
    flags.append(b.allocator, "-D HAVE_SYS_TYPES_H") catch unreachable;

    if (t.abi != .msvc) {
        flags.append(b.allocator, "-D HAVE_UNISTD_H") catch unreachable;
    }

    const have_getcontext = !t.abi.isMusl() and t.os.tag != .windows;
    if (!have_getcontext) {
        flags.append(b.allocator, "-D NO_GETCONTEXT") catch unreachable;
    }

    if (!t.os.tag.isDarwin() and t.os.tag != .windows) {
        // `dl_iterate_phdr` exists (as a strong symbol).
        flags.append(b.allocator, "-D HAVE_DL_ITERATE_PHDR") catch unreachable;
        if (enable_threads) {
            // `pthread_sigmask` and `sigset_t` are available and needed.
            flags.append(b.allocator, "-D HAVE_PTHREAD_SIGMASK") catch unreachable;
        }
    }

    // Build with `GC_wcsdup` support (`wcslen` is available).
    flags.append(b.allocator, "-D GC_REQUIRE_WCSDUP") catch unreachable;

    // `pthread_setname_np`, if available, may have 1, 2 or 3 arguments.
    if (t.os.tag.isDarwin()) {
        flags.append(b.allocator, "-D HAVE_PTHREAD_SETNAME_NP_WITHOUT_TID") catch unreachable;
    } else if (enable_threads) {
        if (t.os.tag == .linux) {
            flags.append(b.allocator, "-D HAVE_PTHREAD_SETNAME_NP_WITH_TID") catch unreachable;
        } else {
            // TODO: support `HAVE_PTHREAD_SETNAME_NP_WITH_TID_AND_ARG`
            // and `HAVE_PTHREAD_SET_NAME_NP` targets.
        }
    }

    if (t.os.tag != .windows) {
        // Define to use `dladdr` function (used for debugging).
        flags.append(b.allocator, "-D HAVE_DLADDR") catch unreachable;
    }

    if (t.os.tag.isDarwin()) {
        // `clock_gettime` is available since macOS 10.12 and iOS 10, i.e.
        // on all Darwin targets supported by zig; otherwise, `clock` (the
        // processor time of all threads) is used to measure the elapsed time.
        flags.append(b.allocator, "-D HAVE_CLOCK_GETTIME") catch unreachable;
    }

    if (enable_cplusplus and enable_werror) {
        if (linkage == .dynamic and t.os.tag == .windows or t.abi == .msvc) {
            // Avoid "replacement operator new[] cannot be declared inline"
            // warnings.
            flags.append(b.allocator, "-Wno-inline-new-delete") catch unreachable;
        }
        // TODO: suppress "argument unused during compilation: -nostdinc++"
        // warning (as of zig 0.17).
        if (t.abi == .msvc) {
            flags.append(b.allocator, "-Wno-unused-command-line-argument") catch unreachable;
        }
    }

    // Extra user-defined flags (if any) to pass to the compiler.
    if (cflags_extra.len > 0) {
        // Split it up on a space and append each part to flags separately.
        var tokenizer = std.mem.tokenizeScalar(u8, cflags_extra, ' ');
        while (tokenizer.next()) |token| {
            flags.append(b.allocator, token) catch unreachable;
        }
    }

    const gc = b.addLibrary(.{
        .linkage = linkage,
        .name = "gc",
        .root_module = b.createModule(.{
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        }),
        .version = std.SemanticVersion.parse(LIBGC_SHARED_VERSION) catch unreachable,
    });
    gc.root_module.addCSourceFiles(.{
        .files = source_files.items,
        .flags = flags.items,
    });
    gc.root_module.addIncludePath(b.path("include"));
    if (linkage == .dynamic and t.abi == .msvc) {
        gc.root_module.linkSystemLibrary("user32", .{});
    }

    var gccpp: *std.Build.Step.Compile = undefined;
    var gctba: *std.Build.Step.Compile = undefined;
    if (enable_cplusplus) {
        const gccpp_version = std.SemanticVersion.parse(LIBGCCPP_SHARED_VERSION) catch unreachable;
        gccpp = b.addLibrary(.{
            .linkage = linkage,
            .name = "gccpp",
            .root_module = b.createModule(.{
                .target = target,
                .optimize = optimize,
            }),
            .version = gccpp_version,
        });
        gccpp.root_module.addCSourceFiles(.{
            .files = &.{
                "gc_badalc.cc",
                "gc_cpp.cc",
            },
            .flags = flags.items,
        });
        gccpp.root_module.addIncludePath(b.path("include"));
        gccpp.root_module.linkLibrary(gc);
        linkLibCpp(gccpp);
        if (enable_throw_bad_alloc_library) {
            // The same as `gccpp` but contains only `gc_badalc`.
            gctba = b.addLibrary(.{
                .linkage = linkage,
                .name = "gctba",
                .root_module = b.createModule(.{
                    .target = target,
                    .optimize = optimize,
                }),
                .version = gccpp_version,
            });
            gctba.root_module.addCSourceFiles(.{
                .files = &.{
                    "gc_badalc.cc",
                },
                .flags = flags.items,
            });
            gctba.root_module.addIncludePath(b.path("include"));
            gctba.root_module.linkLibrary(gc);
            linkLibCpp(gctba);
        }
    }

    var cord: *std.Build.Step.Compile = undefined;
    if (build_cord) {
        cord = b.addLibrary(.{
            .linkage = linkage,
            .name = "cord",
            .root_module = b.createModule(.{
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }),
            .version = std.SemanticVersion.parse(LIBCORD_SHARED_VERSION) catch unreachable,
        });
        cord.root_module.addCSourceFiles(.{
            .files = &.{
                "cord/cordbscs.c",
                "cord/cordprnt.c",
                "cord/cordxtra.c",
            },
            .flags = flags.items,
        });
        cord.root_module.addIncludePath(b.path("include"));
        cord.root_module.linkLibrary(gc);
    }

    if (install_headers) {
        installHeader(b, gc, "gc.h");
        installHeader(b, gc, "gc/gc.h");
        installHeader(b, gc, "gc/gc_backptr.h");
        installHeader(b, gc, "gc/gc_config_macros.h");
        installHeader(b, gc, "gc/gc_inline.h");
        installHeader(b, gc, "gc/gc_mark.h");
        installHeader(b, gc, "gc/gc_tiny_fl.h");
        installHeader(b, gc, "gc/gc_typed.h");
        installHeader(b, gc, "gc/gc_version.h");
        installHeader(b, gc, "gc/javaxfc.h");
        installHeader(b, gc, "gc/leak_detector.h");
        if (enable_cplusplus) {
            installHeader(b, gccpp, "gc_cpp.h");
            installHeader(b, gccpp, "gc/gc_allocator.h");
            installHeader(b, gccpp, "gc/gc_cpp.h");
            if (enable_throw_bad_alloc_library) {
                // The same headers as `gccpp` library has.
                installHeader(b, gctba, "gc_cpp.h");
                installHeader(b, gctba, "gc/gc_allocator.h");
                installHeader(b, gctba, "gc/gc_cpp.h");
            }
        }
        if (enable_disclaim) {
            installHeader(b, gc, "gc/gc_disclaim.h");
        }
        if (enable_gcj_support) {
            installHeader(b, gc, "gc/gc_gcj.h");
        }
        if (enable_threads) {
            installHeader(b, gc, "gc/gc_pthread_redirects.h");
        }
        if (build_cord) {
            installHeader(b, cord, "gc/cord.h");
            installHeader(b, cord, "gc/cord_pos.h");
            installHeader(b, cord, "gc/ec.h");
        }
        // TODO: compose and install `bdw-gc.pc` and `pkgconfig`.
    }

    b.installArtifact(gc);
    if (enable_cplusplus) {
        b.installArtifact(gccpp);
        if (enable_throw_bad_alloc_library) {
            b.installArtifact(gctba);
        }
    }
    if (build_cord) {
        b.installArtifact(cord);
    }

    // Note: the tests are built only if `test` step is requested.
    const test_step = b.step("test", "Run tests");
    addTest(b, gc, test_step, flags, "gctest", "tests/gctest.c");
    if (build_cord and !(linkage == .dynamic and t.abi == .msvc)) {
        // On Windows, the client code which uses `cord.dll` file
        // (like `cordtest.exe`) should not link the static C library
        // (`libcmt.lib` file), otherwise `FILE`-related functions
        // might not work (because own set of opened `FILE` instances
        // is maintained by each copy of the C library thus making
        // impossible to pass `FILE` pointer from `.exe` to `.dll` code).
        // TODO: as of zig 0.17, it is not possible to force linking
        // `msvcrt.lib` instead of `libcmt.lib` file.
        addTestExt(b, gc, test_step, flags, "cordtest", "cord/tests/cordtest.c", .{
            .lib2 = cord,
        });
        if (t.os.tag == .windows) {
            addTestExt(b, gc, test_step, flags, "de", "cord/tests/de.c", .{
                .filename2 = "cord/tests/de_win.c",
                .rc_filename = "cord/tests/de_win.rc",
                .lib2 = cord,
                .sysLibName = "gdi32",
                .sysLibName2 = "user32",
            });
        }
    }
    addTest(b, gc, test_step, flags, "allocbudgettest", "tests/allocbudget.c");
    // `cpucounttest` includes the collector source, thus it is not linked
    // with `gc` library.
    addTestExt(b, gc, test_step, flags, "cpucounttest", "tests/cpucount.c", .{
        .link_gc = false,
        .filename2 = if (t.abi == .msvc) "extra/msvc_dbg.c" else null,
        .sysLibName = if (linkage == .dynamic and t.abi == .msvc) "user32" else null,
    });
    addTest(b, gc, test_step, flags, "dbgfunctest", "tests/dbgfunc.c");
    addTest(b, gc, test_step, flags, "endpaddingtest", "tests/endpadding.c");
    // Likewise, `expandfailtest` includes the collector source.
    addTestExt(b, gc, test_step, flags, "expandfailtest", "tests/expandfail.c", .{
        .link_gc = false,
        .filename2 = if (t.abi == .msvc) "extra/msvc_dbg.c" else null,
        .sysLibName = if (linkage == .dynamic and t.abi == .msvc) "user32" else null,
    });
    addTest(b, gc, test_step, flags, "finalizemarktest", "tests/finalizemark.c");
    addTest(b, gc, test_step, flags, "heapgrowthtest", "tests/heapgrowth.c");
    addTest(b, gc, test_step, flags, "heaplimittest", "tests/heaplimit.c");
    addTest(b, gc, test_step, flags, "hugetest", "tests/huge.c");
    addTest(b, gc, test_step, flags, "leaktest", "tests/leak.c");
    addTest(b, gc, test_step, flags, "mallocmanytest", "tests/mallocmany.c");
    // Likewise, `markstackgrowthtest` includes the collector source.
    addTestExt(b, gc, test_step, flags, "markstackgrowthtest", "tests/markstackgrowth.c", .{
        .link_gc = false,
        .filename2 = if (t.abi == .msvc) "extra/msvc_dbg.c" else null,
        .sysLibName = if (linkage == .dynamic and t.abi == .msvc) "user32" else null,
    });
    addTest(b, gc, test_step, flags, "memaligntest", "tests/memalign.c");
    addTest(b, gc, test_step, flags, "middletest", "tests/middle.c");
    addTest(b, gc, test_step, flags, "realloctest", "tests/realloc.c");
    addTest(b, gc, test_step, flags, "reallocfreetest", "tests/reallocfree.c");
    // Likewise, `serialgrowthtest` includes the collector source.
    addTestExt(b, gc, test_step, flags, "serialgrowthtest", "tests/serialgrowth.c", .{
        .link_gc = false,
        .filename2 = if (t.abi == .msvc) "extra/msvc_dbg.c" else null,
        .sysLibName = if (linkage == .dynamic and t.abi == .msvc) "user32" else null,
    });
    addTest(b, gc, test_step, flags, "sizemaptest", "tests/sizemap.c");
    addTest(b, gc, test_step, flags, "smashtest", "tests/smash.c");
    addTest(b, gc, test_step, flags, "stopfunctest", "tests/stopfunc.c");
    // Likewise, `switchedstacktest` includes the collector source.
    addTestExt(b, gc, test_step, flags, "switchedstacktest", "tests/switchedstack.c", .{
        .link_gc = false,
        .filename2 = if (t.abi == .msvc) "extra/msvc_dbg.c" else null,
        .sysLibName = if (linkage == .dynamic and t.abi == .msvc) "user32" else null,
    });
    addTest(b, gc, test_step, flags, "typedtest", "tests/typed.c");
    // Likewise, `unmaptest` includes the collector source.
    addTestExt(b, gc, test_step, flags, "unmaptest", "tests/unmap.c", .{
        .link_gc = false,
        .filename2 = if (t.abi == .msvc) "extra/msvc_dbg.c" else null,
        .sysLibName = if (linkage == .dynamic and t.abi == .msvc) "user32" else null,
    });
    addTest(b, gc, test_step, flags, "untouchedtest", "tests/untouched.c");
    // TODO: build `staticrootstest` with `-D STATICROOTSLIB2`.
    addTestExt(b, gc, test_step, flags, "staticrootstest", "tests/staticroots.c", .{
        .filename2 = "tests/staticroots_lib.c",
    });
    if (enable_gc_debug) {
        addTest(b, gc, test_step, flags, "tracetest", "tests/trace.c");
    }
    if (enable_threads) {
        addTest(b, gc, test_step, flags, "atomicopstest", "tests/atomicops.c");
        if (t.os.tag != .windows) {
            addTest(b, gc, test_step, flags, "forktest", "tests/fork.c");
        }
        addTest(b, gc, test_step, flags, "initfromthreadtest", "tests/initfromthread.c");
        addTest(b, gc, test_step, flags, "markercounttest", "tests/markercount.c");
        addTest(b, gc, test_step, flags, "subthreadcreatetest", "tests/subthreadcreate.c");
        addTest(b, gc, test_step, flags, "threadleaktest", "tests/threadleak.c");
        addTest(b, gc, test_step, flags, "threadwarmuptest", "tests/threadwarmup.c");
        if (t.os.tag != .windows) {
            addTest(b, gc, test_step, flags, "threadcanceltest", "tests/threadcancel.c");
            addTest(b, gc, test_step, flags, "threadkeytest", "tests/threadkey.c");
        }
    }
    if (enable_cplusplus) {
        addTestExt(b, gc, test_step, flags, "cpptest", "tests/cpp.cc", .{
            .lib2 = gccpp,
        });
        if (enable_throw_bad_alloc_library) {
            addTestExt(b, gc, test_step, flags, "treetest", "tests/tree.cc", .{
                .lib2 = gctba,
            });
        }
    }
    if (enable_disclaim) {
        addTest(b, gc, test_step, flags, "disclaim_bench", "tests/disclaim_bench.c");
        addTest(b, gc, test_step, flags, "disclaimtest", "tests/disclaim.c");
        addTest(b, gc, test_step, flags, "weakmaptest", "tests/weakmap.c");
    }
}

fn linkLibCpp(lib: *std.Build.Step.Compile) void {
    const t = lib.rootModuleTarget();
    // TODO: workaround "compilation of libcxxabi failed" (as of zig 0.17).
    if (t.abi == .msvc) {
        lib.root_module.link_libc = true;
    } else {
        lib.root_module.link_libcpp = true;
    }
}

fn addTest(b: *std.Build, gc: *std.Build.Step.Compile, test_step: *std.Build.Step, flags: std.ArrayListUnmanaged([]const u8), testname: []const u8, filename: []const u8) void {
    addTestExt(b, gc, test_step, flags, testname, filename, .{});
}

fn addTestExt(b: *std.Build, gc: *std.Build.Step.Compile, test_step: *std.Build.Step, flags: std.ArrayListUnmanaged([]const u8), testname: []const u8, filename: []const u8, ext_args: struct {
    link_gc: bool = true,
    filename2: ?[]const u8 = null,
    rc_filename: ?[]const u8 = null,
    lib2: ?*std.Build.Step.Compile = null,
    sysLibName: ?[]const u8 = null,
    sysLibName2: ?[]const u8 = null,
}) void {
    const test_exe = b.addExecutable(.{
        .name = testname,
        .root_module = b.createModule(.{
            .optimize = gc.root_module.optimize.?,
            .target = gc.root_module.resolved_target.?,
            .link_libc = true,
        }),
    });
    test_exe.root_module.addCSourceFile(.{
        .file = b.path(filename),
        .flags = flags.items,
    });
    if (ext_args.filename2 != null) {
        test_exe.root_module.addCSourceFile(.{
            .file = b.path(ext_args.filename2.?),
            .flags = flags.items,
        });
    }
    if (ext_args.rc_filename != null) {
        test_exe.root_module.addWin32ResourceFile(.{
            .file = b.path(ext_args.rc_filename.?),
        });
    }
    test_exe.root_module.addIncludePath(b.path("include"));
    if (ext_args.link_gc) {
        test_exe.root_module.linkLibrary(gc);
    }
    if (ext_args.lib2 != null) {
        test_exe.root_module.linkLibrary(ext_args.lib2.?);
    }
    if (ext_args.sysLibName != null) {
        test_exe.root_module.linkSystemLibrary(ext_args.sysLibName.?, .{});
    }
    if (ext_args.sysLibName2 != null) {
        test_exe.root_module.linkSystemLibrary(ext_args.sysLibName2.?, .{});
    }
    const run_test_exe = b.addRunArtifact(test_exe);
    run_test_exe.setEnvironmentVariable("GC_PROMPT_DISABLED", "1");
    test_step.dependOn(&run_test_exe.step);
}

fn installHeader(b: *std.Build, lib: *std.Build.Step.Compile, hfile: []const u8) void {
    const src_path = b.pathJoin(&.{
        "include",
        hfile,
    });
    lib.installHeader(b.path(src_path), hfile);
}
