
#include "../rts/io.h"
#include "../rts/log.h"
#include "yyjson.h"

static struct B_ValueError jsonQ_float_out_of_range_error =
    STATIC_EXCEPTION(B_ValueError, "JSON floating-point number is out of range");
static struct B_ValueError jsonQ_root_not_object_error =
    STATIC_EXCEPTION(B_ValueError, "JSON root is not an object");
static struct B_ValueError jsonQ_root_not_array_error =
    STATIC_EXCEPTION(B_ValueError, "JSON root is not an array");

static void *my_malloc(void *ctx, size_t size) {
    return acton_malloc(size);
}

static void *my_realloc(void *ctx, void *ptr, size_t old_size, size_t size) {
    return acton_realloc(ptr, size);
}

static void my_free(void *ctx, void *ptr) {
    acton_free(ptr);
}


yyjson_alc acton_alc;

void jsonQ___ext_init__() {
    acton_alc.malloc = my_malloc;
    acton_alc.realloc = my_realloc;
    acton_alc.free = my_free;
}

static yyjson_mut_val *jsonQ_encode_bigint(yyjson_mut_doc *doc, B_bigint value, bool as_string) {
    char *number = get_str(&value->val);
    if (as_string)
        return yyjson_mut_str(doc, number);
    return yyjson_mut_raw(doc, number);
}

void jsonQ_encode_list_into(yyjson_mut_doc *doc, yyjson_mut_val *node, B_list data, bool bigint_as_string);
void jsonQ_encode_dict(yyjson_mut_doc *doc, yyjson_mut_val *node, B_dict data, bool bigint_as_string) {
    B_IteratorD_dict_items iter = $NEW(B_IteratorD_dict_items, data);
    B_tuple item;

    for (int i=0; i < data->numelements; i++) {
        $WORD next;
        iter->$class->__next__(iter, &next);
        item = (B_tuple)next;
        B_str name = (B_str)item->components[0];
        yyjson_mut_val *key = yyjson_mut_strn(doc, (char *)name->str, name->nbytes);
        B_value v = item->components[1];
        if (v) {
            switch (v->$class->$class_id) {
                case INT_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_sint(doc, fromB_int((B_int)v)));
                    break;
                case FLOAT_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_real(doc, fromB_float((B_float)v)));
                    break;
                case BOOL_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_bool(doc, fromB_bool((B_bool)v)));
                    break;
                case STR_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_strn(doc, (char *)fromB_str((B_str)v), ((B_str)v)->nbytes));
                    break;
                case BIGINT_ID:;
                    yyjson_mut_obj_add(node, key, jsonQ_encode_bigint(doc, (B_bigint)v, bigint_as_string));
                    break;
                case LIST_ID:;
                    yyjson_mut_val *l = yyjson_mut_arr(doc);
                    yyjson_mut_obj_add(node, key, l);
                    jsonQ_encode_list_into(doc, l, (B_list)v, bigint_as_string);
                    break;
                case DICT_ID:;
                    yyjson_mut_val *d = yyjson_mut_obj(doc);
                    yyjson_mut_obj_add(node, key, d);
                    jsonQ_encode_dict(doc, d, (B_dict)v, bigint_as_string);
                    break;
                case I8_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_sint(doc, ((B_i8)v)->val));
                    break;
                case I16_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_sint(doc, ((B_i16)v)->val));
                    break;
                case I32_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_sint(doc, ((B_i32)v)->val));
                    break;
                case I64_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_sint(doc, ((B_int)v)->val));
                    break;
                case U1_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_uint(doc, ((B_u1)v)->val));
                    break;
                case U8_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_uint(doc, ((B_u8)v)->val));
                    break;
                case U16_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_uint(doc, ((B_u16)v)->val));
                    break;
                case U32_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_uint(doc, ((B_u32)v)->val));
                    break;
                case U64_ID:;
                    yyjson_mut_obj_add(node, key, yyjson_mut_uint(doc, ((B_u64)v)->val));
                    break;
                default:;
                    // TODO: hmm, at least handle all builtin types? and that's it,
                    // maybe? like we really shouldn't accept user-defined types
                    // here, just throw an exception? or when we have unions, just
                    // accept union of the types we support
                    B_str message = B_TimesD_strD___add__(B_TimesD_strG_witness,
                        actStrFromCString("jsonQ_encode_dict: for key "), name);
                    RAISE(B_ValueError, B_TimesD_strD___add__(B_TimesD_strG_witness,
                        message, $FORMAT(" unknown type: %s", v->$class->$GCINFO)));
            }
        } else {
            yyjson_mut_obj_add(node, key, yyjson_mut_null(doc));
        }
    }
}

void jsonQ_encode_list_into(yyjson_mut_doc *doc, yyjson_mut_val *node, B_list data, bool bigint_as_string) {
    for (int i = 0; i < data->length; i++) {
        B_value v = data->data[i];
        if (v) {
            switch (v->$class->$class_id) {
                case INT_ID:;
                    yyjson_mut_arr_add_int(doc, node, fromB_int((B_int)v));
                    break;
                case FLOAT_ID:;
                    yyjson_mut_arr_add_real(doc, node, fromB_float((B_float)v));
                    break;
                case BOOL_ID:;
                    yyjson_mut_arr_add_bool(doc, node, fromB_bool((B_bool)v));
                    break;
                case STR_ID:;
                    yyjson_mut_arr_add_strn(doc, node, (char *)fromB_str((B_str)v), ((B_str)v)->nbytes);
                    break;
                case BIGINT_ID:;
                    yyjson_mut_arr_add_val(node, jsonQ_encode_bigint(doc, (B_bigint)v, bigint_as_string));
                    break;
                case LIST_ID:;
                    yyjson_mut_val *l = yyjson_mut_arr_add_arr(doc, node);
                    if (l) {
                        jsonQ_encode_list_into(doc, l, (B_list)v, bigint_as_string);
                    } else {
                        // TODO: raise exception
                    }
                    break;
                case DICT_ID:;
                    yyjson_mut_val *d = yyjson_mut_arr_add_obj(doc, node);
                    if (d) {
                        jsonQ_encode_dict(doc, d, (B_dict)v, bigint_as_string);
                    } else {
                        // TODO: raise exception
                    }
                    break;
                case I8_ID:;
                    yyjson_mut_arr_add_int(doc, node, ((B_i8)v)->val);
                    break;
                case I16_ID:;
                    yyjson_mut_arr_add_int(doc, node, ((B_i16)v)->val);
                    break;
                case I32_ID:;
                    yyjson_mut_arr_add_int(doc, node, ((B_i32)v)->val);
                    break;
                case I64_ID:;
                    yyjson_mut_arr_add_int(doc, node, ((B_int)v)->val);
                    break;
                case U1_ID:;
                    yyjson_mut_arr_add_uint(doc, node, ((B_u1)v)->val);
                    break;
                case U8_ID:;
                    yyjson_mut_arr_add_uint(doc, node, ((B_u8)v)->val);
                    break;
                case U16_ID:;
                    yyjson_mut_arr_add_uint(doc, node, ((B_u16)v)->val);
                    break;
                case U32_ID:;
                    yyjson_mut_arr_add_uint(doc, node, ((B_u32)v)->val);
                    break;
                case U64_ID:;
                    yyjson_mut_arr_add_uint(doc, node, ((B_u64)v)->val);
                    break;
                default:;
                    // TODO: hmm, at least handle all builtin types? and that's it,
                    // maybe? like we really shouldn't accept user-defined types
                    // here, just throw an exception? or when we have unions, just
                    // accept union of the types we support
                    RAISE(B_ValueError, $FORMAT("jsonQ_encode_list: unknown type: %s", v->$class->$GCINFO));
            }
        } else {
            yyjson_mut_arr_add_null(doc, node);
        }
    }
}

B_list jsonQ_decode_arr(yyjson_val *);

static B_value jsonQ_decode_integer(yyjson_val *val) {
    if (yyjson_is_raw(val)) {
        size_t len = yyjson_get_len(val);
        const char *raw = yyjson_get_raw(val);
        for (size_t i = 0; i < len; i++) {
            if (raw[i] == '.' || raw[i] == 'e' || raw[i] == 'E')
                RAISE_EXC(&jsonQ_float_out_of_range_error);
        }
        char *number = acton_malloc_atomic(len + 1);
        memcpy(number, raw, len);
        number[len] = '\0';
        return (B_value)toB_bigint2(number);
    }
    if (yyjson_get_subtype(val) == YYJSON_SUBTYPE_UINT) {
        uint64_t number = yyjson_get_uint(val);
        if (number > INT64_MAX)
            return (B_value)toB_u64(number);
        return (B_value)toB_int((int64_t)number);
    }
    return (B_value)toB_int(yyjson_get_sint(val));
}

B_dict jsonQ_decode_obj(yyjson_val *obj) {

    B_Hashable wit = (B_Hashable)B_HashableD_strG_witness;
    B_dict res = $NEW(B_dict, wit, NULL, NULL);
    yyjson_obj_iter iter;
    yyjson_obj_iter_init(obj, &iter);
    yyjson_val *key, *val;
    while ((key = yyjson_obj_iter_next(&iter))) {
        val = yyjson_obj_iter_get_val(key);
        B_str name = actStrFromCStringLengthCopy(yyjson_get_str(key), yyjson_get_len(key));

        switch (yyjson_get_type(val)) {
            case YYJSON_TYPE_NONE:;
                break;
            case YYJSON_TYPE_RAW:;
                B_dictD_setitem(res, wit, name, jsonQ_decode_integer(val));
                break;
            case YYJSON_TYPE_NULL:;
                B_dictD_setitem(res, wit, name, B_None);
                break;
            case YYJSON_TYPE_BOOL:;
                B_dictD_setitem(res, wit, name, toB_bool(yyjson_get_bool(val)));
                break;
            case YYJSON_TYPE_NUM:;
                switch (yyjson_get_subtype(val)) {
                    case YYJSON_SUBTYPE_UINT:;
                    case YYJSON_SUBTYPE_SINT:;
                        B_dictD_setitem(res, wit, name, jsonQ_decode_integer(val));
                        break;
                    case YYJSON_SUBTYPE_REAL:;
                        B_dictD_setitem(res, wit, name, to$float(yyjson_get_real(val)));
                        break;
                }
                break;
            case YYJSON_TYPE_STR:;
                B_dictD_setitem(res, wit, name, actStrFromCStringLengthCopy(yyjson_get_str(val), yyjson_get_len(val)));
                break;
            case YYJSON_TYPE_ARR:;
                B_list l = jsonQ_decode_arr(val);
                B_dictD_setitem(res, wit, name, l);
                break;
            case YYJSON_TYPE_OBJ:;
                B_dict d = jsonQ_decode_obj(val);
                B_dictD_setitem(res, wit, name, d);
                break;
            default:;
                // unreachable
                RAISE(B_ValueError, $FORMAT("jsonQ_encode_list: unknown type: %d", yyjson_get_type(val)));
        }
    }
    return res;
}

B_list jsonQ_decode_arr(yyjson_val *arr) {
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    B_list res = B_listG_new(NULL, NULL);
    yyjson_val *val;
    yyjson_arr_iter iter;
    yyjson_arr_iter_init(arr, &iter);
    while ((val = yyjson_arr_iter_next(&iter))) {
        switch (yyjson_get_type(val)) {
            case YYJSON_TYPE_NONE:
                break;
            case YYJSON_TYPE_RAW:;
                wit->$class->append(wit, res, jsonQ_decode_integer(val));
                break;
            case YYJSON_TYPE_NULL:;
                wit->$class->append(wit, res, B_None);
                break;
            case YYJSON_TYPE_BOOL:;
                wit->$class->append(wit, res, toB_bool(yyjson_get_bool(val)));
                break;
            case YYJSON_TYPE_NUM:;
                switch (yyjson_get_subtype(val)) {
                    case YYJSON_SUBTYPE_UINT:;
                    case YYJSON_SUBTYPE_SINT:;
                        wit->$class->append(wit, res, jsonQ_decode_integer(val));
                        break;
                    case YYJSON_SUBTYPE_REAL:;
                        wit->$class->append(wit, res, to$float(yyjson_get_real(val)));
                        break;
                }
                break;
            case YYJSON_TYPE_STR:;
                wit->$class->append(wit, res, actStrFromCStringLengthCopy(yyjson_get_str(val), yyjson_get_len(val)));
                break;
            case YYJSON_TYPE_ARR:;
                B_list l = jsonQ_decode_arr(val);
                wit->$class->append(wit, res, l);
                break;
            case YYJSON_TYPE_OBJ:;
                B_dict d = jsonQ_decode_obj(val);
                wit->$class->append(wit, res, d);
                break;
            default:;
                // TODO: just handle all types?
                RAISE(B_ValueError, $FORMAT("jsonQ_decode_arr: unknown type: %d", yyjson_get_type(val)));
        }
    }
    return res;
}

B_dict jsonQ__decode (B_str data) {
    // Read JSON and get root
    yyjson_read_err err;
    yyjson_doc *doc = yyjson_read_opts((char *)fromB_str(data), data->nbytes, YYJSON_READ_BIGNUM_AS_RAW, &acton_alc, &err);
    yyjson_val *root = yyjson_doc_get_root(doc);

    B_dict res = $NEW(B_dict,(B_Hashable)B_HashableD_strG_witness,NULL,NULL);
    // Iterate over the root object
    if (doc) {
        yyjson_val *obj = yyjson_doc_get_root(doc);
        if (yyjson_get_type(obj) != YYJSON_TYPE_OBJ) {
            yyjson_doc_free(doc);
            RAISE_EXC(&jsonQ_root_not_object_error);
        }
        res = jsonQ_decode_obj(obj);
    } else {
        char errmsg[1024];
        snprintf(errmsg, sizeof(errmsg), "JSON parsing error: %s (%u) at position %ld", err.msg, err.code, err.pos);
        RAISE(B_ValueError, actStrFromCStringCopy(errmsg));
    }

    yyjson_doc_free(doc);
    return res;
}

B_list jsonQ__decode_list (B_str data) {
    // Read JSON and get root
    yyjson_read_err err;
    yyjson_doc *doc = yyjson_read_opts((char *)fromB_str(data), data->nbytes, YYJSON_READ_BIGNUM_AS_RAW, &acton_alc, &err);
    if (!doc) {
        char errmsg[1024];
        snprintf(errmsg, sizeof(errmsg), "JSON parsing error: %s (%u) at position %ld", err.msg, err.code, err.pos);
        RAISE(B_ValueError, actStrFromCStringCopy(errmsg));
    }

    yyjson_val *root = yyjson_doc_get_root(doc);
    if (yyjson_get_type(root) != YYJSON_TYPE_ARR) {
        yyjson_doc_free(doc);
        RAISE_EXC(&jsonQ_root_not_array_error);
    }

    B_list res = jsonQ_decode_arr(root);
    yyjson_doc_free(doc);
    return res;
}

B_str jsonQ__encode (B_dict data, bool pretty, bool bigint_as_string) {
    // Create JSON document
    yyjson_mut_doc *doc = yyjson_mut_doc_new(&acton_alc);
    yyjson_mut_val *root = yyjson_mut_obj(doc);
    yyjson_mut_doc_set_root(doc, root);

    jsonQ_encode_dict(doc, root, data, bigint_as_string);

    yyjson_write_err err;
    int flags = 0;
    if (pretty)
        flags += YYJSON_WRITE_PRETTY;

    char *json = yyjson_mut_write_opts(doc, flags, &acton_alc, NULL, &err);
    //yyjson_doc_free(doc);
    return actStrFromCString(json);
}

B_str jsonQ__encode_list (B_list data, bool pretty, bool bigint_as_string) {
    // Create JSON document
    yyjson_mut_doc *doc = yyjson_mut_doc_new(&acton_alc);
    yyjson_mut_val *root = yyjson_mut_arr(doc);
    yyjson_mut_doc_set_root(doc, root);

    jsonQ_encode_list_into(doc, root, data, bigint_as_string);

    yyjson_write_err err;
    int flags = 0;
    if (pretty)
        flags += YYJSON_WRITE_PRETTY;

    char *json = yyjson_mut_write_opts(doc, flags, &acton_alc, NULL, &err);
    //yyjson_doc_free(doc);
    return actStrFromCString(json);
}
