/*
 * Copyright (C) 2019-2021 Data Ductus AB
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdarg.h>

B_NoneType B_tupleD___init__(B_tuple self,int size ,...) {
    va_list args;
    va_start(args,size);
    self->size = size;
    for (int i=0; i<size; i++)
        self->components[i] = va_arg(args,$WORD);
    va_end(args);
    return B_None;
}

bool B_tupleD___bool__(B_tuple self) {
    return self->size>0;
}

B_str B_tupleD___str__(B_tuple self) {
    B_list s2 = B_listD_new(self->size);
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    for (int i=0; i< self->size; i++) {
        B_value elem = (B_value)self->components[i];
        if (elem == NULL) {
            wit->$class->append(wit,s2,B_None_str);
        } else {
            wit->$class->append(wit,s2,elem->$class->__repr__(elem));
        }
    }
    return B_strD_join_par('(',s2,')');
}


void B_tupleD___serialize__(B_tuple self, $Serial$state state) {
    B_int prevkey = (B_int)B_dictD_get(state->done,(B_Hashable)B_HashableD_WORDG_witness,self,NULL);
    if (prevkey) {
        $val_serialize(-TUPLE_ID,&prevkey->val,state);
        return;
    }
    B_dictD_setitem(state->done,(B_Hashable)B_HashableD_WORDG_witness,self,toB_int(state->row_no));
    long len = (long)self->size;
    $val_serialize(TUPLE_ID,&len,state);
    for (int i=0; i<self->size; i++) {
        $step_serialize(self->components[i],state);
    }
}

B_tuple B_tupleD___deserialize__(B_tuple self, $Serial$state state) {
    $ROW this = state->row;
    state->row = this->next;
    state->row_no++;
    if (this->class_id < 0) {
        return (B_tuple)B_dictD_get(state->done,(B_Hashable)B_HashableD_intG_witness,toB_int((long)this->blob[0]),NULL);
    } else {
        int len = (int)(long)this->blob[0];
        B_tuple res = acton_malloc(sizeof(struct B_tuple) + len*sizeof($WORD));
        B_dictD_setitem(state->done,(B_Hashable)B_HashableD_intG_witness,toB_int(state->row_no-1),res);
        res->$class = &B_tupleG_methods;
        res->size = len;
        for (int i = 0; i < len; i++) 
            res->components[i] = $step_deserialize(state);
        return res;
    }
}

struct B_tupleG_class B_tupleG_methods = {
    "tuple",
    UNASSIGNED,
    ($SuperG_class)&B_valueG_methods,
    B_tupleD___init__,
    B_tupleD___serialize__,
    B_tupleD___deserialize__,
    B_tupleD___bool__,
    B_tupleD___str__,
    B_tupleD___str__
};
