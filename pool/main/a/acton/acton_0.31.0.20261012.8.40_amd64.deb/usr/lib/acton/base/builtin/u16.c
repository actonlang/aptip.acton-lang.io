/*
 * Copyright (C) 2019-2021 Data Ductus AB
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

static struct B_ZeroDivisionError B_u16_zero_division_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "division by zero");
struct B_ZeroDivisionError B_u16_truediv_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "u16 truediv: division by zero");
struct B_ZeroDivisionError B_u16_floordiv_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "u16 floordiv: division by zero");
struct B_ZeroDivisionError B_u16_mod_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "u16 mod: division by zero");

// Auxiliary //////////////////////////////////////////////////////////////////////////////

// only called with e>=0.
uint16_t u16_pow(uint16_t a, uint16_t e) {
    if (e == 0) return 1;
    if (e == 1) return a;
    if (e%2 == 0) return int_pow(a*a,e/2);
    return a * int_pow(a*a,e/2);
}

// General methods
///////////////////////////////////////////////////////////////////////

uint16_t B_u16G_new(B_atom a, B_int base) {  // base is optional
    B_bigint b = B_bigintG_new(a, base);
    int sz = b->val.size;
    unsigned long n = sz == 0 ? 0 : b->val.n[0];
    if (sz  > 1 || sz < 0 || (sz==1 && n > 0xffff)) {
        char errmsg[1024];
        snprintf(errmsg, sizeof(errmsg), "u16(): value %s out of range for type u16",get_str(&b->val));
        RAISE(B_ValueError, actStrFromCStringCopy(errmsg));
    }
    return n*sz;
}
 
B_NoneType B_u16D___init__(B_u16 self, B_atom a, B_int base){
    self->val = B_u16G_new(a,base);
    return B_None;
}

void B_u16D___serialize__(B_u16 n, $Serial$state state) {
    // Widen val: $val_serialize copies a whole word and the box padding is not zeroed
    uint64_t v = n->val;
    $val_serialize(U16_ID,&v,state);
}

B_u16 B_u16D___deserialize__(B_u16 n, $Serial$state state) {
    return toB_u16((uint16_t)(uintptr_t)$val_deserialize(state));
}

bool B_u16D___bool__(B_u16 n) {
    return n->val != 0;
}

B_str B_u16D___str__(B_u16 n) {
    return $FORMAT("%u", (unsigned)n->val);
}

B_str B_u16D___repr__(B_u16 n) {
    return $FORMAT("%u", (unsigned)n->val);
}

B_u16 toB_u16(uint16_t i) {
    B_u16 res = acton_malloc_atomic(sizeof(struct B_u16));
    res->$class = &B_u16G_methods;
    res->val = i;
    return res;
}

uint16_t fromB_u16(B_u16 w) {
    return w->val;
}



// B_IntegralD_u16 /////////////////////////////////////////////////////////////////////////


B_u16 B_IntegralD_u16D___add__(B_IntegralD_u16 wit,  B_u16 a, B_u16 b) {
    return toB_u16(a->val + b->val); 
}

B_u16 B_IntegralD_u16D___zero__(B_IntegralD_u16 wit) {
    return toB_u16(0);
}

B_complex B_IntegralD_u16D___complex__(B_IntegralD_u16 wit, B_u16 a) {
    return toB_complex((double)(a->val));
}

B_u16 B_IntegralD_u16D___fromatom__(B_IntegralD_u16 wit, B_atom a) {
    return toB_u16(B_u16G_new(a,NULL));
}

B_u16 B_IntegralD_u16D___mul__(B_IntegralD_u16 wit,  B_u16 a, B_u16 b) {
    return toB_u16(a->val * b->val);
}  
  
B_u16 B_IntegralD_u16D___pow__(B_IntegralD_u16 wit,  B_u16 a, B_u16 b) {
    uint16_t aval = a->val;
    uint16_t bval = b->val;
    return toB_u16(int_pow(aval,bval));
}

B_u16 B_IntegralD_u16D___neg__(B_IntegralD_u16 wit,  B_u16 a) {
    return toB_u16(-a->val);
}

B_u16 B_IntegralD_u16D___pos__(B_IntegralD_u16 wit,  B_u16 a) {
    return a;
}

$WORD B_IntegralD_u16D_real(B_IntegralD_u16 wit, B_u16 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)(a));
}

$WORD B_IntegralD_u16D_imag(B_IntegralD_u16 wit, B_u16 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_u16(0LL));
}

$WORD B_IntegralD_u16D___abs__(B_IntegralD_u16 wit, B_u16 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_u16(a->val));
}

B_u16 B_IntegralD_u16D_conjugate(B_IntegralD_u16 wit,  B_u16 a) {
    return a;
}

double B_IntegralD_u16D___float__ (B_IntegralD_u16 wit, B_u16 n) {
    return (double)n->val;
}

$WORD B_IntegralD_u16D___trunc__ (B_IntegralD_u16 wit, B_u16 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_u16D___floor__ (B_IntegralD_u16 wit, B_u16 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_u16D___ceil__ (B_IntegralD_u16 wit, B_u16 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
B_u16 B_IntegralD_u16D___round__ (B_IntegralD_u16 wit, B_u16 n, B_int p) {
    uint16_t nval = n->val;
    int16_t pval = p==NULL ? 0 : fromB_int(p);
    if (pval>=0)
        return n;
    uint16_t p10 = int_pow(10,-pval);
    uint16_t res = nval/p10;
    if (nval%p10 * 2 > p10)
        res++; 
    return toB_u16(res * p10);
}
  
$WORD B_IntegralD_u16D_numerator (B_IntegralD_u16 wit, B_u16 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_u16D_denominator (B_IntegralD_u16 wit, B_u16 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_u16(1LL));
}
  
int64_t B_IntegralD_u16D___int__ (B_IntegralD_u16 wit, B_u16 n) {
    return n->val;
}

int64_t B_IntegralD_u16D___index__(B_IntegralD_u16 wit, B_u16 n) {
    return n->val;
}

B_tuple B_IntegralD_u16D___divmod__(B_IntegralD_u16 wit, B_u16 a, B_u16 b) {
    uint16_t n = a->val;
    uint16_t d = b->val;
    return $NEWTUPLE(2, toB_u16(n/d), toB_u16(n%d));
}

B_u16 B_IntegralD_u16D___floordiv__(B_IntegralD_u16 wit, B_u16 a, B_u16 b) {
    if (b->val == 0)
        RAISE_EXC(&B_u16_zero_division_error);
    return toB_u16(a->val / b->val);
}

B_u16 B_IntegralD_u16D___mod__(B_IntegralD_u16 wit, B_u16 a, B_u16 b) {
    return toB_u16(a->val % b->val);
}

B_u16 B_IntegralD_u16D___lshift__(B_IntegralD_u16 wit,  B_u16 a, int64_t b) {
    return toB_u16(a->val << b);
}

B_u16 B_IntegralD_u16D___rshift__(B_IntegralD_u16 wit,  B_u16 a, int64_t b) {
    return toB_u16(a->val >> b);
}
 
B_u16 B_IntegralD_u16D___invert__(B_IntegralD_u16 wit,  B_u16 a) {
    return toB_u16(~a->val);
}


// B_LogicalD_IntegralD_u16  ////////////////////////////////////////////////////////////////////////////////////////

B_u16 B_LogicalD_IntegralD_u16D___and__(B_LogicalD_IntegralD_u16 wit,  B_u16 a, B_u16 b) {
    return toB_u16(a->val & b->val);
}
                                                 
B_u16 B_LogicalD_IntegralD_u16D___or__(B_LogicalD_IntegralD_u16 wit,  B_u16 a, B_u16 b) {
    return toB_u16(a->val | b->val);
}
                                                 
B_u16 B_LogicalD_IntegralD_u16D___xor__(B_LogicalD_IntegralD_u16 wit,  B_u16 a, B_u16 b) {
    return toB_u16(a->val ^ b->val);
}  
 
// B_MinusD_IntegralD_u16  ////////////////////////////////////////////////////////////////////////////////////////

 
B_u16 B_MinusD_IntegralD_u16D___sub__(B_MinusD_IntegralD_u16 wit,  B_u16 a, B_u16 b) {
    return toB_u16(a->val - b->val);
}  

// B_DivD_u16  ////////////////////////////////////////////////////////////////////////////////////////

 
B_float B_DivD_u16D___truediv__ (B_DivD_u16 wit, B_u16 a, B_u16 b) {
    if (b->val == 0)
        RAISE_EXC(&B_u16_zero_division_error);
    return toB_float((double)a->val/(double)b->val);
}

// B_OrdD_u16  ////////////////////////////////////////////////////////////////////////////////////////

bool B_OrdD_u16D___eq__ (B_OrdD_u16 wit, B_u16 a, B_u16 b) {
    return a->val == b->val;
}

bool B_OrdD_u16D___ne__ (B_OrdD_u16 wit, B_u16 a, B_u16 b) {
    return a->val != b->val;
}

bool B_OrdD_u16D___lt__ (B_OrdD_u16 wit, B_u16 a, B_u16 b) {
    return a->val < b->val;
}

bool B_OrdD_u16D___le__ (B_OrdD_u16 wit, B_u16 a, B_u16 b) {
    return a->val <= b->val;
}

bool B_OrdD_u16D___gt__ (B_OrdD_u16 wit, B_u16 a, B_u16 b) {
    return a->val > b->val;
}

bool B_OrdD_u16D___ge__ (B_OrdD_u16 wit, B_u16 a, B_u16 b) {
    return a->val >= b->val;
}

// B_HashableD_u16 ///////////////////////////////////////////////////////////////////////////////////////////////////////

B_NoneType B_HashableD_u16D_hash(B_HashableD_u16 wit, B_u16 a, B_hasher h) {
    zig_hash_wyhash_update(h->_hasher, (const uint8_t *)&a->val, sizeof(a->val));
    return B_None;
}
