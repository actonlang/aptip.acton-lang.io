
void loggingQ___ext_init__() {}

int64_t loggingQ_MessageD__get_actor_id (loggingQ_Message self) {
    $Actor actor_self = GET_SELF();
    return actor_self->$globkey;
}

B_str loggingQ_MessageD__get_actor_class (loggingQ_Message self) {
    $Actor actor_self = GET_SELF();
    return actStrFromCString(unmangle_name(actor_self->$class->$GCINFO));
}
