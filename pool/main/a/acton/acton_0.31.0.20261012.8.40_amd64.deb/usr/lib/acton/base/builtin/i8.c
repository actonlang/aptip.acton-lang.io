/*
 * Copyright (C) 2019-2021 Data Ductus AB
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

static struct B_ZeroDivisionError B_i8_zero_division_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "division by zero");
struct B_ZeroDivisionError B_i8_truediv_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "i8 truediv: division by zero");
struct B_ZeroDivisionError B_i8_floordiv_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "i8 floordiv: division by zero");
struct B_ZeroDivisionError B_i8_mod_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "i8 mod: division by zero");

// Auxiliary //////////////////////////////////////////////////////////////////////////////

// only called with e>=0.
int8_t i8_pow(int8_t a, int8_t e) {
    if (e == 0) return 1;
    if (e == 1) return a;
    if (e%2 == 0) return i8_pow(a*a,e/2);
    return a * i8_pow(a*a,e/2);
}

// General methods ///////////////////////////////////////////////////////////////////////

int8_t B_i8G_new(B_atom a, B_int base) {
    B_bigint b = B_bigintG_new(a, base);
    long sz = b->val.size;
    unsigned long n = sz == 0 ? 0 : b->val.n[0];
    if (labs(sz) > 1 || (sz==1 && n > 0x7ful) || (sz == -1 && n > 0x80ul)) {
        char errmsg[1024];
        snprintf(errmsg, sizeof(errmsg), "i8(): value %s out of range for type i8",get_str(&b->val));
        RAISE(B_ValueError, actStrFromCStringCopy(errmsg));
    }
    return (int8_t)(n*sz);
}


B_NoneType B_i8D___init__(B_i8 self, B_atom a, B_int base){
    self->val = B_i8G_new(a,base);
    return B_None;
}

void B_i8D___serialize__(B_i8 n, $Serial$state state) {
    // Widen val: $val_serialize copies a whole word and the box padding is not zeroed
    uint64_t v = (uint8_t)n->val;
    $val_serialize(I8_ID,&v,state);
}

B_i8 B_i8D___deserialize__(B_i8 n, $Serial$state state) {
    return toB_i8((int8_t)(uintptr_t)$val_deserialize(state));
}

bool B_i8D___bool__(B_i8 n) {
    return n->val != 0;
}

B_str B_i8D___str__(B_i8 n) {
    return $FORMAT("%d", n->val);
}

B_str B_i8D___repr__(B_i8 n) {
    return $FORMAT("%d", n->val);
}

B_i8 toB_i8(int8_t i) {
    B_i8 res = acton_malloc_atomic(sizeof(struct B_i8));
    res->$class = &B_i8G_methods;
    res->val = i;
    return res;
}

int8_t fromB_i8(B_i8 w) {
    return w->val;
}

                  

// B_IntegralD_i8 /////////////////////////////////////////////////////////////////////////

 
B_i8 B_IntegralD_i8D___add__(B_IntegralD_i8 wit,  B_i8 a, B_i8 b) {
    return toB_i8(a->val+b->val);
}  

B_i8 B_IntegralD_i8D___zero__(B_IntegralD_i8 wit) {
    return toB_i8(0);
}

B_complex B_IntegralD_i8D___complex__(B_IntegralD_i8 wit, B_i8 a) {
    return toB_complex((double)(a->val));
}

B_i8 B_IntegralD_i8D___fromatom__(B_IntegralD_i8 wit, B_atom a) {
    return toB_i8(B_i8G_new(a,NULL));
}

B_i8 B_IntegralD_i8D___mul__(B_IntegralD_i8 wit,  B_i8 a, B_i8 b) {
    return toB_i8(a->val * b->val);
}  
  
B_i8 B_IntegralD_i8D___pow__(B_IntegralD_i8 wit,  B_i8 a, B_i8 b) {
    int8_t aval = a->val;
    int8_t bval = b->val;
    if ( bval < 0) {
        char errmsg[1024];
        snprintf(errmsg, sizeof(errmsg), "int.__pow__: negative exponent %d ",bval);
        RAISE(B_ValueError, actStrFromCStringCopy(errmsg));
    }
    return toB_i8(i8_pow(aval,bval));
}

B_i8 B_IntegralD_i8D___neg__(B_IntegralD_i8 wit,  B_i8 a) {
    return toB_i8(-a->val);
}

B_i8 B_IntegralD_i8D___pos__(B_IntegralD_i8 wit,  B_i8 a) {
    return a;
}

$WORD B_IntegralD_i8D_real(B_IntegralD_i8 wit, B_i8 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)(a));
}

$WORD B_IntegralD_i8D_imag(B_IntegralD_i8 wit, B_i8 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_i8(0));
}

$WORD B_IntegralD_i8D___abs__(B_IntegralD_i8 wit, B_i8 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_i8(abs(a->val)));
}

B_i8 B_IntegralD_i8D_conjugate(B_IntegralD_i8 wit,  B_i8 a) {
    return a;
}

double B_IntegralD_i8D___float__ (B_IntegralD_i8 wit, B_i8 n) {
    return (double)n->val;
}

$WORD B_IntegralD_i8D___trunc__ (B_IntegralD_i8 wit, B_i8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_i8D___floor__ (B_IntegralD_i8 wit, B_i8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_i8D___ceil__ (B_IntegralD_i8 wit, B_i8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
B_i8 B_IntegralD_i8D___round__ (B_IntegralD_i8 wit, B_i8 n, B_int p) {
    int8_t nval = n->val;
    if (nval<0)
        return toB_i8(-B_IntegralD_i8D___round__(wit,toB_i8(-nval),p)->val);
    int pval = p==NULL ? 0 : fromB_int(p);
    if (pval>=0)
        return n;
    int p10 = i8_pow(10,-pval);
    int res = nval/p10;
    if (nval%p10 * 2 > p10)
        res++; 
    return toB_i8(res * p10);
}
  
$WORD B_IntegralD_i8D_numerator (B_IntegralD_i8 wit, B_i8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_i8D_denominator (B_IntegralD_i8 wit, B_i8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_i8(1));
}
  
int64_t B_IntegralD_i8D___int__ (B_IntegralD_i8 wit, B_i8 n) {
    return (int64_t)n->val;
}

int64_t B_IntegralD_i8D___index__(B_IntegralD_i8 wit, B_i8 n) {
    return  (int64_t)n->val;
}

B_tuple B_IntegralD_i8D___divmod__(B_IntegralD_i8 wit, B_i8 a, B_i8 b) {
    int8_t n = a->val;
    int8_t d = b->val;
    return $NEWTUPLE(2, toB_i8(n/d), toB_i8(n%d));
}

B_i8 B_IntegralD_i8D___floordiv__(B_IntegralD_i8 wit, B_i8 a, B_i8 b) {
    if (b->val == 0)
        RAISE_EXC(&B_i8_zero_division_error);
    return toB_i8(a->val / b->val);
}

B_i8 B_IntegralD_i8D___mod__(B_IntegralD_i8 wit, B_i8 a, B_i8 b) {
    return toB_i8(a->val % b->val);
}

B_i8 B_IntegralD_i8D___lshift__(B_IntegralD_i8 wit,  B_i8 a, int64_t b) {
    return toB_i8(a->val << b);
}

B_i8 B_IntegralD_i8D___rshift__(B_IntegralD_i8 wit,  B_i8 a, int64_t b) {
    return toB_i8(a->val >> b);
}
 
B_i8 B_IntegralD_i8D___invert__(B_IntegralD_i8 wit,  B_i8 a) {
    return toB_i8( ~a->val);
}


// B_LogicalD_IntegralD_i8  ////////////////////////////////////////////////////////////////////////////////////////

B_i8 B_LogicalD_IntegralD_i8D___and__(B_LogicalD_IntegralD_i8 wit,  B_i8 a, B_i8 b) {
    return toB_i8(a->val & b->val);
}
                                                 
B_i8 B_LogicalD_IntegralD_i8D___or__(B_LogicalD_IntegralD_i8 wit,  B_i8 a, B_i8 b) {
    return toB_i8(a->val | b->val);
}
                                                 
B_i8 B_LogicalD_IntegralD_i8D___xor__(B_LogicalD_IntegralD_i8 wit,  B_i8 a, B_i8 b) {
    return toB_i8(a->val ^ b->val);
}  
 
// B_MinusD_IntegralD_i8  ////////////////////////////////////////////////////////////////////////////////////////

 
B_i8 B_MinusD_IntegralD_i8D___sub__(B_MinusD_IntegralD_i8 wit,  B_i8 a, B_i8 b) {
    return toB_i8(a->val - b->val);
}  

// B_DivD_i8  ////////////////////////////////////////////////////////////////////////////////////////

 
B_float B_DivD_i8D___truediv__ (B_DivD_i8 wit, B_i8 a, B_i8 b) {
    if (b->val == 0)
        RAISE_EXC(&B_i8_zero_division_error);
    return toB_float((double)a->val/(double)b->val);
}

// B_OrdD_i8  ////////////////////////////////////////////////////////////////////////////////////////

bool B_OrdD_i8D___eq__ (B_OrdD_i8 wit, B_i8 a, B_i8 b) {
    return a->val == b->val;
}

bool B_OrdD_i8D___ne__ (B_OrdD_i8 wit, B_i8 a, B_i8 b) {
    return a->val != b->val;
}

bool B_OrdD_i8D___lt__ (B_OrdD_i8 wit, B_i8 a, B_i8 b) {
    return a->val < b->val;
}

bool B_OrdD_i8D___le__ (B_OrdD_i8 wit, B_i8 a, B_i8 b) {
    return a->val <= b->val;
}

bool B_OrdD_i8D___gt__ (B_OrdD_i8 wit, B_i8 a, B_i8 b) {
    return a->val > b->val;
}

bool B_OrdD_i8D___ge__ (B_OrdD_i8 wit, B_i8 a, B_i8 b) {
    return a->val >= b->val;
}

// B_HashableD_i8 ///////////////////////////////////////////////////////////////////////////////////////////////////////

B_NoneType B_HashableD_i8D_hash(B_HashableD_i8 wit, B_i8 a, B_hasher h) {
    zig_hash_wyhash_update(h->_hasher, (const uint8_t *)&a->val, sizeof(a->val));
    return B_None;
}
