/*
 * Copyright (C) 2019-2021 Data Ductus AB
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

static struct B_str true_str = {&B_strG_methods, 4, 4, (unsigned char *)"True"};
static struct B_str false_str = {&B_strG_methods, 5, 5, (unsigned char *)"False"};

// Serialization ///////////////////////////////////////////////////////////////////////

B_NoneType B_boolD___init__(B_bool self, B_value s){
    self->val = B_boolG_new(s);
    return B_None;
}

bool B_boolD___bool__(B_bool self) {
    return self->val;
}

B_str B_boolD___str__(B_bool self) {
    if (self->val)
        return &true_str;
    else
        return &false_str;
}

B_str B_boolD___repr__(B_bool self) {
    return B_boolD___str__(self);
}

void B_boolD___serialize__(B_bool self, $Serial$state state) {
    $val_serialize(BOOL_ID,&self->val,state);
}

B_bool B_boolD___deserialize__(B_bool self, $Serial$state state) {
    return toB_bool((long)$val_deserialize(state));
}

bool B_boolG_new(B_value s) {
    return  s->$class->__bool__(s);
}

B_bool toB_bool(bool b) {
    return b ? B_True : B_False;
}
    
bool fromB_bool(B_bool b) {
    return b->val;
}

struct B_bool $t = {&B_boolG_methods,true};
struct B_bool $f = {&B_boolG_methods,false};

B_bool B_True = &$t;
B_bool B_False = &$f;


bool $default__bool__(B_value self) {
    return true;
}

// B_HashableD_bool ///////////////////////////////////////////////////////////////////////////////////////////////////////

bool B_HashableD_boolD___eq__(B_HashableD_bool wit, B_bool a, B_bool b) {
    return a->val == b->val;
}

bool B_HashableD_boolD___ne__(B_HashableD_bool wit, B_bool a, B_bool b) {
    return a->val != b->val;
}

B_NoneType B_HashableD_boolD_hash(B_HashableD_bool wit, B_bool a, B_hasher h) {
    zig_hash_wyhash_update(h->_hasher, (const uint8_t *)&a->val, sizeof(a->val));
    return B_None;
}
