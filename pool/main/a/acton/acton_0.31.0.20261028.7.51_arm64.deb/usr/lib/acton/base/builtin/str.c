/*
 * Copyright (C) 2019-2021 Data Ductus AB
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <ctype.h>
#include <wchar.h>

#include <strings.h>

#define GC_THREADS 1
#include "gc.h"

#include "utf8proc.h"

static struct B_ValueError B_str_invalid_utf8_copy_error =
    STATIC_EXCEPTION(B_ValueError, "to$str: Unicode decode error");
static struct B_ValueError B_str_invalid_utf8_nocopy_error =
    STATIC_EXCEPTION(B_ValueError, "to_str_noc: Unicode decode error");
static struct B_ValueError B_str_invalid_utf8_error =
    STATIC_EXCEPTION(B_ValueError, "Unicode decode error");
static struct B_ValueError B_str_invalid_center_fill_error =
    STATIC_EXCEPTION(B_ValueError, "center: fill string not single char");
static struct B_ValueError B_str_substring_not_found_error =
    STATIC_EXCEPTION(B_ValueError, "index: substring not found");
static struct B_ValueError B_str_expandtabs_too_long_error =
    STATIC_EXCEPTION(B_ValueError, "expandtabs: result too long");
static struct B_ValueError B_str_too_long_error =
    STATIC_EXCEPTION(B_ValueError, "result too long");
static struct B_ValueError B_str_invalid_ljust_fill_error =
    STATIC_EXCEPTION(B_ValueError, "ljust: fill str not single char");
static struct B_ValueError B_str_rsubstring_not_found_error =
    STATIC_EXCEPTION(B_ValueError, "rindex: substring not found");
static struct B_ValueError B_str_invalid_rjust_fill_error =
    STATIC_EXCEPTION(B_ValueError, "rjust: fill string not single char");
static struct B_ValueError B_str_empty_separator_error =
    STATIC_EXCEPTION(B_ValueError, "split: separator is empty string");
static struct B_MemoryError B_str_allocation_failed_error =
    STATIC_EXCEPTION(B_MemoryError, "memory allocation failed");
static struct B_ValueError B_str_invalid_bytearray_center_fill_error =
    STATIC_EXCEPTION(B_ValueError, "center: fill bytearray not single char");
static struct B_ValueError B_str_odd_hex_length_error =
    STATIC_EXCEPTION(B_ValueError, "from_hex: hex string must have even length");
static struct B_ValueError B_str_invalid_hex_error =
    STATIC_EXCEPTION(B_ValueError, "from_hex: invalid hex character");
static struct B_ValueError B_str_invalid_bytearray_ljust_fill_error =
    STATIC_EXCEPTION(B_ValueError, "bytearray ljust: fill array not single char");
static struct B_ValueError B_str_bytearray_rsubstring_not_found_error =
    STATIC_EXCEPTION(B_ValueError, "rindex for bytearray: substring not found");
static struct B_ValueError B_str_empty_bytearray_separator_error =
    STATIC_EXCEPTION(B_ValueError, "split for bytearray: separator is empty string");
static struct B_ValueError B_str_invalid_bytearray_value_error =
    STATIC_EXCEPTION(B_ValueError, "setitem for bytearray: value outside [0..255]");
static struct B_ValueError B_str_invalid_bytearray_insert_error =
    STATIC_EXCEPTION(B_ValueError, "insert for bytearray: value outside [0..255]");
static struct B_ValueError B_str_invalid_bytearray_append_error =
    STATIC_EXCEPTION(B_ValueError, "append for bytearray: value outside [0..255]");
static struct B_ValueError B_str_invalid_bytearray_slice_error =
    STATIC_EXCEPTION(B_ValueError, "setslice for bytearray: illegal slice");
static struct B_ValueError B_str_invalid_bytes_value_error =
    STATIC_EXCEPTION(B_ValueError, "bytes constructor: element outside [0..255]");
static struct B_ValueError B_str_invalid_bytes_center_fill_error =
    STATIC_EXCEPTION(B_ValueError, "center: fill bytes not single char");
static struct B_ValueError B_str_invalid_bytes_ljust_fill_error =
    STATIC_EXCEPTION(B_ValueError, "bytes ljust: fill array not single char");
static struct B_ValueError B_str_bytes_rsubstring_not_found_error =
    STATIC_EXCEPTION(B_ValueError, "rindex for bytes: substring not found");
static struct B_ValueError B_str_empty_bytes_separator_error =
    STATIC_EXCEPTION(B_ValueError, "split for bytes: separator is empty string");
static struct B_ValueError B_str_invalid_code_point_error =
    STATIC_EXCEPTION(B_ValueError, "chr: argument is not a valid Unicode code point");
static struct B_ValueError B_str_invalid_ord_error =
    STATIC_EXCEPTION(B_ValueError, "ord: argument is not a single Unicode char");
static struct B_ValueError B_str_invalid_format_error =
    STATIC_EXCEPTION(B_ValueError, "Invalid format string");
static struct B_MemoryError B_str_format_allocation_failed_error =
    STATIC_EXCEPTION(B_MemoryError, "Failed to allocate memory for formatted string");

// Auxiliaries, some used for both str and bytearray implementations ////////////////////////////////////////////////////////

static unsigned char nul = 0;

static struct B_str null_struct = {&B_strG_methods,0,0,&nul};

static B_str null_str = &null_struct;
// Prebuilt immutable one-byte ASCII strings used by indexing and iteration.
#define ASCII_CHAR_TABLE_SIZE 128
static unsigned char ascii_char_data[ASCII_CHAR_TABLE_SIZE][2] = {
    [1] = {1, 0},
    [2] = {2, 0},
    [3] = {3, 0},
    [4] = {4, 0},
    [5] = {5, 0},
    [6] = {6, 0},
    [7] = {7, 0},
    [8] = {8, 0},
    [9] = {9, 0},
    [10] = {10, 0},
    [11] = {11, 0},
    [12] = {12, 0},
    [13] = {13, 0},
    [14] = {14, 0},
    [15] = {15, 0},
    [16] = {16, 0},
    [17] = {17, 0},
    [18] = {18, 0},
    [19] = {19, 0},
    [20] = {20, 0},
    [21] = {21, 0},
    [22] = {22, 0},
    [23] = {23, 0},
    [24] = {24, 0},
    [25] = {25, 0},
    [26] = {26, 0},
    [27] = {27, 0},
    [28] = {28, 0},
    [29] = {29, 0},
    [30] = {30, 0},
    [31] = {31, 0},
    [32] = {32, 0},
    [33] = {33, 0},
    [34] = {34, 0},
    [35] = {35, 0},
    [36] = {36, 0},
    [37] = {37, 0},
    [38] = {38, 0},
    [39] = {39, 0},
    [40] = {40, 0},
    [41] = {41, 0},
    [42] = {42, 0},
    [43] = {43, 0},
    [44] = {44, 0},
    [45] = {45, 0},
    [46] = {46, 0},
    [47] = {47, 0},
    [48] = {48, 0},
    [49] = {49, 0},
    [50] = {50, 0},
    [51] = {51, 0},
    [52] = {52, 0},
    [53] = {53, 0},
    [54] = {54, 0},
    [55] = {55, 0},
    [56] = {56, 0},
    [57] = {57, 0},
    [58] = {58, 0},
    [59] = {59, 0},
    [60] = {60, 0},
    [61] = {61, 0},
    [62] = {62, 0},
    [63] = {63, 0},
    [64] = {64, 0},
    [65] = {65, 0},
    [66] = {66, 0},
    [67] = {67, 0},
    [68] = {68, 0},
    [69] = {69, 0},
    [70] = {70, 0},
    [71] = {71, 0},
    [72] = {72, 0},
    [73] = {73, 0},
    [74] = {74, 0},
    [75] = {75, 0},
    [76] = {76, 0},
    [77] = {77, 0},
    [78] = {78, 0},
    [79] = {79, 0},
    [80] = {80, 0},
    [81] = {81, 0},
    [82] = {82, 0},
    [83] = {83, 0},
    [84] = {84, 0},
    [85] = {85, 0},
    [86] = {86, 0},
    [87] = {87, 0},
    [88] = {88, 0},
    [89] = {89, 0},
    [90] = {90, 0},
    [91] = {91, 0},
    [92] = {92, 0},
    [93] = {93, 0},
    [94] = {94, 0},
    [95] = {95, 0},
    [96] = {96, 0},
    [97] = {97, 0},
    [98] = {98, 0},
    [99] = {99, 0},
    [100] = {100, 0},
    [101] = {101, 0},
    [102] = {102, 0},
    [103] = {103, 0},
    [104] = {104, 0},
    [105] = {105, 0},
    [106] = {106, 0},
    [107] = {107, 0},
    [108] = {108, 0},
    [109] = {109, 0},
    [110] = {110, 0},
    [111] = {111, 0},
    [112] = {112, 0},
    [113] = {113, 0},
    [114] = {114, 0},
    [115] = {115, 0},
    [116] = {116, 0},
    [117] = {117, 0},
    [118] = {118, 0},
    [119] = {119, 0},
    [120] = {120, 0},
    [121] = {121, 0},
    [122] = {122, 0},
    [123] = {123, 0},
    [124] = {124, 0},
    [125] = {125, 0},
    [126] = {126, 0},
    [127] = {127, 0}
};
static struct B_str ascii_char_strs[ASCII_CHAR_TABLE_SIZE] = {
    [0] = {&B_strG_methods, 1, 1, ascii_char_data[0]},
    [1] = {&B_strG_methods, 1, 1, ascii_char_data[1]},
    [2] = {&B_strG_methods, 1, 1, ascii_char_data[2]},
    [3] = {&B_strG_methods, 1, 1, ascii_char_data[3]},
    [4] = {&B_strG_methods, 1, 1, ascii_char_data[4]},
    [5] = {&B_strG_methods, 1, 1, ascii_char_data[5]},
    [6] = {&B_strG_methods, 1, 1, ascii_char_data[6]},
    [7] = {&B_strG_methods, 1, 1, ascii_char_data[7]},
    [8] = {&B_strG_methods, 1, 1, ascii_char_data[8]},
    [9] = {&B_strG_methods, 1, 1, ascii_char_data[9]},
    [10] = {&B_strG_methods, 1, 1, ascii_char_data[10]},
    [11] = {&B_strG_methods, 1, 1, ascii_char_data[11]},
    [12] = {&B_strG_methods, 1, 1, ascii_char_data[12]},
    [13] = {&B_strG_methods, 1, 1, ascii_char_data[13]},
    [14] = {&B_strG_methods, 1, 1, ascii_char_data[14]},
    [15] = {&B_strG_methods, 1, 1, ascii_char_data[15]},
    [16] = {&B_strG_methods, 1, 1, ascii_char_data[16]},
    [17] = {&B_strG_methods, 1, 1, ascii_char_data[17]},
    [18] = {&B_strG_methods, 1, 1, ascii_char_data[18]},
    [19] = {&B_strG_methods, 1, 1, ascii_char_data[19]},
    [20] = {&B_strG_methods, 1, 1, ascii_char_data[20]},
    [21] = {&B_strG_methods, 1, 1, ascii_char_data[21]},
    [22] = {&B_strG_methods, 1, 1, ascii_char_data[22]},
    [23] = {&B_strG_methods, 1, 1, ascii_char_data[23]},
    [24] = {&B_strG_methods, 1, 1, ascii_char_data[24]},
    [25] = {&B_strG_methods, 1, 1, ascii_char_data[25]},
    [26] = {&B_strG_methods, 1, 1, ascii_char_data[26]},
    [27] = {&B_strG_methods, 1, 1, ascii_char_data[27]},
    [28] = {&B_strG_methods, 1, 1, ascii_char_data[28]},
    [29] = {&B_strG_methods, 1, 1, ascii_char_data[29]},
    [30] = {&B_strG_methods, 1, 1, ascii_char_data[30]},
    [31] = {&B_strG_methods, 1, 1, ascii_char_data[31]},
    [32] = {&B_strG_methods, 1, 1, ascii_char_data[32]},
    [33] = {&B_strG_methods, 1, 1, ascii_char_data[33]},
    [34] = {&B_strG_methods, 1, 1, ascii_char_data[34]},
    [35] = {&B_strG_methods, 1, 1, ascii_char_data[35]},
    [36] = {&B_strG_methods, 1, 1, ascii_char_data[36]},
    [37] = {&B_strG_methods, 1, 1, ascii_char_data[37]},
    [38] = {&B_strG_methods, 1, 1, ascii_char_data[38]},
    [39] = {&B_strG_methods, 1, 1, ascii_char_data[39]},
    [40] = {&B_strG_methods, 1, 1, ascii_char_data[40]},
    [41] = {&B_strG_methods, 1, 1, ascii_char_data[41]},
    [42] = {&B_strG_methods, 1, 1, ascii_char_data[42]},
    [43] = {&B_strG_methods, 1, 1, ascii_char_data[43]},
    [44] = {&B_strG_methods, 1, 1, ascii_char_data[44]},
    [45] = {&B_strG_methods, 1, 1, ascii_char_data[45]},
    [46] = {&B_strG_methods, 1, 1, ascii_char_data[46]},
    [47] = {&B_strG_methods, 1, 1, ascii_char_data[47]},
    [48] = {&B_strG_methods, 1, 1, ascii_char_data[48]},
    [49] = {&B_strG_methods, 1, 1, ascii_char_data[49]},
    [50] = {&B_strG_methods, 1, 1, ascii_char_data[50]},
    [51] = {&B_strG_methods, 1, 1, ascii_char_data[51]},
    [52] = {&B_strG_methods, 1, 1, ascii_char_data[52]},
    [53] = {&B_strG_methods, 1, 1, ascii_char_data[53]},
    [54] = {&B_strG_methods, 1, 1, ascii_char_data[54]},
    [55] = {&B_strG_methods, 1, 1, ascii_char_data[55]},
    [56] = {&B_strG_methods, 1, 1, ascii_char_data[56]},
    [57] = {&B_strG_methods, 1, 1, ascii_char_data[57]},
    [58] = {&B_strG_methods, 1, 1, ascii_char_data[58]},
    [59] = {&B_strG_methods, 1, 1, ascii_char_data[59]},
    [60] = {&B_strG_methods, 1, 1, ascii_char_data[60]},
    [61] = {&B_strG_methods, 1, 1, ascii_char_data[61]},
    [62] = {&B_strG_methods, 1, 1, ascii_char_data[62]},
    [63] = {&B_strG_methods, 1, 1, ascii_char_data[63]},
    [64] = {&B_strG_methods, 1, 1, ascii_char_data[64]},
    [65] = {&B_strG_methods, 1, 1, ascii_char_data[65]},
    [66] = {&B_strG_methods, 1, 1, ascii_char_data[66]},
    [67] = {&B_strG_methods, 1, 1, ascii_char_data[67]},
    [68] = {&B_strG_methods, 1, 1, ascii_char_data[68]},
    [69] = {&B_strG_methods, 1, 1, ascii_char_data[69]},
    [70] = {&B_strG_methods, 1, 1, ascii_char_data[70]},
    [71] = {&B_strG_methods, 1, 1, ascii_char_data[71]},
    [72] = {&B_strG_methods, 1, 1, ascii_char_data[72]},
    [73] = {&B_strG_methods, 1, 1, ascii_char_data[73]},
    [74] = {&B_strG_methods, 1, 1, ascii_char_data[74]},
    [75] = {&B_strG_methods, 1, 1, ascii_char_data[75]},
    [76] = {&B_strG_methods, 1, 1, ascii_char_data[76]},
    [77] = {&B_strG_methods, 1, 1, ascii_char_data[77]},
    [78] = {&B_strG_methods, 1, 1, ascii_char_data[78]},
    [79] = {&B_strG_methods, 1, 1, ascii_char_data[79]},
    [80] = {&B_strG_methods, 1, 1, ascii_char_data[80]},
    [81] = {&B_strG_methods, 1, 1, ascii_char_data[81]},
    [82] = {&B_strG_methods, 1, 1, ascii_char_data[82]},
    [83] = {&B_strG_methods, 1, 1, ascii_char_data[83]},
    [84] = {&B_strG_methods, 1, 1, ascii_char_data[84]},
    [85] = {&B_strG_methods, 1, 1, ascii_char_data[85]},
    [86] = {&B_strG_methods, 1, 1, ascii_char_data[86]},
    [87] = {&B_strG_methods, 1, 1, ascii_char_data[87]},
    [88] = {&B_strG_methods, 1, 1, ascii_char_data[88]},
    [89] = {&B_strG_methods, 1, 1, ascii_char_data[89]},
    [90] = {&B_strG_methods, 1, 1, ascii_char_data[90]},
    [91] = {&B_strG_methods, 1, 1, ascii_char_data[91]},
    [92] = {&B_strG_methods, 1, 1, ascii_char_data[92]},
    [93] = {&B_strG_methods, 1, 1, ascii_char_data[93]},
    [94] = {&B_strG_methods, 1, 1, ascii_char_data[94]},
    [95] = {&B_strG_methods, 1, 1, ascii_char_data[95]},
    [96] = {&B_strG_methods, 1, 1, ascii_char_data[96]},
    [97] = {&B_strG_methods, 1, 1, ascii_char_data[97]},
    [98] = {&B_strG_methods, 1, 1, ascii_char_data[98]},
    [99] = {&B_strG_methods, 1, 1, ascii_char_data[99]},
    [100] = {&B_strG_methods, 1, 1, ascii_char_data[100]},
    [101] = {&B_strG_methods, 1, 1, ascii_char_data[101]},
    [102] = {&B_strG_methods, 1, 1, ascii_char_data[102]},
    [103] = {&B_strG_methods, 1, 1, ascii_char_data[103]},
    [104] = {&B_strG_methods, 1, 1, ascii_char_data[104]},
    [105] = {&B_strG_methods, 1, 1, ascii_char_data[105]},
    [106] = {&B_strG_methods, 1, 1, ascii_char_data[106]},
    [107] = {&B_strG_methods, 1, 1, ascii_char_data[107]},
    [108] = {&B_strG_methods, 1, 1, ascii_char_data[108]},
    [109] = {&B_strG_methods, 1, 1, ascii_char_data[109]},
    [110] = {&B_strG_methods, 1, 1, ascii_char_data[110]},
    [111] = {&B_strG_methods, 1, 1, ascii_char_data[111]},
    [112] = {&B_strG_methods, 1, 1, ascii_char_data[112]},
    [113] = {&B_strG_methods, 1, 1, ascii_char_data[113]},
    [114] = {&B_strG_methods, 1, 1, ascii_char_data[114]},
    [115] = {&B_strG_methods, 1, 1, ascii_char_data[115]},
    [116] = {&B_strG_methods, 1, 1, ascii_char_data[116]},
    [117] = {&B_strG_methods, 1, 1, ascii_char_data[117]},
    [118] = {&B_strG_methods, 1, 1, ascii_char_data[118]},
    [119] = {&B_strG_methods, 1, 1, ascii_char_data[119]},
    [120] = {&B_strG_methods, 1, 1, ascii_char_data[120]},
    [121] = {&B_strG_methods, 1, 1, ascii_char_data[121]},
    [122] = {&B_strG_methods, 1, 1, ascii_char_data[122]},
    [123] = {&B_strG_methods, 1, 1, ascii_char_data[123]},
    [124] = {&B_strG_methods, 1, 1, ascii_char_data[124]},
    [125] = {&B_strG_methods, 1, 1, ascii_char_data[125]},
    [126] = {&B_strG_methods, 1, 1, ascii_char_data[126]},
    [127] = {&B_strG_methods, 1, 1, ascii_char_data[127]}
};

static B_str space_str = &ascii_char_strs[(unsigned char)' '];

static struct B_str whitespace_struct = {&B_strG_methods,6,6,(unsigned char *)" \t\n\r\x0b\x0c"};

static B_str whitespace_str = &whitespace_struct;

static struct B_bytes null_bytes_struct = {&B_bytesG_methods,0,&nul};

static B_bytes null_bytes = &null_bytes_struct;

static struct B_bytes space_bytes_struct = {&B_bytesG_methods,1,(unsigned char *)" "};

static B_bytes space_bytes = &space_bytes_struct;

static struct B_bytes whitespace_bytes_struct = {&B_bytesG_methods,6,(unsigned char *)" \t\n\r\x0b\x0c"};

static B_bytes whitespace_bytes = &whitespace_bytes_struct;

// We avoid returning the bytearray singleton from bytearray methods, this is
// just used internally as a default value for the fill character.
static struct B_bytearray space_bytearray_struct = {&B_bytearrayG_methods,1,(unsigned char *)" ",1};

static B_bytearray space_bytearray = &space_bytearray_struct;

static struct B_bytearray whitespace_bytearray_struct = {&B_bytearrayG_methods,6,(unsigned char *)" \t\n\r\x0b\x0c",6};

static B_bytearray whitespace_bytearray = &whitespace_bytearray_struct;

// Allocate the data of a str, bytes or bytearray. Its length can be up to
// MAX_STR_LEN, far more than there is memory for.
static unsigned char *alloc_data(size_t nbytes) {
    unsigned char *p = acton_malloc_atomic(nbytes);
    if (p == NULL && nbytes > 0)
        RAISE_EXC(&B_str_allocation_failed_error);
    return p;
}

#define NEW_UNFILLED_STR(nm, nchrs, nbtes)      \
    assert((nbtes) >= (nchrs));                 \
    nm = acton_malloc(sizeof(struct B_str));    \
    (nm)->$class = &B_strG_methods;             \
    (nm)->nchars = (nchrs);                     \
    (nm)->nbytes = (nbtes);                     \
    (nm)->str = alloc_data((size_t)(nbtes) + 1); \
    (nm)->str[(nbtes)] = 0

// bytes and bytearray data is nbytes long and not NUL-terminated; NUL is an
// ordinary byte.
#define NEW_UNFILLED_BYTEARRAY(nm, nbtes)       \
    nm = acton_malloc(sizeof(struct B_bytearray)); \
    (nm)->$class = &B_bytearrayG_methods;       \
    (nm)->nbytes = (nbtes);                     \
    (nm)->capacity = (nbtes);                   \
    (nm)->str = alloc_data(nbtes)

#define NEW_UNFILLED_BYTES(nm, nbtes)           \
    nm = acton_malloc(sizeof(struct B_bytes));  \
    (nm)->$class = &B_bytesG_methods;           \
    (nm)->nbytes = (nbtes);                     \
    (nm)->str = alloc_data(nbtes)

// The length of a result is computed in 64 bits and checked with this before
// allocating it. The terms added up are lengths, which are at most
// MAX_STR_LEN, and counts and widths checked on their own first, multiplied by
// at most 4, so the sum can't overflow. A count times a length can, and is
// checked by division instead.
static void check_result_len(int64_t nbytes) {
    if (nbytes > MAX_STR_LEN)
        RAISE_EXC(&B_str_too_long_error);
}

// Conversion to and from C strings

// Count Unicode characters within the supplied byte range, including NUL.
static int64_t str_count_chars(const char *str, int64_t nbytes, B_ValueError error) {
    const unsigned char *p = (const unsigned char *)str;
    const unsigned char *end = p + nbytes;
    int64_t nchars = nbytes;
    while (p < end) {
        if (*p < 0x80) {
            p++;
        } else {
            int cp;
            int size = utf8proc_iterate(p, end - p, &cp);
            if (size < 0) {
                RAISE_EXC(error);
                return 0;
            }
            p += size;
            nchars -= size - 1;
        }
    }
    return nchars;
}

static B_str str_from_c(const char *str, int64_t nbytes, bool copy, B_ValueError error) {
    if (nbytes == 0)
        return null_str;
    if (nbytes == 1 && (unsigned char)str[0] < ASCII_CHAR_TABLE_SIZE)
        return &ascii_char_strs[(unsigned char)str[0]];

    int64_t nchars = str_count_chars(str, nbytes, error);
    B_str res;
    if (copy) {
        NEW_UNFILLED_STR(res, nchars, nbytes);
        memcpy(res->str, str, nbytes);
    } else {
        res = acton_malloc(sizeof(struct B_str));
        res->$class = &B_strG_methods;
        res->nbytes = nbytes;
        res->nchars = nchars;
        res->str = (unsigned char *)str;
    }
    return res;
}

B_str actStrFromCString(const char *str) {
    return str_from_c(str, strlen(str), false, &B_str_invalid_utf8_error);
}

B_str actStrFromCStringCopy(const char *str) {
    return str_from_c(str, strlen(str), true, &B_str_invalid_utf8_error);
}

B_str actStrFromCStringLength(const char *str, int64_t nbytes) {
    return str_from_c(str, nbytes, false, &B_str_invalid_utf8_error);
}

B_str actStrFromCStringLengthCopy(const char *str, int64_t nbytes) {
    return str_from_c(str, nbytes, true, &B_str_invalid_utf8_error);
}

B_str actStrFromLiteral(const char *str, int64_t nbytes, int64_t nchars) {
    if (nbytes == 0)
        return null_str;
    if (nbytes == 1 && (unsigned char)str[0] < ASCII_CHAR_TABLE_SIZE)
        return &ascii_char_strs[(unsigned char)str[0]];
    B_str res = acton_malloc(sizeof(struct B_str));
    res->$class = &B_strG_methods;
    res->nbytes = nbytes;
    res->nchars = nchars;
    res->str = (unsigned char *)str;
    return res;
}

// Keep the old ownership contracts and diagnostics during migration.
B_str to$str(char *str) {
    return str_from_c(str, strlen(str), true, &B_str_invalid_utf8_copy_error);
}

B_str to_str_len(const char *str, int64_t nbytes) {
    return actStrFromCStringLengthCopy(str, nbytes);
}

B_str to_str_noc(char *str) {
    int64_t nbytes = strlen(str);
    int64_t nchars = str_count_chars(str, nbytes, &B_str_invalid_utf8_nocopy_error);
    B_str res = acton_malloc(sizeof(struct B_str));
    res->$class = &B_strG_methods;
    res->nbytes = nbytes;
    res->nchars = nchars;
    res->str = (unsigned char *)str;
    return res;
}

unsigned char *fromB_str(B_str str) {
    return str->str;
}

const char *actStrToCString(B_str s, B_ValueError nul_error) {
    if (memchr(s->str, 0, s->nbytes))
        RAISE_EXC(nul_error);
    char *res = (char *)alloc_data(s->nbytes + 1);
    memcpy(res, s->str, s->nbytes);
    res[s->nbytes] = '\0';
    return res;
}

// #bytes in UTF-8 to represent codepoint cp
static int byte_length(unsigned int cp) {
    if (cp < 0x80)
        return 1;
    else if (cp < 0x800)
        return 2;
    else if (cp < 0x10000)
        return 3;
    else
        return 4;
}

// #bytes in UTF-8 for char starting with byte c
static int byte_length2(unsigned char c) {
    if (c < 0x80)
        return 1;
    else if (c < 0xe0)
        return 2;
    else if (c < 0xf0)
        return 3;
    else
        return 4;
}

// #chars in a byte range of valid UTF-8: the bytes that start a char
static int64_t count_chars(unsigned char *p, int64_t nbytes) {
    int64_t n = 0;
    for (int64_t i = 0; i < nbytes; i++)
        n += (p[i] & 0xc0) != 0x80;
    return n;
}

typedef utf8proc_int32_t (*transform)(utf8proc_int32_t codepoint);

// Mapping codepoint transforms over an entire string: first for the first
// character and rest for the others. Used by upper, lower and capitalize.
// A transform can change the UTF-8 length of a character, so the first pass
// computes the length of the result and the second one writes it.
static B_str str_transform(B_str s, transform first, transform rest) {
    if (s->nchars == 0) {
        return null_str;
    }
    unsigned char tmp[4];
    utf8proc_int32_t cp;
    int64_t nbytes = 0;
    unsigned char *p = s->str;
    for (int64_t i = 0; i < s->nchars; i++) {
        p += utf8proc_iterate(p, -1, &cp);
        nbytes += utf8proc_encode_char(i == 0 ? first(cp) : rest(cp), tmp);
    }
    check_result_len(nbytes);
    B_str res;
    NEW_UNFILLED_STR(res, s->nchars, nbytes);
    p = s->str;
    unsigned char *up = res->str;
    for (int64_t i = 0; i < s->nchars; i++) {
        p += utf8proc_iterate(p, -1, &cp);
        up += utf8proc_encode_char(i == 0 ? first(cp) : rest(cp), up);
    }
    return res;
}

// Find char position in text from byte position.
// Assume that i is first byte of a char in text.
int64_t $char_no(B_str text, int64_t i) {
    if (text->nbytes == text->nchars) // ASCII string
        return i;
    int64_t res = 0;
    int64_t k=0;
    unsigned char *t = text->str;
    while (k<i) {
        k += byte_length2(t[k]);
        res++;
    }
    return res;
}

static unsigned char *skip_chars(unsigned char* start, int64_t n, int isascii) {
    unsigned char *res = start;
    if (isascii)
        return start+n;
    if (n >= 0) {
        for (int64_t i=0; i<n; i++)
            res += byte_length2(*res);
    } else {
        for (int64_t i= 0; i<-n; i++) {
            res--;
            while (*res >> 6 == 2) res--;
        }
    }
    return res;
}


// Find byte position in text from char position.
// Assume i is a valid char index in text
int64_t $byte_no(B_str text, int64_t i) {
    if (text->nbytes == text->nchars) // ASCII string
        return i;
    int64_t res = 0;
    unsigned char *t = text->str;
    for (int64_t k=0; k<i; k++)
        res += byte_length2(t[res]);
    return res;
}

// Handles negative indices in getitem etc (slice notation)
static int64_t get_index(int64_t i, int64_t nchars) {
    if (i >= 0) {
        if (i<nchars)
            return i;
    } else {
        if (i >= -nchars)
            return nchars+i;
    }
    RAISE(B_IndexError, i, actStrFromCString("index outside str"));
    return 0;
}


// Eliminates slice notation in find, index, count and other methods. As for
// slice indices, a negative index counts from the end, so -1 is the last
// position, and indices outside the string are clamped to it. Returns -1 if
// start is beyond the end. Omitted arguments have already been expanded to 0
// and INT64_MAX by the compiler; the latter is clamped to nchars below.
static int fix_start_end(int64_t nchars, int64_t *start, int64_t *end) {
    int64_t st = *start;
    if (st > nchars) {
        return -1;
    }
    if (st < 0)
        st += nchars;
    *start = st < 0 ? 0 : st;

    int64_t en = *end;
    if (en > nchars)
        en = nchars;
    else if (en < 0)
        en += nchars;
    *end = en < 0 ? 0 : en;
    return 0;
}

// Builds a new one-char string starting at p.
static B_str mk_char(unsigned char *p) {
    unsigned char c = *p;
    if (c < ASCII_CHAR_TABLE_SIZE)
        return &ascii_char_strs[c];

    B_str res;
    NEW_UNFILLED_STR(res,1,byte_length2(*p));
    for (int64_t i=0; i<res->nbytes; i++)
        res->str[i] = p[i];
    return res;
}

int equal_bytes(unsigned char *p, unsigned char *q, int64_t len) {
    int64_t i;
    for (i=0; i<len; i++) {
        if (p[i] != q[i]) break;
    }
    return i==len;
}

static int isspace_codepoint(int codepoint) {
    int cat = utf8proc_get_property(codepoint)->category;
    int bidi = utf8proc_get_property(codepoint)->bidi_class;
    return (cat == UTF8PROC_CATEGORY_ZS || (bidi >= UTF8PROC_BIDI_CLASS_B && bidi <= UTF8PROC_BIDI_CLASS_WS));
}

static int islinebreak_codepoint(int codepoint) {
    // category not useful; all the seven codepoints we handle are in category Other, control.
    return (codepoint >= 0x0a && codepoint <= 0x0d) ||
        (codepoint >= 0x1c && codepoint <= 0x1e);
    // For now we ignore the three codepoints below which are counted as linebreaks by
    // Python's splitlines for strings.
    //  || codepoint == 0x85 || codepoint == 0x2028 ||codepoint == 0x2029;

}

// The Boyer-Moore-Horspool algorithm for searching for pattern in text.
// For very short patterns, this should be replaced by brute force.
// Returns byte position in text where first occurrence of pattern starts,
// or -1 if it does not occur.
// Start search from the left end of text.
int64_t bmh( unsigned char *text, unsigned char *pattern, int64_t tbytes, int64_t pbytes) {
    if (pbytes>tbytes) return -1;
    int64_t skip[256];
    for (int i=0; i<256; i++) skip[i] = pbytes;
    for (int64_t i=0; i<pbytes-1; i++)
        skip[(int)pattern[i]] = pbytes-i-1;
    int64_t k = pbytes-1;
    int64_t i, j;
    while (k<tbytes) {
        j = pbytes-1;
        i = k;
        while (j >=0 && text[i] == pattern[j]) {
            j--; i--;
        }
        if (j==-1) return i+1;
        k += skip[(int)text[k]];
    }
    return -1;
}

// Start search from the right end of text.
static int64_t rbmh( unsigned char *text, unsigned char *pattern, int64_t tbytes, int64_t pbytes) {
    if (pbytes>tbytes) return -1;
    int64_t skip[256];
    for (int i=0; i<256; i++) skip[i] = pbytes;
    for (int64_t i=pbytes-1; i>0; i--)
        skip[(int)pattern[i]] = i;
    int64_t k = tbytes - pbytes;
    int64_t i, j;
    while (k >= 0) {
        j = 0;
        i = k;
        while (j < pbytes && text[i] == pattern[j]) {
            j++; i++;
        }
        if (j==pbytes) return i-pbytes;
        k -= skip[(int)text[k]];
    }
    return -1;
}

struct byte_counts {
    int64_t printable, squotes, dquotes, escaped, non_printable, non_ascii, braces;
};


struct byte_counts byte_count(unsigned char *s, int64_t len) {
   struct byte_counts res = {0,0,0,0,0,0,0};
    unsigned char c;
    for (int64_t i=0; i<len; i++) {
        c = s[i];
        if (c=='\\' || c=='\n' || c=='\t' || c=='\r')
            res.escaped++;
        else if (c < 32 || c == 127)
            res.non_printable++;
        else if (c=='\'')
            res.squotes++;
        else if (c=='"')
            res.dquotes++;
        else if (c=='{' || c=='}')
            res.braces++;
        else if (c<127)
            res.printable++;
        else
            res.non_ascii++;
    }
    return res;
}

// bytes and bytearray have no encoding, so case mapping only changes the
// ASCII letters. ctype toupper/tolower would depend on the C locale.
static unsigned char ascii_toupper(unsigned char c) {
    return c >= 'a' && c <= 'z' ? c - 'a' + 'A' : c;
}

static unsigned char ascii_tolower(unsigned char c) {
    return c >= 'A' && c <= 'Z' ? c - 'A' + 'a' : c;
}

// Tab expansion for bytes and bytearray. Every byte other than tab, newline
// and carriage return takes one column; newline and carriage return reset
// the column. Returns the length of the result and, unless out is NULL,
// writes the result to out.
static int64_t expandtabs_bytes(unsigned char *in, int64_t nbytes, int64_t tabsize, unsigned char *out) {
    int64_t len = 0;
    int64_t col = 0;
    for (int64_t i = 0; i < nbytes; i++) {
        unsigned char c = in[i];
        if (c == '\t') {
            int64_t n = tabsize - col % tabsize;
            if (n > MAX_STR_LEN - len)
                RAISE_EXC(&B_str_expandtabs_too_long_error);
            if (out)
                memset(out + len, ' ', n);
            len += n;
            col += n;
        } else {
            if (len == MAX_STR_LEN)
                RAISE_EXC(&B_str_expandtabs_too_long_error);
            if (out)
                out[len] = c;
            len++;
            col = c == '\n' || c == '\r' ? 0 : col + 1;
        }
    }
    return len;
}

// Tab expansion for str, the same as for bytes except that columns count
// characters: a character takes one column whatever its UTF-8 length.
// Returns the length of the result in bytes, sets *nchars to its length in
// characters and, unless out is NULL, writes the result to out.
static int64_t expandtabs_str(unsigned char *in, int64_t nbytes, int64_t tabsize, unsigned char *out, int64_t *nchars) {
    int64_t len = 0;
    int64_t chars = 0;
    int64_t col = 0;
    unsigned char *p = in;
    unsigned char *end = in + nbytes;
    while (p < end) {
        if (*p == '\t') {
            int64_t n = tabsize - col % tabsize;
            if (n > MAX_STR_LEN - len)
                RAISE_EXC(&B_str_expandtabs_too_long_error);
            if (out)
                memset(out + len, ' ', n);
            len += n;
            chars += n;
            col += n;
            p++;
        } else {
            int n = byte_length2(*p);
            if (n > MAX_STR_LEN - len)
                RAISE_EXC(&B_str_expandtabs_too_long_error);
            if (out)
                memcpy(out + len, p, n);
            len += n;
            chars++;
            col = *p == '\n' || *p == '\r' ? 0 : col + 1;
            p += n;
        }
    }
    *nchars = chars;
    return len;
}

void escape_str(unsigned char *out, unsigned char *in, int64_t outlen, int64_t inlen, int max_esc, bool esc_squote, bool esc_dquote, bool esc_braces, bool esc_triple_dquote) {
    unsigned char *hexdigits = (unsigned char *)"0123456789abcdef";
    unsigned char *p = out;
    for (int64_t i=0; i<inlen; i++) {
        unsigned char c = in[i];

        // Handle """ sequences if requested
        if (esc_triple_dquote && i + 2 < inlen && c == '"' && in[i+1] == '"' && in[i+2] == '"') {
            // Escape all three quotes: """ -> \"\"\"
            *p = '\\'; p++;
            *p = '"'; p++;
            *p = '\\'; p++;
            *p = '"'; p++;
            *p = '\\'; p++;
            *p = '"'; p++;
            i += 2;  // Skip the other two quotes
            continue;
        }

        if ((c < 32 && c != '\t' && c != '\r' && c != '\n') || ( c > 126 && c <= max_esc)) {
            *p = '\\'; p++;
            *p = 'x'; p++;
            *p = hexdigits[c >> 4]; p++;
            *p = hexdigits[c & 0xf]; p++;
        } else {
            switch (c) {
            case '\\':
                *p = '\\'; p++;
                *p = '\\'; p++;
                break;
            case '\'':
                if (esc_squote) {
                    *p = '\\'; p++;
                }
                *p = '\''; p++;
                break;
            case '"':
                if (esc_dquote) {
                    *p = '\\'; p++;
                }
                *p = '"'; p++;
                break;
            case '{':
                if (esc_braces) {
                    *p = '{'; p++;
                }
                *p = '{'; p++;
                break;
            case '}':
                if (esc_braces) {
                    *p = '}'; p++;
                }
                *p = '}'; p++;
                break;
            case '\t':
                *p = '\\'; p++;
                *p = 't'; p++;
                break;
            case '\n':
                *p = '\\'; p++;
                *p = 'n'; p++;
                break;
            case '\r':
                *p = '\\'; p++;
                *p = 'r'; p++;
                break;
            default:
                *p = c; p++;
            }
        }
    }
}



// General methods //////////////////////////////////////////////////////////////

B_str B_strG_new(B_value s) {
    B_str res = s == B_None ? B_None_str : s->$class->__str__(s);
    if (res->$class == &B_strG_methods)
        return res;
    B_str self = acton_malloc(sizeof(struct B_str));
    *self = *res;
    self->$class = &B_strG_methods;
    return self;
}

B_NoneType B_strD___init__(B_str self, B_value s) {
    B_str res = s == B_None ? B_None_str : s->$class->__str__(s);
    self->nchars = res->nchars;
    self->nbytes = res->nbytes;
    self->str = res->str;
    return B_None;
}

bool B_strD___bool__(B_str s) {
    return s->nchars > 0;
};

B_str B_strD___str__(B_str s) {
    return s;
}


B_str B_strD___repr__(B_str s) {
    struct byte_counts bs = byte_count(s->str, s->nbytes);
    // We aim to produce a simple, readable representation of the string
    // - Default to single quotes unless string contains single quotes
    // - Use double quotes if string contains single quotes
    // - Use triple quotes (""") if both quote types are present
    // - If """ appears in the content, escape it as \"\"\"

    bool use_triple_quotes = (bs.dquotes > 0 && bs.squotes > 0); // Use triple quotes if both types are present
    bool use_double_quotes = false;  // Default to single quotes

    if (use_triple_quotes) {
        // Always use """ for triple quotes
        use_double_quotes = true;
    } else {
        // Simple case: use single quotes unless string contains single quotes
        use_double_quotes = (bs.squotes > 0);
    }

    int quotes_per_side = use_triple_quotes ? 3 : 1;
    int quote_bytes = quotes_per_side * 2;

    // Count how many """ sequences need escaping (only relevant if using """ delimiters)
    int64_t escape_triple_bytes = 0;
    if (use_triple_quotes) {
        unsigned char *p = s->str;
        int64_t remaining = s->nbytes;
        int64_t pos;
        while ((pos = bmh(p, (unsigned char*)"\"\"\"", remaining, 3)) >= 0) {
            escape_triple_bytes += 3;  // Each quote needs a backslash: """ -> \"\"\"
            p += pos + 3;
            remaining = s->nbytes - (p - s->str);
        }
    }

    int64_t newbytes = (int64_t)quote_bytes + bs.escaped + 3 * (int64_t)bs.non_printable + bs.braces + escape_triple_bytes;
    check_result_len(s->nbytes + newbytes);

    B_str res;
    NEW_UNFILLED_STR(res, s->nchars + newbytes, s->nbytes + newbytes);

    char quote_char = use_double_quotes ? '"' : '\'';

    // Add opening quotes
    for (int i = 0; i < quotes_per_side; i++)
        res->str[i] = quote_char;

    escape_str(res->str + quotes_per_side, s->str, res->nbytes - quote_bytes, s->nbytes, 127, false, false, true, use_triple_quotes);

    // Add closing quotes
    for (int i = 0; i < quotes_per_side; i++)
        res->str[res->nbytes - quotes_per_side + i] = quote_char;

    return res;
}

void B_strD___serialize__(B_str str,$Serial$state state) {
    int64_t nWords = str->nbytes/sizeof($WORD) + 1;     // # $WORDS needed to store str->str, including terminating 0.
    $ROW row = $add_header(STR_ID,2+nWords,state);
    int64_t nbytes = str->nbytes;                      // We could pack nbytes and nchars in one $WORD,
    memcpy(row->blob,&nbytes,sizeof($WORD));            // but we should think of a better, general approach.
    int64_t nchars = str->nchars;
    memcpy(row->blob+1,&nchars,sizeof($WORD));
    memcpy(row->blob+2,str->str,nbytes+1);
}

B_str B_strD___deserialize__(B_str self, $Serial$state state) {
    $ROW this = state->row;
    state->row =this->next;
    state->row_no++;
    B_str res = acton_malloc(sizeof(struct B_str));
    int64_t nbytes;
    memcpy(&nbytes,this->blob,sizeof($WORD));
    res->$class = &B_strG_methods;
    res->nbytes = nbytes;
    int64_t nchars;
    memcpy(&nchars,this->blob+1,sizeof($WORD));
    res->nchars = nchars;
    res->str = alloc_data(nbytes+1);
    memcpy(res->str,this->blob+2,nbytes+1);
    return res;
}


// str-specific methods ////////////////////////////////////////////////////////

B_str B_strD_capitalize(B_str s) {
    return str_transform(s,utf8proc_totitle,utf8proc_tolower);
}

B_str B_strD_center(B_str s, int64_t width, B_str fill) {
    if (!fill)
        fill = space_str;
    if (fill->nchars != 1) {
        RAISE_EXC(&B_str_invalid_center_fill_error);
    }
    if (width <= s->nchars) {
        return s;
    }
    int64_t pad = width - s->nchars;
    int64_t padleft = pad / 2; // Below we make use of the fact padright >= padleft.
    int64_t padright = pad - padleft;
    int64_t fillbytes = fill->nbytes;
    int64_t sbytes = s->nbytes;
    // pad is checked on its own first, so pad * fillbytes can't overflow
    check_result_len(pad);
    check_result_len(sbytes + pad * fillbytes);
    B_str res;
    NEW_UNFILLED_STR(res, width, sbytes + pad * fillbytes);
    unsigned char *c = fill->str;
    unsigned char *p = res->str;
    p += padleft * fillbytes + sbytes;
    for (int64_t i = 0; i < padright; i++) {
        for (int64_t j = 0; j < fillbytes; j++)
            p[j] = c[j];
        p += fillbytes;
    }
    p -= padright * fillbytes;
    memcpy(res->str, p, padleft * fillbytes);
    p -= sbytes;
    memcpy(p, s->str, sbytes);
    return res;
}


int64_t B_strD_count(B_str s, B_str sub, int64_t start, int64_t end) {
    int isascii = s->nchars == s->nbytes;
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nchars,&st,&en) < 0) return 0;
    if (sub->nbytes == 0) {
        // The empty string occurs before every character and at the end
        int64_t n = en - st;
        return n < 0 ? 0 : n + 1;
    }
    unsigned char *p = skip_chars(s->str,st,isascii);
    unsigned char *q = skip_chars(p,en-st,isascii);
    int64_t res = 0;
    int64_t n = bmh(p, sub->str, q-p, sub->nbytes);
    while (n>=0) {
        res++;
        p += n + (sub->nbytes>0 ? sub->nbytes : 1);
        n = bmh(p,sub->str,q-p,sub->nbytes);
    }
    return res;
}

B_bytes B_strD_encode(B_str s) {
    B_bytes res;
    NEW_UNFILLED_BYTES(res,s->nbytes);
    memcpy(res->str,s->str,s->nbytes);
    return res;
}

bool B_strD_endswith(B_str s, B_str sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nchars,&st,&en) < 0) return false;
    if (en-st < sub->nchars) return false;
    int isascii = s->nchars==s->nbytes;
    unsigned char *q = skip_chars(s->str+s->nbytes,en-s->nchars,isascii);
    if (q-s->str < sub->nbytes) return false;
    return memcmp(q-sub->nbytes, sub->str, sub->nbytes) == 0;
}

B_str B_strD_expandtabs(B_str s, B_int tabsize){
    if (s->nchars == 0) {
        return null_str;
    }
    int64_t tabsz = tabsize ? fromB_int(tabsize) : 8;
    tabsz = tabsz <= 0 ? 1 : tabsz;
    int64_t nchars;
    int64_t nbytes = expandtabs_str(s->str, s->nbytes, tabsz, NULL, &nchars);
    B_str res;
    NEW_UNFILLED_STR(res,nchars,nbytes);
    expandtabs_str(s->str, s->nbytes, tabsz, res->str, &nchars);
    return res;
}

int64_t B_strD_find(B_str s, B_str sub, int64_t start, int64_t end) {
    int isascii = s->nchars == s->nbytes;
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nchars,&st,&en) < 0) return -1;
    unsigned char *p = skip_chars(s->str,st,isascii);
    unsigned char *q = skip_chars(p,en-st,isascii);
    int64_t n = bmh(p, sub->str, q-p, sub->nbytes);
    if (n<0) return -1;
    return $char_no(s,n+p-s->str);
}

int64_t B_strD_index(B_str s, B_str sub, int64_t start, int64_t end) {
   int64_t n = B_strD_find(s,sub,start,end);
    if (n<0) {
        RAISE_EXC(&B_str_substring_not_found_error);
    }
    return n;
}

bool B_strD_isalnum(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if ((cat <  UTF8PROC_CATEGORY_LU || cat >  UTF8PROC_CATEGORY_LO) && cat != UTF8PROC_CATEGORY_ND)
            return false;
        p += nbytes;
    }
    return true;
}

bool B_strD_isalpha(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if (cat <  UTF8PROC_CATEGORY_LU || cat >  UTF8PROC_CATEGORY_LO)
            return false;
        p += nbytes;
    }
    return true;
}

bool B_strD_isascii(B_str s) {
    unsigned char *p = s->str;
    for (int64_t i=0; i < s->nbytes; i++) {
        if (*p > 127)
            return false;
        p++;
    }
    return true;
}

bool B_strD_isdecimal(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if (cat != UTF8PROC_CATEGORY_ND)
            return false;
        p += nbytes;
    }
    return true;
}

bool B_strD_islower(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    bool has_cased = false;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if (cat == UTF8PROC_CATEGORY_LT|| cat == UTF8PROC_CATEGORY_LU)
            return false;
        if (cat == UTF8PROC_CATEGORY_LL)
            has_cased = true;
        p += nbytes;
    }
    return has_cased;
}

bool B_strD_isprintable(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if (cat >= UTF8PROC_CATEGORY_ZS && codepoint != 0x20)
            return false;
        p += nbytes;
    }
    return true;
}

bool B_strD_isspace(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        if (!isspace_codepoint(codepoint))
            return false;
        p += nbytes;
    }
    return true;
}

bool B_strD_istitle(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    int hascased = false;
    bool incasedrun = false;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if (cat == UTF8PROC_CATEGORY_LU || cat == UTF8PROC_CATEGORY_LT ) {
            hascased = true;
            if (incasedrun)
                return false;
            incasedrun = true;
        } else if (cat == UTF8PROC_CATEGORY_LL) {
            hascased = true;
            if (!incasedrun)
                return false;
        } else
            incasedrun = false;
        p += nbytes;
    }
    return hascased;
}

bool B_strD_isupper(B_str s) {
    unsigned char *p = s->str;
    int codepoint;
    int nbytes;
    int hascased = false;
    if (s->nchars == 0)
        return false;
    for (int64_t i=0; i < s->nchars; i++) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if (cat == UTF8PROC_CATEGORY_LL)
            return false;
        if (cat == UTF8PROC_CATEGORY_LU || cat == UTF8PROC_CATEGORY_LT)
            hascased = true;
        p += nbytes;
    }
    return hascased;
}

// Joining needs two passes over its input: one to size the result and one to
// fill it.  General iterables therefore have to be materialized.  A builtin
// list or ilist already provides stable contiguous storage for both passes,
// so borrowing it avoids constructing an identical temporary list.
static B_list_base join_parts(B_Iterable wit, $WORD iter) {
    if (iter &&
        (wit == (B_Iterable)B_CollectionD_SequenceD_listG_witness ||
         wit == (B_Iterable)B_CollectionD_ISequenceD_ilistG_witness))
        return (B_list_base)iter;

    B_CollectionD_SequenceD_list list_wit = B_CollectionD_SequenceD_listG_witness;
    return (B_list_base)list_wit->$class->__fromiter__(list_wit, wit, iter);
}

B_str B_strD_join(B_str s, B_Iterable wit, $WORD iter) {
    int64_t totchars = 0;
    int64_t totbytes = 0;
    B_list_base lst = join_parts(wit, iter);
    B_str nxt;
    int64_t len = lst->length;
    // The total is checked as it grows by a part and a separator, so it
    // can't overflow before it is checked
    for (int64_t i = 0; i < len; i++) {
        nxt = (B_str)lst->data[i];
        totchars += nxt->nchars + (i > 0 ? s->nchars : 0);
        totbytes += nxt->nbytes + (i > 0 ? s->nbytes : 0);
        check_result_len(totbytes);
    }
    B_str res;
    NEW_UNFILLED_STR(res, totchars, totbytes);
    if (len > 0) {
        nxt = (B_str)lst->data[0];
        unsigned char *p = res->str;
        memcpy(p, nxt->str, nxt->nbytes);
        p += nxt->nbytes;
        for (int64_t i = 1; i < len; i++) {
            nxt = (B_str)lst->data[i];
            memcpy(p, s->str, s->nbytes);
            p += s->nbytes;
            memcpy(p, nxt->str, nxt->nbytes);
            p += nxt->nbytes;
        }
    }
    return res;
}

B_str B_strD_ljust(B_str s, int64_t width, B_str fill) {
    if (!fill) fill = space_str;
    if (fill->nchars != 1) {
        RAISE_EXC(&B_str_invalid_ljust_fill_error);
    }
    if (width <= s->nchars) {
        return s;
    }
    int64_t pad = width - s->nchars;
    // pad is checked on its own first, so pad * fill->nbytes can't overflow
    check_result_len(pad);
    int64_t nbytes = s->nbytes + pad * fill->nbytes;
    check_result_len(nbytes);
    B_str res;
    NEW_UNFILLED_STR(res, width, nbytes);
    unsigned char *c = fill->str;
    unsigned char *p = res->str + s->nbytes;
    for (int64_t i = 0; i < pad; i++) {
        for (int64_t j = 0; j < fill->nbytes; j++)
            *p++ = c[j];
    }
    memcpy(res->str, s->str, s->nbytes);
    return res;
}

B_str B_strD_lower(B_str s) {
    return str_transform(s,utf8proc_tolower,utf8proc_tolower);
}


B_str B_strD_lstrip(B_str s, B_str cs) {
    if (s->nchars == 0) return s;
    if (cs==NULL) cs = whitespace_str;
    unsigned char *p = s->str;
    int64_t i, k;
    for (i = 0; i < s->nchars; i++) {
        unsigned char *q = cs->str;
        for (k = 0; k < cs->nchars; k++) {
            if (equal_bytes(p,q,byte_length2(*q)))
                break;
            else
                q +=  byte_length2(*q);
        }
        if (k == cs->nchars) break;
        p +=  byte_length2(*p);
    }
    B_str res;
    NEW_UNFILLED_STR(res,s->nchars-i,s->str+s->nbytes-p);
    memcpy(res->str,p,res->nbytes);
    return res;
}

B_tuple B_strD_partition(B_str s, B_str sep) {
    int64_t n = B_strD_find(s,sep,0,INT64_MAX);
    if (n<0) {
        return $NEWTUPLE(3,s,null_str,null_str);
    } else {
        int64_t nb = bmh(s->str, sep->str, s->nbytes, sep->nbytes);
        B_str ls;
        NEW_UNFILLED_STR(ls,n,nb);
        memcpy(ls->str,s->str,nb);
        B_str rs;
        int64_t nbr = s->nbytes - sep->nbytes - nb;
        NEW_UNFILLED_STR(rs,s->nchars-n-sep->nchars,nbr);
        memcpy(rs->str,s->str+nb+sep->nbytes,nbr);
        return $NEWTUPLE(3,ls,sep,rs);
    }
}

B_str B_strD_replace(B_str s, B_str old, B_str new, B_int count) {
    // A negative count, like no count, replaces every occurrence
    if (count == NULL || fromB_int(count) < 0)
        count = toB_int(INT64_MAX);
    int64_t c = B_strD_count(s, old, 0, INT64_MAX);
    int64_t c0 = fromB_int(count) < c ? fromB_int(count) : c;
    if (c0 == 0) {
        return s;
    }
    // The result can be far longer than the input. The count times the
    // growth of each replacement could overflow, so the count is checked
    // against how many replacements fit instead.
    int64_t growth = new->nbytes - old->nbytes;
    if (growth > 0 && c0 > (MAX_STR_LEN - s->nbytes) / growth)
        RAISE_EXC(&B_str_too_long_error);
    int64_t nbytes = s->nbytes + c0 * growth;
    int64_t nchars = s->nchars + c0 * (new->nchars - old->nchars);
    B_str res;
    NEW_UNFILLED_STR(res, nchars, nbytes);
    unsigned char *p = s->str;
    unsigned char *q = res->str;
    unsigned char *pold = old->str;
    unsigned char *pnew = new->str;
    int64_t plen = s->nbytes;
    int64_t n;
    for (int64_t i = 0; i < c0; i++) {
        // An empty old string occurs before every character: step over one
        // character, not one byte
        n = i > 0 && old->nbytes == 0 ? byte_length2(*p) : bmh(p, pold, plen, old->nbytes);
        if (n > 0) {
            memcpy(q, p, n);
            p += n; q += n;
        }
        memcpy(q, pnew, new->nbytes);
        p += old->nbytes;
        q += new->nbytes;
        plen -= n + old->nbytes;
    }
    if (plen > 0)
        memcpy(q, p, plen);
    return res;
}


int64_t B_strD_rfind(B_str s, B_str sub, int64_t start, int64_t end) {
    int isascii = s->nchars == s->nbytes;
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nchars,&st,&en) < 0) return -1;
    unsigned char *p = skip_chars(s->str,st,isascii);
    unsigned char *q = skip_chars(p,en-st,isascii);
    int64_t n = rbmh(p, sub->str, q-p, sub->nbytes);
    if (n<0) return -1;
    return $char_no(s,n+p-s->str);
}


int64_t B_strD_rindex(B_str s, B_str sub, int64_t start, int64_t end) {
    int64_t n = B_strD_rfind(s,sub,start,end);
    if (n<0) {
        RAISE_EXC(&B_str_rsubstring_not_found_error);
    };
    return n;
}

B_str B_strD_rjust(B_str s, int64_t width, B_str fill) {
    if (!fill) fill = space_str;
    if (fill->nchars != 1) {
        RAISE_EXC(&B_str_invalid_rjust_fill_error);
    }
    if (width <= s->nchars) {
        return s;
    }
    int64_t pad = width - s->nchars;
    // pad is checked on its own first, so pad * fill->nbytes can't overflow
    check_result_len(pad);
    int64_t nbytes = s->nbytes + pad * fill->nbytes;
    check_result_len(nbytes);
    B_str res;
    NEW_UNFILLED_STR(res, width, nbytes);
    unsigned char *c = fill->str;
    unsigned char *p = res->str;
    for (int64_t i = 0; i < pad; i++) {
        for (int64_t j = 0; j < fill->nbytes; j++)
            *p++ = c[j];
    }
    memcpy(p, s->str, s->nbytes);
    return res;
}

B_tuple B_strD_rpartition(B_str s, B_str sep) {
    int64_t n = B_strD_rfind(s,sep,0,INT64_MAX);
    if (n<0) {
        return $NEWTUPLE(3,null_str,null_str,s);
    } else {
        int64_t nb = rbmh(s->str, sep->str, s->nbytes, sep->nbytes);
        B_str ls;
        NEW_UNFILLED_STR(ls,n,nb);
        memcpy(ls->str,s->str,nb);
        int64_t nbr = s->nbytes - sep->nbytes - nb;
        B_str rs;
        NEW_UNFILLED_STR(rs,s->nchars-n-sep->nchars,nbr);
        memcpy(rs->str,s->str+nb+sep->nbytes,nbr);
        return  $NEWTUPLE(3,ls,sep,rs);
    }
}


B_list B_strD_split(B_str s, B_str sep, B_int maxsplit) {
    B_list res = $NEW(B_list,NULL,NULL);
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    if (maxsplit == NULL || fromB_int(maxsplit) < 0) maxsplit = toB_int(INT64_MAX);
    int64_t remaining = s->nchars;
    if (sep == NULL) {
        unsigned char *p = s->str;
        int nbytes, codepoint;
        int64_t wordlength;
        if (remaining==0) {
            return res;
        }
        wordlength = 0;
        int inword = 0;
        unsigned char *q;
        while (remaining > 0) {
            nbytes = utf8proc_iterate(p,-1,&codepoint);
            if (!isspace_codepoint(codepoint)) {
                if (!inword) {
                    inword = 1;
                    q = p;
                    wordlength = 1;
                    if (res->length == fromB_int(maxsplit))
                        break; // we have now removed leading whitespace in remainder
                } else
                    wordlength++;
            } else {
                if (inword) {
                    inword = 0;
                    B_str word;
                    NEW_UNFILLED_STR(word,wordlength,p-q);
                    memcpy(word->str,q,p-q);
                    wit->$class->append(wit,res,word);
                    wordlength = 0;
                }
            }
            remaining--;
            p += nbytes;
        }
        // this if statement should be simplified; almost code duplication.
        if (remaining == 0) {
            if (inword) {
                B_str word;
                NEW_UNFILLED_STR(word,wordlength,p-q);
                memcpy(word->str,q,p-q);
                wit->$class->append(wit,res,word);
            }
        } else {
            B_str word;
            p = s->str+s->nbytes;
            NEW_UNFILLED_STR(word,remaining,p-q);
            memcpy(word->str,q,p-q);
            wit->$class->append(wit,res,word);
        }
        // $WORD w = list_getitem(res,0);
        return res;
    } else { // separator given
        if (sep->nchars==0) {
            RAISE_EXC(&B_str_empty_separator_error);
        }
        // Search for each separator from the end of the previous one and
        // copy every piece once
        int isascii = s->nchars == s->nbytes;
        int64_t maxs = fromB_int(maxsplit);
        unsigned char *p = s->str;
        int64_t rest = s->nbytes;
        int64_t n;
        while (res->length < maxs && (n = bmh(p,sep->str,rest,sep->nbytes)) >= 0) {
            int64_t nchars = isascii ? n : count_chars(p, n);
            B_str word;
            NEW_UNFILLED_STR(word,nchars,n);
            memcpy(word->str,p,n);
            wit->$class->append(wit,res,word);
            p += n + sep->nbytes;
            rest -= n + sep->nbytes;
        }
        int64_t nchars = isascii ? rest : count_chars(p, rest);
        B_str word;
        NEW_UNFILLED_STR(word,nchars,rest);
        memcpy(word->str,p,rest);
        wit->$class->append(wit,res,word);
        return res;
    }
}

B_list B_strD_splitlines(B_str s, B_bool keepends) {
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    if (!keepends)
        keepends = B_False;
    B_list res = $NEW(B_list,NULL,NULL);
    unsigned char *p = s->str;
    unsigned char *q = p;
    int nbytes, codepoint;
    int64_t linelength;
    if (s->nbytes==0) {
        return res;
    }
    linelength = 0;
    while (p < s->str + s->nbytes) {
        nbytes = utf8proc_iterate(p,-1,&codepoint);
        utf8proc_category_t cat = utf8proc_category(codepoint);
        if (!islinebreak_codepoint(codepoint)) {
            linelength++;
            p += nbytes;
        } else {
            // all the codepoints we count as linebreaks are ascii bytes, i.e. nbytes = 1.
            B_str line;
            int winend = *p=='\r' && *(p+1)=='\n';
            int64_t size = p-q + (keepends->val ? 1 + winend : 0);
            NEW_UNFILLED_STR(line,linelength + (keepends->val ? 1 + winend : 0),size);
            memcpy(line->str,q,size);
            p += 1 + winend;
            q = p;
            wit->$class->append(wit,res,line);
            linelength = 0;
        }
    }
    if (q < p) {
        B_str line;
        NEW_UNFILLED_STR(line,linelength,p-q);
        memcpy(line->str,q,p-q);
        wit->$class->append(wit,res,line);
    }
    return res;
}

B_str B_strD_rstrip(B_str s, B_str cs) {
    if (s->nchars == 0) return s;
    if (cs==NULL) cs = whitespace_str;
    unsigned char *end = s->str + s->nbytes;   // exclusive end of the result
    int64_t i, k;
    for (i = 0; i < s->nchars; i++) {
        unsigned char *p = skip_chars(end,-1,0); // last char before end
        unsigned char *q = cs->str;
        for (k = 0; k < cs->nchars; k++) {
            if (equal_bytes(p,q,byte_length2(*q)))
                break;
            else
                q += byte_length2(*q);
        }
        if (k == cs->nchars) break;
        end = p;
    }
    B_str res;
    NEW_UNFILLED_STR(res,s->nchars-i,end-s->str);
    memcpy(res->str,s->str,res->nbytes);
    return res;
}

bool B_strD_startswith(B_str s, B_str sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nchars,&st,&en) < 0) return false;
    if (en-st < sub->nchars) return false;
    int isascii = s->nchars==s->nbytes;
    unsigned char *p = skip_chars(s->str,st,isascii);
    if (s->str+s->nbytes-p < sub->nbytes) return false;
    return memcmp(p, sub->str, sub->nbytes) == 0;
}


B_str B_strD_strip(B_str s, B_str cs) {
    return B_strD_lstrip(B_strD_rstrip(s,cs),cs);
}

B_str B_strD_upper(B_str s) {
    return str_transform(s,utf8proc_toupper,utf8proc_toupper);
}

B_str B_strD_zfill(B_str s, int64_t width) {
    if (width < s->nchars)
        return s;
    int64_t fill = width - s->nchars;
    // fill is checked on its own first, so the sum can't overflow
    check_result_len(fill);
    check_result_len(s->nbytes + fill);
    B_str res;
    NEW_UNFILLED_STR(res, width, s->nbytes + fill);
    unsigned char *p = s->str;
    unsigned char *q = res->str;
    int64_t hassign = s->nbytes > 0 && (*p == '+' || *p == '-');
    if (hassign) {
        *q = *p;
        q++;
    }
    for (int64_t i = 0; i < fill; i++)
        *q++ = '0';
    memcpy(res->str + hassign + fill, s->str + hassign, s->nbytes - hassign);
    return res;
}



// Protocol methods; string implementations /////////////////////////////////////////////////////////////////////////////
/*
   Note: We make str instances for Indexed and Sliceable even though these protocols
   include mutating methods.
*/

// B_Ord ///////////////////////////////////////////////////////////////////////////////////////////////


// TODO: We should consider how to normalize strings before comparisons


// The comparisons below do lexicographic byte-wise comparisons.
// Thus they do not in general reflect locale-dependent order conventions.

static int str_compare(B_str a, B_str b) {
    int64_t size = a->nbytes < b->nbytes ? a->nbytes : b->nbytes;
    int order = memcmp(a->str, b->str, size);
    return order != 0 ? order : (a->nbytes > b->nbytes) - (a->nbytes < b->nbytes);
}

bool B_OrdD_strD___eq__ (B_OrdD_str wit, B_str a, B_str b) {
    if (a == b)
        return true;
    return a->nbytes == b->nbytes && memcmp(a->str, b->str, a->nbytes) == 0;
}

bool B_OrdD_strD___ne__ (B_OrdD_str wit, B_str a, B_str b) {
    return !B_OrdD_strD___eq__(wit, a, b);
}

bool B_OrdD_strD___lt__ (B_OrdD_str wit, B_str a, B_str b) {
    return str_compare(a, b) < 0;
}

bool B_OrdD_strD___le__ (B_OrdD_str wit, B_str a, B_str b) {
    return str_compare(a, b) <= 0;
}

bool B_OrdD_strD___gt__ (B_OrdD_str wit, B_str a, B_str b) {
    return str_compare(a, b) > 0;
}

bool B_OrdD_strD___ge__ (B_OrdD_str wit, B_str a, B_str b) {
    return str_compare(a, b) >= 0;
}

// B_Hashable ///////////////////////////////////////////////////////////////////////////////////

B_NoneType B_HashableD_strD_hash(B_HashableD_str wit, B_str a, B_hasher h) {
    zig_hash_wyhash_update(h->_hasher, (const uint8_t *)a->str, a->nbytes);
    return B_None;
}
// B_Times /////////////////////////////////////////////////////////////////////////////////////////////

B_str B_TimesD_strD___add__ (B_TimesD_str wit, B_str s, B_str t) {
    int64_t nbytes = (int64_t)s->nbytes + t->nbytes;
    check_result_len(nbytes);
    B_str res;
    NEW_UNFILLED_STR(res, (int64_t)s->nchars + t->nchars, nbytes);
    memcpy(res->str, s->str, s->nbytes);
    memcpy(res->str + s->nbytes, t->str, t->nbytes);
    return res;
}

B_str B_TimesD_strD___zero__ (B_TimesD_str wit) {
    return null_str;
}

B_str B_TimesD_strD___mul__ (B_TimesD_str wit, B_str a, B_int n) {
    int64_t nval = n->val;
    if (nval <= 0 || a->nbytes == 0)
        return null_str;
    // The count times the length could overflow, so the count is checked
    // against how many copies fit instead
    if (nval > MAX_STR_LEN / a->nbytes)
        RAISE_EXC(&B_str_too_long_error);
    int64_t nbytes = a->nbytes * nval;
    B_str res;
    NEW_UNFILLED_STR(res, a->nchars * nval, nbytes);
    for (int64_t i = 0; i < nval; i++)
        memcpy(res->str + i * a->nbytes, a->str, a->nbytes);
    return res;
}

// Collection ///////////////////////////////////////////////////////////////////////////////////////


B_str B_ContainerD_strD___fromiter__ (B_ContainerD_str wit, B_Iterable wit2, $WORD iter) {
    return B_strD_join(null_str,wit2,iter);
}

int64_t B_ContainerD_strD___len__ (B_ContainerD_str wit, B_str s){
    return (int64_t)s->nchars;
}

// B_Container ///////////////////////////////////////////////////////////////////////////


bool B_ContainerD_strD___contains__ (B_ContainerD_str wit, B_str s, B_str sub) {
    return bmh(s->str,sub->str,s->nbytes,sub->nbytes) >= 0;
}

bool B_ContainerD_strD___containsnot__ (B_ContainerD_str wit, B_str s, B_str sub) {
    return !B_ContainerD_strD___contains__(wit, s, sub);
}

// Iterable ///////////////////////////////////////////////////////////////////////////

// first define Iterator class

B_IteratorD_str B_IteratorD_strG_new(B_str str) {
    return $NEW(B_IteratorD_str, str);
}

B_NoneType B_IteratorD_strD_init(B_IteratorD_str self, B_str str) {
    self->src = str;
    self->nxt = 0;
    return B_None;
}

B_Iterator $strD_U_iter_init(B_IteratorD_str iter, B_str src) {
    iter->$class = &B_IteratorD_strG_methods;
    B_IteratorD_strD_init(iter, src);
    return (B_Iterator)iter;
}

void B_IteratorD_strD_serialize(B_IteratorD_str self,$Serial$state state) {
    $step_serialize(self->src,state);
    $step_serialize(toB_int(self->nxt),state);
}


B_IteratorD_str B_IteratorD_str$_deserialize(B_IteratorD_str res, $Serial$state state) {
    if (!res)
        res = $DNEW(B_IteratorD_str,state);
    res->src = (B_str)$step_deserialize(state);
    res->nxt = fromB_int((B_int)$step_deserialize(state));
    return res;
}

bool B_IteratorD_strD_bool(B_IteratorD_str self) {
    return true;
}

B_str B_IteratorD_strD_str(B_IteratorD_str self) {
    return $FORMAT("<str iterator object at %p>", self);
}
static bool B_IteratorD_strD_next(B_IteratorD_str self, $WORD *out) {
    if (self->nxt >= self->src->nbytes)
        return false;
    unsigned char *p = &self->src->str[self->nxt];
    B_str res;
    if (*p < ASCII_CHAR_TABLE_SIZE) {
        self->nxt++;
        res = &ascii_char_strs[*p];
    } else {
        self->nxt += byte_length2(*p);
        res = mk_char(p);
    }
    *out = (B_value)res;
    return true;
}


struct B_IteratorD_strG_class B_IteratorD_strG_methods = {"B_IteratorD_str",UNASSIGNED,($SuperG_class)&B_IteratorG_methods, B_IteratorD_strD_init,
                                                    B_IteratorD_strD_serialize, B_IteratorD_str$_deserialize,
                                                    B_IteratorD_strD_bool, B_IteratorD_strD_str, B_IteratorD_strD_str,
                                                    B_IteratorD_strD_next};

// now, define __iter__

B_Iterator B_ContainerD_strD___iter__ (B_ContainerD_str wit, B_str s) {
    return (B_Iterator)$NEW(B_IteratorD_str,s);
}


// IIndexed //////////////////////////////////////////////////////////////////////////

B_str $strD_U__getitem__(B_str s, int64_t i) {
    unsigned char *p = s->str;
    int64_t ix = get_index(i, s->nchars);
    p = skip_chars(p,ix,s->nchars == s->nbytes);
    return mk_char(p);
}

B_str B_ISliceableD_strD___getitem__ (B_ISliceableD_str wit, B_str s, B_int i) {
    return $strD_U__getitem__(s, i->val);
}

// ISliceable /////////////////////////////////////////////////////////////////////////////////////

B_str B_ISliceableD_strD___getslice__ (B_ISliceableD_str wit, B_str s, B_slice slc) {
    int isascii = s->nchars == s->nbytes;
    int64_t nchars = s->nchars;
    int64_t nbytes = 0;
    int64_t start, stop, step, slen;
    normalize_slice(slc, nchars, &slen, &start, &stop, &step);
    if (slen == 0) {
        return null_str;
    }
    //slice notation have been eliminated and default values applied.
    unsigned char *t = skip_chars(s->str,start,isascii);
    B_str res;
    if (step == 1) {
        // A contiguous run of characters, copied in one go
        unsigned char *e = skip_chars(t,slen,isascii);
        NEW_UNFILLED_STR(res,slen,e-t);
        memcpy(res->str,t,e-t);
        return res;
    }
    // The first pass computes the length of the result in bytes and the
    // second one copies the characters. Neither steps beyond the last
    // character of the slice.
    unsigned char *u = t;
    for (int64_t i=0; i<slen; i++) {
        nbytes += byte_length2(*u);
        if (i < slen-1)
            u = skip_chars(u,step,isascii);
    }
    NEW_UNFILLED_STR(res,slen,nbytes);
    unsigned char *p = res->str;
    for (int64_t i=0; i<slen; i++) {
        int bytes = byte_length2(*t);
        memcpy(p,t,bytes);
        p += bytes;
        if (i < slen-1)
            t = skip_chars(t,step,isascii);
    }
    return res;
}

// End of str implementation ////////////////////////////////////////////////////

// bytearray implementation //////////////////////////////////////////////////////////////////////////////

// Conversion to and from C strings

B_bytearray toB_bytearray(char *str) {
    B_bytearray res;
    int64_t len = strlen(str);
    NEW_UNFILLED_BYTEARRAY(res,len);
    memcpy(res->str,str,len);
    return res;
}


B_bytearray to$bytearrayD_len(char *str, int64_t len) {
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, len);
    memcpy(res->str, str, len);
    return res;
}

B_bytearray actBytearrayFromCString(char *str) {
    B_bytearray res;
    int64_t len = strlen(str);
    NEW_UNFILLED_BYTEARRAY(res,len);
    memcpy(res->str,str,len);
    return res;
}

B_bytearray actBytearrayFromCStringNoCopy(char *str) {
    B_bytearray res = acton_malloc(sizeof(struct B_bytearray));
    res->$class = &B_bytearrayG_methods;
    res->nbytes = strlen(str);
    res->str = (unsigned char*)str;
    return res;
}

B_bytearray actBytearrayFromCStringLength(char *str, int64_t len) {
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, len);
    memcpy(res->str, str, len);
    return res;
}

B_bytearray actBytearrayFromCStringLengthNoCopy(char *str, int64_t length) {
    B_bytearray res = acton_malloc(sizeof(struct B_bytearray));
    res->$class = &B_bytearrayG_methods;
    res->nbytes = length;
    res->str = (unsigned char*)str;
    return res;
}

unsigned char *fromB_bytearray(B_bytearray b) {
    return b->str;
}

// Auxiliaries

static void expand_bytearray(B_bytearray b, int64_t n) {
    int64_t needed = (int64_t)b->nbytes + n;
    if (b->capacity >= needed)
        return;
    check_result_len(needed);
    int64_t newcapacity = b->capacity == 0 ? 1 : b->capacity;
    while (newcapacity < needed)
        newcapacity <<= 1;
    // Doubling can pass the limit on lengths
    if (newcapacity > MAX_STR_LEN)
        newcapacity = MAX_STR_LEN;
    unsigned char *newstr = acton_realloc_atomic(b->str, newcapacity);
    if (newstr == NULL) {
        RAISE_EXC(&B_str_allocation_failed_error);
    }
    b->str = newstr;
    b->capacity = newcapacity;
}

static B_bytearray B_bytearrayD_copy(B_bytearray s) {
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,s->nbytes);
    res->nbytes = s->nbytes;
    memcpy(res->str,s->str,s->nbytes);
    return res;
}


// General methods

B_bytearray B_bytearrayG_new(B_bytes b) {
    return $NEW(B_bytearray, b);
}

B_NoneType B_bytearrayD___init__(B_bytearray self, B_bytes b) {
    int64_t len = b->nbytes;
    self->nbytes = len;
    self->capacity = len;
    self->str = alloc_data(len);
    memcpy(self->str,b->str,len);
    return B_None;
}

bool B_bytearrayD___bool__(B_bytearray s) {
    return s->nbytes > 0;
};

B_str B_bytearrayD___str__(B_bytearray s) {
    struct byte_counts bs = byte_count(s->str, s->nbytes);
    bool use_single_quotes = !(bs.dquotes==0 && bs.squotes>0);
    int64_t escaped_quotes = use_single_quotes ? bs.squotes : bs.dquotes;
    int64_t nbytes = (int64_t)s->nbytes + 14 + bs.escaped + 3 * (int64_t)bs.non_printable + escaped_quotes + 3 * (int64_t)bs.non_ascii;
    check_result_len(nbytes);
    B_str res;
    NEW_UNFILLED_STR(res, nbytes, nbytes);
    escape_str(res->str+12,s->str,res->nbytes-12,s->nbytes,255,use_single_quotes,!use_single_quotes,false,false);
    if (use_single_quotes) {
        res->str[11] = '\'';
        res->str[res->nbytes-2] = '\'';
    } else {
        res->str[11] = '"';
        res->str[res->nbytes-2] = '"';
    }
    memcpy(res->str, "bytearray(b",11);
    res->str[res->nbytes-1] = ')';
    return res;
}

B_str B_bytearrayD___repr__(B_bytearray s) {
    return B_bytearrayD___str__(s);
}

void B_bytearrayD___serialize__(B_bytearray str,$Serial$state state) {
    int64_t nWords = (str->nbytes + sizeof($WORD) - 1)/sizeof($WORD); // # $WORDS needed to store str->str
    $ROW row = $add_header(BYTEARRAY_ID,1+nWords,state);
    int64_t nbytes = str->nbytes;
    memcpy(row->blob,&nbytes,sizeof($WORD));
    memcpy(row->blob+1,str->str,nbytes);
}

B_bytearray B_bytearrayD___deserialize__(B_bytearray res, $Serial$state state) {
    $ROW this = state->row;
    state->row =this->next;
    state->row_no++;
    if(!res)
        res = acton_malloc(sizeof(struct B_bytearray));
    int64_t nbytes;
    memcpy(&nbytes,this->blob,sizeof($WORD));
    res->$class = &B_bytearrayG_methods;
    res->nbytes = nbytes;
    res->capacity = nbytes;
    res->str = alloc_data(nbytes);
    memcpy(res->str,this->blob+1,nbytes);
    return res;
}

// bytearray methods

B_bytearray B_bytearrayD_capitalize(B_bytearray s) {
    if (s->nbytes==0) {
        return toB_bytearray("");
    }
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,s->nbytes);
    res->str[0] = ascii_toupper(s->str[0]);
    for (int64_t i=1; i<s->nbytes; i++)
        res->str[i] = ascii_tolower(s->str[i]);
    return res;
}

B_bytearray B_bytearrayD_center(B_bytearray s, int64_t width, B_bytearray fill) {
    if (!fill) fill = space_bytearray;
    if (fill->nbytes != 1) {
        RAISE_EXC(&B_str_invalid_bytearray_center_fill_error);
    }
    if (width <= s->nbytes) {
        return B_bytearrayD_copy(s);
    }
    check_result_len(width);
    int64_t pad = width - s->nbytes;
    int64_t padleft = pad / 2;
    int64_t padright = pad - padleft;
    int64_t sbytes = s->nbytes;
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, width);
    unsigned char c = fill->str[0];
    unsigned char *p = res->str;
    p += padleft + sbytes;
    for (int64_t i = 0; i < padright; i++) {
        p[i] = c;
    }
    memcpy(res->str, p, padleft);
    p -= sbytes;
    memcpy(p, s->str, sbytes);
    return res;
}

int64_t B_bytearrayD_count(B_bytearray s, B_bytearray sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return 0;
    int64_t stval = st;
    int64_t enval = en;
    unsigned char *p = &s->str[stval];
    unsigned char *q = &p[enval-stval];
    int64_t res = 0;
    int64_t n = bmh(p, sub->str, q-p, sub->nbytes);
    while (n>=0) {
        res++;
        p += n + (sub->nbytes>0 ? sub->nbytes : 1);
        n = bmh(p,sub->str,q-p,sub->nbytes);
    }
    return res;
}

B_str B_bytearrayD_decode(B_bytearray s) {
    return actStrFromCStringLengthCopy((const char *)s->str, s->nbytes);
}

bool B_bytearrayD_endswith(B_bytearray s, B_bytearray sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return false;
    int64_t stval = st;
    int64_t enval = en;
    if (enval-stval < sub->nbytes) return false;
    return memcmp(&s->str[enval-sub->nbytes],sub->str,sub->nbytes)==0;
}

B_bytearray B_bytearrayD_expandtabs(B_bytearray s, B_int tabsz){
    int64_t tabsize = tabsz ? fromB_int(tabsz) : 8;
    tabsize = tabsize <= 0 ? 1 : tabsize;
    int64_t len = expandtabs_bytes(s->str, s->nbytes, tabsize, NULL);
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,len);
    expandtabs_bytes(s->str, s->nbytes, tabsize, res->str);
    return res;
}

int64_t B_bytearrayD_find(B_bytearray s, B_bytearray sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return -1;
    unsigned char *p = &s->str[st];
    unsigned char *q = &s->str[en];
    int64_t n = bmh(p, sub->str, q-p, sub->nbytes);
    if (n<0) return -1;
    return n+p-s->str;
}

B_bytearray B_bytearrayD_from_hex(B_str s) {
    // Each byte is represented by 2 hex chars
    int64_t strlen = s->nbytes;  // Changed from len to nbytes
    if (strlen % 2 != 0) {
        RAISE_EXC(&B_str_odd_hex_length_error);
    }

    int64_t bytelen = strlen / 2;
    char *result = (char *)alloc_data(bytelen);

    for (int64_t i = 0; i < strlen; i += 2) {
        char high = s->str[i];
        char low = s->str[i + 1];

        // Convert hex chars to values 0-15
        int high_val, low_val;

        // Handle high nibble
        if (high >= '0' && high <= '9')
            high_val = high - '0';
        else if (high >= 'a' && high <= 'f')
            high_val = high - 'a' + 10;
        else if (high >= 'A' && high <= 'F')
            high_val = high - 'A' + 10;
        else {
            RAISE_EXC(&B_str_invalid_hex_error);
        }

        // Handle low nibble
        if (low >= '0' && low <= '9')
            low_val = low - '0';
        else if (low >= 'a' && low <= 'f')
            low_val = low - 'a' + 10;
        else if (low >= 'A' && low <= 'F')
            low_val = low - 'A' + 10;
        else {
            RAISE_EXC(&B_str_invalid_hex_error);
        }

        // Combine into byte
        result[i/2] = (high_val << 4) | low_val;
    }

    return actBytearrayFromCStringLengthNoCopy(result, bytelen);
}

// Shared by bytes.hex and bytearray.hex. The result is built by length; the
// hex digits are ASCII, so it has as many chars as bytes.
static B_str hex_from_bytes(unsigned char *data, int64_t nbytes) {
    if (nbytes == 0)
        return null_str;
    // Each byte becomes 2 hex chars, so output length is 2 * number of bytes
    int64_t len = nbytes * 2;
    check_result_len(len);
    B_str res;
    NEW_UNFILLED_STR(res, len, len);

    // Hex digit lookup table
    const char hex_digits[] = "0123456789abcdef";

    // Convert each byte to two hex digits
    for (int64_t i = 0; i < nbytes; i++) {
        unsigned char byte = data[i];
        res->str[i*2] = hex_digits[byte >> 4];     // High nibble
        res->str[i*2 + 1] = hex_digits[byte & 0xf]; // Low nibble
    }
    return res;
}

B_str B_bytearrayD_hex(B_bytearray s) {
    return hex_from_bytes(s->str, s->nbytes);
}


int64_t B_bytearrayD_index(B_bytearray s, B_bytearray sub, int64_t start, int64_t end) {
    int64_t n = B_bytearrayD_find(s,sub,start,end);
    if (n<0) {
        RAISE_EXC(&B_str_substring_not_found_error);
    }
    return n;
}

bool B_bytearrayD_isalnum(B_bytearray s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c < '0' || c > 'z' || (c > '9' && c < 'A') || (c > 'Z' && c < 'a'))
            return false;
    }
    return true;
}

bool B_bytearrayD_isalpha(B_bytearray s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c < 'A' || c > 'z' || (c > 'Z' && c < 'a'))
            return false;
    }
    return true;
}

bool B_bytearrayD_isascii(B_bytearray s) {
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c > 0x7f)
            return false;
    }
    return true;
}

bool B_bytearrayD_isdigit(B_bytearray s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c<'0' || c > '9')
            return false;
    }
    return true;
}


bool B_bytearrayD_islower(B_bytearray s) {
    bool has_lower = false;
    for (int64_t i=0; i < s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c >= 'A' && c <= 'Z')
            return false;
        if (c >= 'a' && c <= 'z')
            has_lower = true;
    }
    return has_lower;
}

bool B_bytearrayD_isspace(B_bytearray s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c !=' ' && c != '\t' && c != '\n' && c != '\r' && c != '\x0b' && c != '\f')
            return false;
    }
    return true;
}

bool B_bytearrayD_istitle(B_bytearray s) {
    if (s->nbytes==0)
        return false;
    bool incasedrun = false;
    bool cased = false;
    for (int64_t i=0; i < s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c >='A' && c <= 'Z') {
            if (incasedrun)
                return false;
            incasedrun = true;
            cased = true;
        } else if (c >='a' && c <= 'z') {
            if (!incasedrun)
                return false;
        } else
            incasedrun = false;
    }
    return cased;
}

bool B_bytearrayD_isupper(B_bytearray s) {
    bool has_upper = false;
    for (int64_t i=0; i < s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c >= 'a' && c <= 'z')
            return false;
        if (c >= 'A' && c <= 'Z')
            has_upper = true;
    }
    return has_upper;
}

B_bytearray B_bytearrayD_join(B_bytearray s, B_Iterable wit, $WORD iter) {
    int64_t totbytes = 0;
    B_list_base lst = join_parts(wit, iter);
    B_bytearray nxt;
    int64_t len = lst->length;
    // The total is checked as it grows by a part and a separator, so it
    // can't overflow before it is checked
    for (int64_t i = 0; i < len; i++) {
        nxt = (B_bytearray)lst->data[i];
        totbytes += nxt->nbytes + (i > 0 ? s->nbytes : 0);
        check_result_len(totbytes);
    }
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, totbytes);
    if (len > 0) {
        nxt = (B_bytearray)lst->data[0];
        unsigned char *p = res->str;
        memcpy(p, nxt->str, nxt->nbytes);
        p += nxt->nbytes;
        for (int64_t i = 1; i < len; i++) {
            nxt = (B_bytearray)lst->data[i];
            memcpy(p, s->str, s->nbytes);
            p += s->nbytes;
            memcpy(p, nxt->str, nxt->nbytes);
            p += nxt->nbytes;
        }
    }
    return res;
}

B_bytearray B_bytearrayD_ljust(B_bytearray s, int64_t width, B_bytearray fill) {
    if (!fill)
        fill = space_bytearray;
    if (fill->nbytes != 1) {
        RAISE_EXC(&B_str_invalid_bytearray_ljust_fill_error);
    }
    if (width <= s->nbytes) {
        return B_bytearrayD_copy(s);
    }
    check_result_len(width);
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, width);
    memcpy(res->str, s->str, s->nbytes);
    unsigned char c = fill->str[0];
    for (int64_t i = s->nbytes; i < width; i++) {
        res->str[i] = c;
    }
    return res;
}

B_bytearray B_bytearrayD_lower(B_bytearray s) {
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,s->nbytes);
    for (int64_t i=0; i< s->nbytes; i++)
        res->str[i] = ascii_tolower(s->str[i]);
    return res;
}

B_bytearray B_bytearrayD_lstrip(B_bytearray s, B_bytearray cs) {
    if (!cs)
        cs = whitespace_bytearray;
    int64_t nstrip = 0;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        int found = 0;
        for (int64_t j=0; j<cs->nbytes; j++)
            if (c == cs->str[j]) {
                found = 1;
                break;
            }
        if (!found)
            break;
        nstrip++;
    }
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,s->nbytes-nstrip);
    memcpy(res->str,s->str+nstrip,res->nbytes);
    return res;
}


B_tuple B_bytearrayD_partition(B_bytearray s, B_bytearray sep) {
    int64_t n = B_bytearrayD_find(s,sep,0,INT64_MAX);
    if (n<0) {
        return $NEWTUPLE(3,B_bytearrayD_copy(s),toB_bytearray(""),toB_bytearray(""));
    } else {
        int64_t nb = bmh(s->str, sep->str, s->nbytes, sep->nbytes);
        B_bytearray ls;
        NEW_UNFILLED_BYTEARRAY(ls,nb);
        memcpy(ls->str,s->str,nb);
        B_bytearray rs;
        int64_t nbr = s->nbytes - sep->nbytes - nb;
        NEW_UNFILLED_BYTEARRAY(rs,nbr);
        memcpy(rs->str,s->str+nb+sep->nbytes,nbr);
        return $NEWTUPLE(3,ls,B_bytearrayD_copy(sep),rs);
    }
}


B_bytearray B_bytearrayD_replace(B_bytearray s, B_bytearray old, B_bytearray new, B_int count) {
    // A negative count, like no count, replaces every occurrence
    if (count == NULL || fromB_int(count) < 0)
        count = toB_int(INT64_MAX);
    int64_t c = B_bytearrayD_count(s, old, 0, INT64_MAX);
    int64_t c0 = fromB_int(count) < c ? fromB_int(count) : c;
    if (c0 == 0) {
        return B_bytearrayD_copy(s);
    }
    // The result can be far longer than the input. The count times the
    // growth of each replacement could overflow, so the count is checked
    // against how many replacements fit instead.
    int64_t growth = new->nbytes - old->nbytes;
    if (growth > 0 && c0 > (MAX_STR_LEN - s->nbytes) / growth)
        RAISE_EXC(&B_str_too_long_error);
    int64_t nbytes = s->nbytes + c0 * growth;
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, nbytes);
    unsigned char *p = s->str;
    unsigned char *q = res->str;
    unsigned char *pold = old->str;
    unsigned char *pnew = new->str;
    int64_t plen = s->nbytes;
    int64_t n;
    for (int64_t i = 0; i < c0; i++) {
        n = i > 0 && old->nbytes == 0 ? 1 : bmh(p, pold, plen, old->nbytes);
        if (n > 0) {
            memcpy(q, p, n);
            p += n; q += n;
        }
        memcpy(q, pnew, new->nbytes);
        p += old->nbytes;
        q += new->nbytes;
        plen -= n + old->nbytes;
    }
    if (plen > 0)
        memcpy(q, p, plen);
    return res;
}


int64_t B_bytearrayD_rfind(B_bytearray s, B_bytearray sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return -1;
    unsigned char *p = &s->str[st];
    unsigned char *q = &s->str[en];
    int64_t n = rbmh(p, sub->str, q-p, sub->nbytes);
    if (n<0) return -1;
    return n+p-s->str;
}


int64_t B_bytearrayD_rindex(B_bytearray s, B_bytearray sub, int64_t start, int64_t end) {
    int64_t n = B_bytearrayD_rfind(s,sub,start,end);
    if (n<0) {
        RAISE_EXC(&B_str_bytearray_rsubstring_not_found_error);
    };
    return n;
}

B_bytearray B_bytearrayD_rjust(B_bytearray s, int64_t width, B_bytearray fill) {
    if (!fill)
        fill = space_bytearray;
    if (fill->nbytes != 1) {
        RAISE_EXC(&B_str_invalid_rjust_fill_error);
    }
    if (width <= s->nbytes) {
        return B_bytearrayD_copy(s);
    }
    check_result_len(width);
    int64_t pad = width - s->nbytes;
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, width);
    unsigned char c = fill->str[0];
    for (int64_t i = 0; i < pad; i++) {
        res->str[i] = c;
    }
    memcpy(&res->str[pad], s->str, s->nbytes);
    return res;
}

B_tuple B_bytearrayD_rpartition(B_bytearray s, B_bytearray sep) {
    int64_t n = B_bytearrayD_rfind(s,sep,0,INT64_MAX);
    if (n<0) {
        return $NEWTUPLE(3,toB_bytearray(""),toB_bytearray(""),B_bytearrayD_copy(s));
    } else {
        int64_t nb = rbmh(s->str, sep->str, s->nbytes, sep->nbytes);
        B_bytearray ls;
        NEW_UNFILLED_BYTEARRAY(ls,nb);
        memcpy(ls->str,s->str,nb);
        int64_t nbr = s->nbytes - sep->nbytes - nb;
        B_bytearray rs;
        NEW_UNFILLED_BYTEARRAY(rs,nbr);
        memcpy(rs->str,s->str+nb+sep->nbytes,nbr);
        return  $NEWTUPLE(3,ls,B_bytearrayD_copy(sep),rs);
    }
}

B_bytearray B_bytearrayD_rstrip(B_bytearray s, B_bytearray cs) {
    if (!cs)
        cs = whitespace_bytearray;
    int64_t nstrip = 0;
    for (int64_t i=s->nbytes-1; i>=0; i--) {
        unsigned char c = s->str[i];
        int found = 0;
        for (int64_t j=0; j<cs->nbytes; j++)
            if (c == cs->str[j]) {
                found = 1;
                break;
            }
        if (!found)
            break;
        nstrip++;
    }
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,s->nbytes-nstrip);
    memcpy(res->str,s->str,res->nbytes);
    return res;
}

B_list B_bytearrayD_split(B_bytearray s, B_bytearray sep, B_int maxsplit) {
    B_list res = $NEW(B_list,NULL,NULL);
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    if (maxsplit == NULL || fromB_int(maxsplit) < 0) maxsplit = toB_int(INT64_MAX);
    if (sep == NULL) {
        unsigned char *p = s->str;
        if (s->nbytes==0) {
            return res;
        }
        int inword = 0;
        unsigned char *q;
        while (p < s->str + s->nbytes) {
            if  (*p !=' ' && *p != '\t' && *p != '\n' && *p != '\r' && *p != '\x0b' && *p != '\f') {
                if (!inword) {
                    inword = 1;
                    q = p;
                    if (res->length == fromB_int(maxsplit))
                        break; // we have now removed leading whitespace in remainder
                }
            } else {
                if (inword) {
                    inword = 0;
                    B_bytearray word;
                    NEW_UNFILLED_BYTEARRAY(word,p-q);
                    memcpy(word->str,q,p-q);
                    wit->$class->append(wit,res,word);
                }
            }
            p++;
        }
        // The loop ends inside a word either at the end of s or when maxsplit
        // pieces are done. Either way the last piece runs from q to the end.
        if (inword) {
            B_bytearray word;
            p = s->str+s->nbytes;
            NEW_UNFILLED_BYTEARRAY(word,p-q);
            memcpy(word->str,q,p-q);
            wit->$class->append(wit,res,word);
        }
        return res;
    } else { // separator given
        if (sep->nbytes==0) {
            RAISE_EXC(&B_str_empty_bytearray_separator_error);
        }
        // Search for each separator from the end of the previous one and
        // copy every piece once
        int64_t maxs = fromB_int(maxsplit);
        unsigned char *p = s->str;
        int64_t rest = s->nbytes;
        int64_t n;
        while (res->length < maxs && (n = bmh(p,sep->str,rest,sep->nbytes)) >= 0) {
            B_bytearray word;
            NEW_UNFILLED_BYTEARRAY(word,n);
            memcpy(word->str,p,n);
            wit->$class->append(wit,res,word);
            p += n + sep->nbytes;
            rest -= n + sep->nbytes;
        }
        B_bytearray word;
        NEW_UNFILLED_BYTEARRAY(word,rest);
        memcpy(word->str,p,rest);
        wit->$class->append(wit,res,word);
        return res;
    }
}

B_list B_bytearrayD_splitlines(B_bytearray s, B_bool keepends) {
    if (!keepends)
        keepends = B_False;
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    B_list res = $NEW(B_list,NULL,NULL);
    if (s->nbytes==0) {
        return res;
    }
    int winend;
    unsigned char *p = s->str;
    unsigned char *q = p;
    while (p < s->str + s->nbytes) {
        if (*p != '\n' && *p != '\r') {
            p++;
        } else {
            B_bytearray line;
            winend = *p=='\r' && p+1 < s->str + s->nbytes && *(p+1)=='\n';
            int64_t size = p-q + (keepends->val ? 1 + winend : 0);
            NEW_UNFILLED_BYTEARRAY(line,size);
            memcpy(line->str,q,size);
            p+= 1 + winend;
            q = p;
            wit->$class->append(wit,res,line);
        }
    }
    if (q < p) {
        B_bytearray line;
        NEW_UNFILLED_BYTEARRAY(line,p-q);
        memcpy(line->str,q,p-q);
        wit->$class->append(wit,res,line);
    }
    return res;
}

bool B_bytearrayD_startswith(B_bytearray s, B_bytearray sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return false;
    unsigned char *p = s->str + st;
    if (sub->nbytes > 0 && p+sub->nbytes > s->str+s->nbytes) return false;
    unsigned char *q = sub->str;
    for (int64_t i=0; i<sub->nbytes; i++) {
        if (p >= s->str + en || *p++ != *q++) {
            return false;
        }
    }
    return true;
}


B_bytearray B_bytearrayD_strip(B_bytearray s, B_bytearray cs) {
    return B_bytearrayD_lstrip(B_bytearrayD_rstrip(s,cs),cs);
}

B_bytearray B_bytearrayD_upper(B_bytearray s) {
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,s->nbytes);
    for (int64_t i=0; i< s->nbytes; i++)
        res->str[i] = ascii_toupper(s->str[i]);
    return res;
}

B_bytearray B_bytearrayD_zfill(B_bytearray s, int64_t width) {
    if (width < s->nbytes)
        return B_bytearrayD_copy(s);
    check_result_len(width);
    int64_t fill = width - s->nbytes;
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, width);
    unsigned char *p = s->str;
    unsigned char *q = res->str;
    int64_t hassign = s->nbytes > 0 && (*p == '+' || *p == '-');
    if (hassign) {
        *q = *p;
        q++;
    }
    for (int64_t i = 0; i < fill; i++)
        *q++ = '0';
    memcpy(res->str + hassign + fill, s->str + hassign, s->nbytes - hassign);
    return res;
}


// Ord


bool B_OrdD_bytearrayD___eq__ (B_OrdD_bytearray wit, B_bytearray a, B_bytearray b) {
    if (a == b)
        return true;
    return a->nbytes == b->nbytes && memcmp(a->str,b->str,a->nbytes)==0;
}

bool B_OrdD_bytearrayD___ne__ (B_OrdD_bytearray wit, B_bytearray a, B_bytearray b) {
    return !B_OrdD_bytearrayD___eq__(wit,a,b);
}

bool B_OrdD_bytearrayD___lt__ (B_OrdD_bytearray wit, B_bytearray a, B_bytearray b) {
    int64_t minl = a->nbytes<b->nbytes ? a->nbytes : b->nbytes;
    int c = memcmp(a->str,b->str,minl);
    return c<0 || (c==0 && a->nbytes<b->nbytes);
}

bool B_OrdD_bytearrayD___le__ (B_OrdD_bytearray wit, B_bytearray a, B_bytearray b){
    return !B_OrdD_bytearrayD___lt__(wit,b,a);
}

bool B_OrdD_bytearrayD___gt__ (B_OrdD_bytearray wit, B_bytearray a, B_bytearray b){
    return B_OrdD_bytearrayD___lt__(wit,b,a);
}

bool B_OrdD_bytearrayD___ge__ (B_OrdD_bytearray wit, B_bytearray a, B_bytearray b){
    return !B_OrdD_bytearrayD___lt__(wit,a,b);
}

// Container

// Iterable
static bool B_IteratorD_bytearrayD_next(B_IteratorD_bytearray self, $WORD *out) {
    if (self->nxt >= self->src->nbytes)
        return false;
    *out = (B_value)toB_int(self->src->str[self->nxt++]);
    return true;
}

B_NoneType B_IteratorD_bytearrayD_init(B_IteratorD_bytearray self, B_bytearray b) {
    self->src = b;
    self->nxt = 0;
    return B_None;
}

B_Iterator $bytearrayD_U_iter_init(B_IteratorD_bytearray iter, B_bytearray src) {
    iter->$class = &B_IteratorD_bytearrayG_methods;
    B_IteratorD_bytearrayD_init(iter, src);
    return (B_Iterator)iter;
}

bool B_IteratorD_bytearrayD_bool(B_IteratorD_bytearray self) {
    return true;
}

B_str B_IteratorD_bytearrayD_str(B_IteratorD_bytearray self) {
    return $FORMAT("<bytearray iterator object at %p>", self);
}

void B_IteratorD_bytearrayD_serialize(B_IteratorD_bytearray self,$Serial$state state) {
    $step_serialize(self->src,state);
    $step_serialize(toB_int(self->nxt),state);
}

B_IteratorD_bytearray B_IteratorD_bytearray$_deserialize(B_IteratorD_bytearray res, $Serial$state state) {
    if(!res)
        res = $DNEW(B_IteratorD_bytearray,state);
    res->src = (B_bytearray)$step_deserialize(state);
    res->nxt = fromB_int((B_int)$step_deserialize(state));
    return res;
}

struct B_IteratorD_bytearrayG_class B_IteratorD_bytearrayG_methods = {
    "",
    UNASSIGNED,
    ($SuperG_class)&B_IteratorG_methods,
    B_IteratorD_bytearrayD_init,
    B_IteratorD_bytearrayD_serialize,
    B_IteratorD_bytearray$_deserialize,
    B_IteratorD_bytearrayD_bool,
    B_IteratorD_bytearrayD_str,
    B_IteratorD_bytearrayD_str,
    B_IteratorD_bytearrayD_next
};

bool B_ContainerD_bytearrayD___contains__(B_ContainerD_bytearray wit, B_bytearray self, B_int n) {
    if (n->val < 0 || n->val > 255)
        return false;
    bool res = false;
    for (int64_t i=0; i < self->nbytes; i++) {
        if (self->str[i] == (unsigned char)n->val) {
            res = true;
            break;
        }
    }
    return res;
}

bool B_ContainerD_bytearrayD___containsnot__(B_ContainerD_bytearray wit, B_bytearray self, B_int n) {
    return !B_ContainerD_bytearrayD___contains__(wit,self,n);
}

// Sequence

int64_t $bytearrayD_U__getitem__(B_bytearray self, int64_t ix) {
    int64_t ix0 = ix < 0 ? self->nbytes + ix : ix;
    if (ix0<0 || ix0 >= self->nbytes)
        RAISE(B_IndexError, ix0, actStrFromCString("getitem: index outside bytearray"));
    return (int64_t)self->str[ix0];
}

B_NoneType $bytearrayD_U__setitem__(B_bytearray self, int64_t ix, int64_t val) {
    int64_t ix0 = ix < 0 ? self->nbytes + ix : ix;
    if (ix0<0 || ix0 >= self->nbytes)
        RAISE(B_IndexError, ix0, actStrFromCString("setitem: index outside bytearray"));
    if (val<0 || val>255)
        RAISE_EXC(&B_str_invalid_bytearray_value_error);
    self->str[ix0] = (unsigned char)val;
    return B_None;
}

B_NoneType $bytearrayD_U__delitem__(B_bytearray self, int64_t ix) {
    int64_t ix0 = ix < 0 ? self->nbytes + ix : ix;
    int64_t len = self->nbytes;
    if (ix0 < 0 || ix0 >= len)
        RAISE(B_IndexError, ix0, actStrFromCString("delitem: index outside bytearray"));
    memmove(self->str + ix0,self->str + (ix0 + 1),len-(ix0+1));
    self->nbytes--;
    return B_None;
}

B_int B_SequenceD_bytearrayD___getitem__ (B_SequenceD_bytearray wit, B_bytearray self, B_int n) {
    return toB_int($bytearrayD_U__getitem__(self, n->val));
}

B_NoneType B_SequenceD_bytearrayD___setitem__ (B_SequenceD_bytearray wit, B_bytearray self, B_int n, B_int v) {
    return $bytearrayD_U__setitem__(self, n->val, v->val);
}

B_NoneType B_SequenceD_bytearrayD___delitem__ (B_SequenceD_bytearray wit, B_bytearray self, B_int n) {
    return $bytearrayD_U__delitem__(self, n->val);
}

B_NoneType B_SequenceD_bytearrayD_insert(B_SequenceD_bytearray wit, B_bytearray self, int64_t n, B_int elem) {
    if (elem->val < 0 || elem->val > 255)
        RAISE_EXC(&B_str_invalid_bytearray_insert_error);
    int64_t ix = n;
    int64_t len = self->nbytes;
    expand_bytearray(self,1);
    int64_t ix0 = ix < 0 ? (len+ix < 0 ? 0 : len+ix) : (ix < len ? ix : len);
    memmove(self->str + (ix0 + 1),
            self->str + ix0 ,
            len - ix0);
    self->str[ix0] = (unsigned char)(elem->val & 0xff);
    self->nbytes++;
    return B_None;
}

B_NoneType B_SequenceD_bytearrayD_append(B_SequenceD_bytearray wit, B_bytearray self, B_int elem) {
    if (elem->val < 0 || elem->val > 255)
        RAISE_EXC(&B_str_invalid_bytearray_append_error);
    expand_bytearray(self,1);
    self->str[self->nbytes++] = (unsigned char)(elem->val & 0xff);
    return B_None;
}

B_NoneType B_SequenceD_bytearrayD_reverse(B_SequenceD_bytearray wit, B_bytearray self) {
    int64_t len = self->nbytes;
    for (int64_t i = 0; i < len/2; i++) {
        unsigned char tmp = self->str[i];
        self->str[i] = self->str[len-1-i];
        self->str[len-1-i] = tmp;
    }
    return B_None;
}

B_Iterator B_SequenceD_bytearrayD___reversed__(B_SequenceD_bytearray wit, B_bytearray self) {
    B_bytearray copy = B_bytearrayD_copy(self);
    B_SequenceD_bytearrayD_reverse(wit,copy);
    return (B_Iterator)$NEW(B_IteratorD_bytearray,copy);
}

B_bytearray B_SequenceD_bytearrayD___getslice__ (B_SequenceD_bytearray wit, B_bytearray self, B_slice slc) {
    int64_t len = self->nbytes;
    int64_t start, stop, step, slen;
    normalize_slice(slc, len, &slen, &start, &stop, &step);
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res,slen);
    int64_t t = start;
    for (int64_t i=0; i<slen; i++) {
        B_int w = B_SequenceD_bytearrayD___getitem__(wit, self, toB_int(t));
        B_SequenceD_bytearrayD___setitem__(wit, res , toB_int(i), w);
        t += step;
    }
    return res;
}

B_NoneType B_SequenceD_bytearrayD___setslice__ (B_SequenceD_bytearray wit,  B_bytearray self, B_Iterable wit2, B_slice slc, $WORD iter) {
    B_Iterator it = wit2->$class->__iter__(wit2,iter);
    int64_t len = self->nbytes;
    B_bytearray other;
    NEW_UNFILLED_BYTEARRAY(other,0);
    $WORD next;
    while (it->$class->__next__(it, &next)) {
        B_SequenceD_bytearrayD_append(wit, other, next);
    }
    int64_t olen = other->nbytes;
    int64_t start, stop, step, slen;
    normalize_slice(slc, len, &slen, &start, &stop, &step);
    if (step != 1 && olen != slen) {
        RAISE_EXC(&B_str_invalid_bytearray_slice_error);
    }
    int64_t copy = olen <= slen ? olen : slen;
    int64_t t = start;
    for (int64_t i= 0; i<copy; i++) {
        self->str[t] = other->str[i];
        t += step;
    }
    if (olen == slen)
        return B_None;
    // now we know that step=1
    if (olen < slen) {
        memmove(self->str + start + copy,
                self->str + start + slen,
                len-(start+slen));
        self->nbytes-=slen-olen;
        return B_None;
    } else {
        expand_bytearray(self,olen-slen);
        int64_t rest = len - (start+copy);
        int64_t incr = olen - slen;
        memmove(self->str + start + copy + incr,
                self->str + start + copy,
                rest);
        for (int64_t i = copy; i < olen; i++)
            self->str[start+i] = other->str[i];
        self->nbytes += incr;
    }
    return B_None;
}

B_NoneType B_SequenceD_bytearrayD___delslice__ (B_SequenceD_bytearray wit,  B_bytearray self, B_slice slc) {
    int64_t len = self->nbytes;
    int64_t start, stop, step, slen;
    normalize_slice(slc, len, &slen, &start, &stop, &step);
    if (slen==0) return B_None;
    if (step < 0) {
        // The loop below needs a positive step: delete the same bytes,
        // taking them in increasing order
        start += (slen-1)*step;
        step = -step;
    }
    unsigned char *p = self->str + start;
    for (int64_t i=0; i<slen-1; i++) {
        memmove(p,p+i+1,step-1);
        p+=step-1;
    }
    memmove(p,p+slen,len-1-(start+step*(slen-1)));
    self->nbytes-=slen;
    return B_None;
}

// Sliceable / Indexed sibling wrappers generated by the Sequence hierarchy

B_int B_SliceableD_SequenceD_bytearrayD___getitem__(B_SliceableD_SequenceD_bytearray wit,
                                                     B_bytearray self, B_int n) {
    return B_SequenceD_bytearrayD___getitem__(NULL, self, n);
}

B_bytearray B_SliceableD_SequenceD_bytearrayD___getslice__(B_SliceableD_SequenceD_bytearray wit,
                                                            B_bytearray self, B_slice slc) {
    return B_SequenceD_bytearrayD___getslice__(NULL, self, slc);
}

B_NoneType B_SliceableD_SequenceD_bytearrayD___setslice__(B_SliceableD_SequenceD_bytearray wit,
                                                           B_bytearray self, B_Iterable iterwit,
                                                           B_slice slc, $WORD iter) {
    return B_SequenceD_bytearrayD___setslice__(NULL, self, iterwit, slc, iter);
}

B_NoneType B_SliceableD_SequenceD_bytearrayD___delslice__(B_SliceableD_SequenceD_bytearray wit,
                                                           B_bytearray self, B_slice slc) {
    return B_SequenceD_bytearrayD___delslice__(NULL, self, slc);
}

B_int B_IndexedD_SliceableD_SequenceD_bytearrayD___getitem__(B_IndexedD_SliceableD_SequenceD_bytearray wit,
                                                             B_bytearray self, B_int n) {
    return B_SequenceD_bytearrayD___getitem__(NULL, self, n);
}

B_NoneType B_IndexedD_SliceableD_SequenceD_bytearrayD___setitem__(B_IndexedD_SliceableD_SequenceD_bytearray wit,
                                                                  B_bytearray self, B_int n, B_int val) {
    return B_SequenceD_bytearrayD___setitem__(NULL, self, n, val);
}

B_NoneType B_IndexedD_SliceableD_SequenceD_bytearrayD___delitem__(B_IndexedD_SliceableD_SequenceD_bytearray wit,
                                                                  B_bytearray self, B_int n) {
    return B_SequenceD_bytearrayD___delitem__(NULL, self, n);
}

// Collection


B_Iterator B_CollectionD_SequenceD_bytearrayD___iter__ (B_CollectionD_SequenceD_bytearray wit, B_bytearray str) {
    return (B_Iterator)$NEW(B_IteratorD_bytearray,str);
}

B_bytearray B_CollectionD_SequenceD_bytearrayD___fromiter__ (B_CollectionD_SequenceD_bytearray wit, B_Iterable wit2, $WORD iter) {
    return B_bytearrayD_join(toB_bytearray(""),wit2,iter);
}

int64_t B_CollectionD_SequenceD_bytearrayD___len__ (B_CollectionD_SequenceD_bytearray wit, B_bytearray str) {
    return  (int64_t)str->nbytes;
}

// Times

B_bytearray B_TimesD_SequenceD_bytearrayD___add__ (B_TimesD_SequenceD_bytearray wit, B_bytearray a, B_bytearray b) {
    int64_t nbytes = (int64_t)a->nbytes + b->nbytes;
    check_result_len(nbytes);
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, nbytes);
    memcpy(res->str, a->str, a->nbytes);
    memcpy(res->str + a->nbytes, b->str, b->nbytes);
    return res;
}

B_bytearray B_TimesD_SequenceD_bytearrayD___zero__ (B_TimesD_SequenceD_bytearray wit) {
    return toB_bytearray("");
}

B_bytearray B_TimesD_SequenceD_bytearrayD___mul__ (B_TimesD_SequenceD_bytearray wit, B_bytearray a, B_int n) {
    int64_t nval = n->val;
    if (nval <= 0 || a->nbytes == 0)
        return toB_bytearray("");
    // The count times the length could overflow, so the count is checked
    // against how many copies fit instead
    if (nval > MAX_STR_LEN / a->nbytes)
        RAISE_EXC(&B_str_too_long_error);
    int64_t nbytes = a->nbytes * nval;
    B_bytearray res;
    NEW_UNFILLED_BYTEARRAY(res, nbytes);
    for (int64_t i = 0; i < nval; i++)
        memcpy(res->str + i * a->nbytes, a->str, a->nbytes);
    return res;
}

B_bytearray B_TimesD_SequenceD_bytearrayD___iadd__ (B_TimesD_SequenceD_bytearray wit, B_bytearray a, B_bytearray b) {
    // b can be a, so its length is read before a grows
    int64_t n = b->nbytes;
    if (n == 0)
        return a;
    expand_bytearray(a, n);
    memcpy(a->str + a->nbytes, b->str, n);
    a->nbytes += n;
    return a;
}

// Repeat the bytes of a n times in a, or remove them if n <= 0. Only the added
// copies are written.
B_bytearray B_TimesD_SequenceD_bytearrayD___imul__ (B_TimesD_SequenceD_bytearray wit, B_bytearray a, B_int n) {
    int64_t nval = n->val;
    int64_t len = a->nbytes;
    if (nval <= 0) {
        a->nbytes = 0;
        return a;
    }
    if (len == 0 || nval == 1)
        return a;
    // The count times the length could overflow, so the count is checked
    // against how many copies fit instead
    if (nval > MAX_STR_LEN / len)
        RAISE_EXC(&B_str_too_long_error);
    expand_bytearray(a, len * (nval - 1));
    for (int64_t i = 1; i < nval; i++)
        memcpy(a->str + i * len, a->str, len);
    a->nbytes = len * nval;
    return a;
}

// End of bytearray implementation ////////////////////////////////////////////////



// bytes implementation ///////////////////////////////////////////////////////////


// Conversion to and from C strings

B_bytes actBytesFromCStringCopy(const char *str) {
    return actBytesFromCStringLengthCopy(str, strlen(str));
}

B_bytes actBytesFromCStringLengthCopy(const char *str, int64_t len) {
    B_bytes res;
    NEW_UNFILLED_BYTES(res,len);
    memcpy(res->str,str,len);
    return res;
}

B_bytes actBytesFromCStringNoCopy(char *str) {
    return actBytesFromCStringLengthNoCopy(str, strlen(str));
}

B_bytes actBytesFromCStringLengthNoCopy(char *str, int64_t length) {
    B_bytes res = acton_malloc(sizeof(struct B_bytes));
    res->$class = &B_bytesG_methods;
    res->nbytes = length;
    res->str = (unsigned char *)str;
    return res;
}

// These existing names continue to copy until downstream callers migrate.
B_bytes actBytesFromCString(char *str) {
    return actBytesFromCStringCopy(str);
}

B_bytes actBytesFromCStringLength(char *str, int64_t len) {
    return actBytesFromCStringLengthCopy(str, len);
}

B_bytes to$bytes(char *str) {
    return actBytesFromCStringCopy(str);
}

B_bytes to$bytesD_len(char *str, int64_t len) {
    return actBytesFromCStringLengthCopy(str, len);
}

char *fromB_bytes(B_bytes b) {
    return (char *)b->str;
}

// Auxiliaries

static B_bytes B_bytesD_copy(B_bytes s) {
    B_bytes res;
    NEW_UNFILLED_BYTES(res,s->nbytes);
    res->nbytes = s->nbytes;
    memcpy(res->str,s->str,s->nbytes);
    return res;
}



// Bytes methods, implementations

// General methods //////////////////////////////////////////////////////////////

B_bytes B_bytesG_new(B_Iterable iter, $WORD wit) {
    return $NEW(B_bytes, iter, wit);
}

B_NoneType B_bytesD___init__(B_bytes self, B_Iterable wit, $WORD iter) {
    B_CollectionD_SequenceD_list wit2 = B_CollectionD_SequenceD_listG_witness;
    B_list lst = wit2->$class->__fromiter__(wit2,wit,iter);
    int len = lst->length;
    self->nbytes = len;
    self->str = alloc_data(len);
    for (int i=0; i< len; i++) {
        int64_t n = fromB_int((B_int)lst->data[i]);
        if (0<=n && n <= 255)
            self->str[i] = n;
        else
            RAISE_EXC(&B_str_invalid_bytes_value_error);
    }
    return B_None;
}

bool B_bytesD___bool__(B_bytes s) {
    return s->nbytes > 0;
};

B_str B_bytesD___str__(B_bytes s) {
    struct byte_counts bs = byte_count(s->str, s->nbytes);
    bool use_single_quotes = !(bs.dquotes==0 && bs.squotes>0);
    int64_t escaped_quotes = use_single_quotes ? bs.squotes : bs.dquotes;
    int64_t nbytes = (int64_t)s->nbytes + 3 + bs.escaped + 3 * (int64_t)bs.non_printable + escaped_quotes + 3 * (int64_t)bs.non_ascii;
    check_result_len(nbytes);
    B_str res;
    NEW_UNFILLED_STR(res, nbytes, nbytes);
    escape_str(res->str+2,s->str,res->nbytes-2,s->nbytes,255,use_single_quotes,!use_single_quotes,false,false);
    if (use_single_quotes) {
        res->str[1] = '\'';
        res->str[res->nbytes-1] = '\'';
    } else {
        res->str[1] = '"';
        res->str[res->nbytes-1] = '"';
    }
    res->str[0] = 'b';
    return res;
}

B_str B_bytesD___repr__(B_bytes s) {
    return  B_bytesD___str__(s);
}

void B_bytesD___serialize__(B_bytes str,$Serial$state state) {
    int64_t nWords = (str->nbytes + sizeof($WORD) - 1)/sizeof($WORD); // # $WORDS needed to store str->str
    $ROW row = $add_header(BYTES_ID,1+nWords,state);
    int64_t nbytes = str->nbytes;
    memcpy(row->blob,&nbytes,sizeof($WORD));
    memcpy(row->blob+1,str->str,nbytes);
}

B_bytes B_bytesD___deserialize__(B_bytes self, $Serial$state state) {
    $ROW this = state->row;
    state->row =this->next;
    state->row_no++;
    B_bytes res = acton_malloc(sizeof(struct B_bytes));
    int64_t nbytes;
    memcpy(&nbytes,this->blob,sizeof($WORD));
    res->$class = &B_bytesG_methods;
    res->nbytes = nbytes;
    res->str = alloc_data(nbytes);
    memcpy(res->str,this->blob+1,nbytes);
    return res;
}

B_bytes B_bytesD_capitalize(B_bytes s) {
    if (s->nbytes==0) {
        return s;
    }
    B_bytes res;
    NEW_UNFILLED_BYTES(res,s->nbytes);
    res->str[0] = ascii_toupper(s->str[0]);
    for (int64_t i = 1; i < s->nbytes; i++)
        res->str[i] = ascii_tolower(s->str[i]);
    return res;
}

B_bytes B_bytesD_center(B_bytes s, int64_t width, B_bytes fill) {
    if (!fill) fill = actBytesFromCStringCopy(" ");
    if (fill->nbytes != 1) {
        RAISE_EXC(&B_str_invalid_bytes_center_fill_error);
    }
    if (width <= s->nbytes) {
        return s;
    }
    check_result_len(width);
    int64_t pad = width - s->nbytes;
    int64_t padleft = pad / 2;
    int64_t padright = pad - padleft;
    int64_t sbytes = s->nbytes;
    B_bytes res;
    NEW_UNFILLED_BYTES(res, width);
    unsigned char c = fill->str[0];
    unsigned char *p = res->str;
    p += padleft + sbytes;
    for (int64_t i = 0; i < padright; i++) {
        p[i] = c;
    }
    memcpy(res->str, p, padleft);
    p -= sbytes;
    memcpy(p, s->str, sbytes);
    return res;
}

int64_t B_bytesD_count(B_bytes s, B_bytes sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return 0;
    int64_t stval = st;
    unsigned char *p = &s->str[stval];
    unsigned char *q = &p[en-stval];
    int64_t res = 0;
    int64_t n = bmh(p, sub->str, q-p, sub->nbytes);
    while (n>=0) {
        res++;
        p += n + (sub->nbytes>0 ? sub->nbytes : 1);
        n = bmh(p,sub->str,q-p,sub->nbytes);
    }
    return res;
}

B_str B_bytesD_decode(B_bytes s) {
    return actStrFromCStringLengthCopy((const char *)s->str, s->nbytes);
}

bool B_bytesD_endswith(B_bytes s, B_bytes sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return false;
    int64_t stval = st;
    int64_t enval = en;
    if (enval-stval < sub->nbytes) return false;
    return memcmp(&s->str[enval-sub->nbytes],sub->str,sub->nbytes)==0;
}

B_bytes B_bytesD_expandtabs(B_bytes s, B_int tabsz){
    if (s->nbytes == 0) {
        return null_bytes;
    }
    int64_t tabsize = tabsz ? fromB_int(tabsz) : 8;
    tabsize = tabsize <= 0 ? 1 : tabsize;
    int64_t len = expandtabs_bytes(s->str, s->nbytes, tabsize, NULL);
    B_bytes res;
    NEW_UNFILLED_BYTES(res,len);
    expandtabs_bytes(s->str, s->nbytes, tabsize, res->str);
    return res;
}

int64_t B_bytesD_find(B_bytes s, B_bytes sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return -1;
    unsigned char *p = &s->str[st];
    unsigned char *q = &s->str[en];
    int64_t n = bmh(p, sub->str, q-p, sub->nbytes);
    if (n<0) return -1;
    return n+p-s->str;
}

B_bytes B_bytesD_from_hex(B_str s) {
    if (s->nbytes == 0)
        return null_bytes;
    // Each byte is represented by 2 hex chars
    int64_t strlen = s->nbytes;  // Changed from len to nbytes
    if (strlen % 2 != 0) {
        RAISE_EXC(&B_str_odd_hex_length_error);
    }

    int64_t bytelen = strlen / 2;
    char *result = (char *)alloc_data(bytelen);

    for (int64_t i = 0; i < strlen; i += 2) {
        char high = s->str[i];
        char low = s->str[i + 1];

        // Convert hex chars to values 0-15
        int high_val, low_val;

        // Handle high nibble
        if (high >= '0' && high <= '9')
            high_val = high - '0';
        else if (high >= 'a' && high <= 'f')
            high_val = high - 'a' + 10;
        else if (high >= 'A' && high <= 'F')
            high_val = high - 'A' + 10;
        else {
            RAISE_EXC(&B_str_invalid_hex_error);
        }

        // Handle low nibble
        if (low >= '0' && low <= '9')
            low_val = low - '0';
        else if (low >= 'a' && low <= 'f')
            low_val = low - 'a' + 10;
        else if (low >= 'A' && low <= 'F')
            low_val = low - 'A' + 10;
        else {
            RAISE_EXC(&B_str_invalid_hex_error);
        }

        // Combine into byte
        result[i/2] = (high_val << 4) | low_val;
    }

    return actBytesFromCStringLengthNoCopy(result, bytelen);
}

B_str B_bytesD_hex(B_bytes s) {
    return hex_from_bytes(s->str, s->nbytes);
}

int64_t B_bytesD_index(B_bytes s, B_bytes sub, int64_t start, int64_t end) {
    int64_t n = B_bytesD_find(s,sub,start,end);
    if (n<0) {
        RAISE_EXC(&B_str_substring_not_found_error);
    }
    return n;
}

bool B_bytesD_isalnum(B_bytes s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c < '0' || c > 'z' || (c > '9' && c < 'A') || (c > 'Z' && c < 'a'))
            return false;
    }
    return true;
}

bool B_bytesD_isalpha(B_bytes s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c < 'A' || c > 'z' || (c > 'Z' && c < 'a'))
            return false;
    }
    return true;
}

bool B_bytesD_isascii(B_bytes s) {
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c > 0x7f)
            return false;
    }
    return true;
}

bool B_bytesD_isdigit(B_bytes s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c<'0' || c > '9')
            return false;
    }
    return true;
}

bool B_bytesD_islower(B_bytes s) {
    bool has_lower = false;
    for (int64_t i=0; i < s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c >= 'A' && c <= 'Z')
            return false;
        if (c >= 'a' && c <= 'z')
            has_lower = true;
    }
    return has_lower;
}

bool B_bytesD_isspace(B_bytes s) {
    if (s->nbytes==0)
        return false;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c !=' ' && c != '\t' && c != '\n' && c != '\r' && c != '\x0b' && c != '\f')
            return false;
    }
    return true;
}

bool B_bytesD_istitle(B_bytes s) {
    if (s->nbytes==0)
        return false;
    bool incasedrun = false;
    bool cased = false;
    for (int64_t i=0; i < s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c >='A' && c <= 'Z') {
            if (incasedrun)
                return false;
            incasedrun = true;
            cased = true;
        } else if (c >='a' && c <= 'z') {
            if (!incasedrun)
                return false;
        } else
            incasedrun = false;
    }
    return cased;
}

bool B_bytesD_isupper(B_bytes s) {
    bool has_upper = false;
    for (int64_t i=0; i < s->nbytes; i++) {
        unsigned char c = s->str[i];
        if (c >= 'a' && c <= 'z')
            return false;
        if (c >= 'A' && c <= 'Z')
            has_upper = true;
    }
    return has_upper;
}

B_bytes B_bytesD_join(B_bytes s, B_Iterable wit, $WORD iter) {
    int64_t totbytes = 0;
    B_list_base lst = join_parts(wit, iter);
    B_bytes nxt;
    int64_t len = lst->length;
    // The total is checked as it grows by a part and a separator, so it
    // can't overflow before it is checked
    for (int64_t i = 0; i < len; i++) {
        nxt = (B_bytes)lst->data[i];
        totbytes += nxt->nbytes + (i > 0 ? s->nbytes : 0);
        check_result_len(totbytes);
    }
    B_bytes res;
    NEW_UNFILLED_BYTES(res, totbytes);
    if (len > 0) {
        nxt = (B_bytes)lst->data[0];
        unsigned char *p = res->str;
        memcpy(p, nxt->str, nxt->nbytes);
        p += nxt->nbytes;
        for (int64_t i = 1; i < len; i++) {
            nxt = (B_bytes)lst->data[i];
            memcpy(p, s->str, s->nbytes);
            p += s->nbytes;
            memcpy(p, nxt->str, nxt->nbytes);
            p += nxt->nbytes;
        }
    }
    return res;
}

B_bytes B_bytesD_ljust(B_bytes s, int64_t width, B_bytes fill) {
    if (!fill)
        fill = space_bytes;
    if (fill->nbytes != 1) {
        RAISE_EXC(&B_str_invalid_bytes_ljust_fill_error);
    }
    if (width <= s->nbytes) {
        return B_bytesD_copy(s);
    }
    check_result_len(width);
    B_bytes res;
    NEW_UNFILLED_BYTES(res, width);
    memcpy(res->str, s->str, s->nbytes);
    unsigned char c = fill->str[0];
    for (int64_t i = s->nbytes; i < width; i++) {
        res->str[i] = c;
    }
    return res;
}

B_bytes B_bytesD_lower(B_bytes s) {
    B_bytes res;
    NEW_UNFILLED_BYTES(res,s->nbytes);
    for (int64_t i=0; i< s->nbytes; i++)
        res->str[i] = ascii_tolower(s->str[i]);
    return res;
}

B_bytes B_bytesD_lstrip(B_bytes s, B_bytes cs) {
    if (!cs)
        cs = whitespace_bytes;
    int64_t nstrip = 0;
    for (int64_t i=0; i<s->nbytes; i++) {
        unsigned char c = s->str[i];
        int found = 0;
        for (int64_t j=0; j<cs->nbytes; j++)
            if (c == cs->str[j]) {
                found = 1;
                break;
            }
        if (!found)
            break;
        nstrip++;
    }
    B_bytes res;
    NEW_UNFILLED_BYTES(res,s->nbytes-nstrip);
    memcpy(res->str,s->str+nstrip,res->nbytes);
    return res;
}


B_tuple B_bytesD_partition(B_bytes s, B_bytes sep) {
    int64_t n = B_bytesD_find(s,sep,0,INT64_MAX);
    if (n<0) {
        return $NEWTUPLE(3,s,actBytesFromCStringCopy(""),actBytesFromCStringCopy(""));
    } else {
        int64_t nb = bmh(s->str, sep->str, s->nbytes, sep->nbytes);
        B_bytes ls;
        NEW_UNFILLED_BYTES(ls,nb);
        memcpy(ls->str,s->str,nb);
        B_bytes rs;
        int64_t nbr = s->nbytes - sep->nbytes - nb;
        NEW_UNFILLED_BYTES(rs,nbr);
        memcpy(rs->str,s->str+nb+sep->nbytes,nbr);
        return $NEWTUPLE(3,ls,sep,rs);
    }
}


B_bytes B_bytesD_removeprefix(B_bytes s, B_bytes prefix) {
    int64_t bytes_to_remove;
    if (prefix->nbytes > s->nbytes || memcmp(s->str,prefix->str,prefix->nbytes))
        bytes_to_remove = 0;
    else
        bytes_to_remove = prefix->nbytes;
    B_bytes res;
    int64_t resbytes = s->nbytes - bytes_to_remove;
    NEW_UNFILLED_BYTES(res,resbytes);
    memcpy(res->str,s->str+bytes_to_remove,resbytes);
    return res;
}

B_bytes B_bytesD_removesuffix(B_bytes s, B_bytes suffix) {
    int64_t bytes_to_remove;
    if (suffix->nbytes > s->nbytes || memcmp(s->str+s->nbytes-suffix->nbytes,suffix->str,suffix->nbytes))
        bytes_to_remove = 0;
    else
        bytes_to_remove = suffix->nbytes;
    B_bytes res;
    int64_t resbytes = s->nbytes - bytes_to_remove;
    NEW_UNFILLED_BYTES(res,resbytes);
    memcpy(res->str,s->str,resbytes);
    return res;
}
B_bytes B_bytesD_replace(B_bytes s, B_bytes old, B_bytes new, B_int count) {
    // A negative count, like no count, replaces every occurrence
    if (count == NULL || fromB_int(count) < 0)
        count = toB_int(INT64_MAX);
    int64_t c = B_bytesD_count(s, old, 0, INT64_MAX);
    int64_t c0 = fromB_int(count) < c ? fromB_int(count) : c;
    if (c0 == 0) {
        return B_bytesD_copy(s);
    }
    // The result can be far longer than the input. The count times the
    // growth of each replacement could overflow, so the count is checked
    // against how many replacements fit instead.
    int64_t growth = new->nbytes - old->nbytes;
    if (growth > 0 && c0 > (MAX_STR_LEN - s->nbytes) / growth)
        RAISE_EXC(&B_str_too_long_error);
    int64_t nbytes = s->nbytes + c0 * growth;
    B_bytes res;
    NEW_UNFILLED_BYTES(res, nbytes);
    unsigned char *p = s->str;
    unsigned char *q = res->str;
    unsigned char *pold = old->str;
    unsigned char *pnew = new->str;
    int64_t plen = s->nbytes;
    int64_t n;
    for (int64_t i = 0; i < c0; i++) {
        n = i > 0 && old->nbytes == 0 ? 1 : bmh(p, pold, plen, old->nbytes);
        if (n > 0) {
            memcpy(q, p, n);
            p += n; q += n;
        }
        memcpy(q, pnew, new->nbytes);
        p += old->nbytes;
        q += new->nbytes;
        plen -= n + old->nbytes;
    }
    if (plen > 0)
        memcpy(q, p, plen);
    return res;
}


int64_t B_bytesD_rfind(B_bytes s, B_bytes sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return -1;
    unsigned char *p = &s->str[st];
    unsigned char *q = &s->str[en];
    int64_t n = rbmh(p, sub->str, q-p, sub->nbytes);
    if (n<0) return -1;
    return n+p-s->str;
}


int64_t B_bytesD_rindex(B_bytes s, B_bytes sub, int64_t start, int64_t end) {
    int64_t n = B_bytesD_rfind(s,sub,start,end);
    if (n<0) {
        RAISE_EXC(&B_str_bytes_rsubstring_not_found_error);
    };
    return n;
}

B_bytes B_bytesD_rjust(B_bytes s, int64_t width, B_bytes fill) {
    if (!fill)
        fill = space_bytes;
    if (fill->nbytes != 1) {
        RAISE_EXC(&B_str_invalid_rjust_fill_error);
    }
    if (width <= s->nbytes) {
        return B_bytesD_copy(s);
    }
    check_result_len(width);
    int64_t pad = width - s->nbytes;
    B_bytes res;
    NEW_UNFILLED_BYTES(res, width);
    unsigned char c = fill->str[0];
    for (int64_t i = 0; i < pad; i++) {
        res->str[i] = c;
    }
    memcpy(&res->str[pad], s->str, s->nbytes);
    return res;
}

B_tuple B_bytesD_rpartition(B_bytes s, B_bytes sep) {
    int64_t n = B_bytesD_rfind(s,sep,0,INT64_MAX);
    if (n<0) {
        return $NEWTUPLE(3,actBytesFromCStringCopy(""),actBytesFromCStringCopy(""),s);
    } else {
        int64_t nb = rbmh(s->str, sep->str, s->nbytes, sep->nbytes);
        B_bytes ls;
        NEW_UNFILLED_BYTES(ls,nb);
        memcpy(ls->str,s->str,nb);
        int64_t nbr = s->nbytes - sep->nbytes - nb;
        B_bytes rs;
        NEW_UNFILLED_BYTES(rs,nbr);
        memcpy(rs->str,s->str+nb+sep->nbytes,nbr);
        return  $NEWTUPLE(3,ls,sep,rs);
    }
}

B_bytes B_bytesD_rstrip(B_bytes s, B_bytes cs) {
    if (!cs)
        cs = whitespace_bytes;
    int64_t nstrip = 0;
    for (int64_t i=s->nbytes-1; i>=0; i--) {
        unsigned char c = s->str[i];
        int found = 0;
        for (int64_t j=0; j<cs->nbytes; j++)
            if (c == cs->str[j]) {
                found = 1;
                break;
            }
        if (!found)
            break;
        nstrip++;
    }
    B_bytes res;
    NEW_UNFILLED_BYTES(res,s->nbytes-nstrip);
    memcpy(res->str,s->str,res->nbytes);
    return res;
}

B_list B_bytesD_split(B_bytes s, B_bytes sep, B_int maxsplit) {
    B_list res = $NEW(B_list,NULL,NULL);
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    if (maxsplit == NULL || fromB_int(maxsplit) < 0) maxsplit = toB_int(INT64_MAX);
    if (sep == NULL) {
        unsigned char *p = s->str;
        if (s->nbytes==0) {
            return res;
        }
        int inword = 0;
        unsigned char *q;
        while (p < s->str + s->nbytes) {
            if  (*p !=' ' && *p != '\t' && *p != '\n' && *p != '\r' && *p != '\x0b' && *p != '\f') {
                if (!inword) {
                    inword = 1;
                    q = p;
                    if (res->length == fromB_int(maxsplit))
                        break; // we have now removed leading whitespace in remainder
                }
            } else {
                if (inword) {
                    inword = 0;
                    B_bytes word;
                    NEW_UNFILLED_BYTES(word,p-q);
                    memcpy(word->str,q,p-q);
                    wit->$class->append(wit,res,word);
                }
            }
            p++;
        }
        // The loop ends inside a word either at the end of s or when maxsplit
        // pieces are done. Either way the last piece runs from q to the end.
        if (inword) {
            B_bytes word;
            p = s->str+s->nbytes;
            NEW_UNFILLED_BYTES(word,p-q);
            memcpy(word->str,q,p-q);
            wit->$class->append(wit,res,word);
        }
        return res;
    } else { // separator given
        if (sep->nbytes==0) {
            RAISE_EXC(&B_str_empty_bytes_separator_error);
        }
        // Search for each separator from the end of the previous one and
        // copy every piece once
        int64_t maxs = fromB_int(maxsplit);
        unsigned char *p = s->str;
        int64_t rest = s->nbytes;
        int64_t n;
        while (res->length < maxs && (n = bmh(p,sep->str,rest,sep->nbytes)) >= 0) {
            B_bytes word;
            NEW_UNFILLED_BYTES(word,n);
            memcpy(word->str,p,n);
            wit->$class->append(wit,res,word);
            p += n + sep->nbytes;
            rest -= n + sep->nbytes;
        }
        B_bytes word;
        NEW_UNFILLED_BYTES(word,rest);
        memcpy(word->str,p,rest);
        wit->$class->append(wit,res,word);
        return res;
    }
}

B_list B_bytesD_splitlines(B_bytes s, B_bool keepends) {
    if (!keepends)
        keepends = B_False;
    B_list res = $NEW(B_list,NULL,NULL);
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    if (s->nbytes==0) {
        return res;
    }
    int winend;
    unsigned char *p = s->str;
    unsigned char *q = p;
    while (p < s->str + s->nbytes) {
        if (*p != '\n' && *p != '\r') {
            p++;
        } else {
            B_bytes line;
            winend = *p=='\r' && p+1 < s->str + s->nbytes && *(p+1)=='\n';
            int64_t size = p-q + (keepends->val ? 1 + winend : 0);
            NEW_UNFILLED_BYTES(line,size);
            memcpy(line->str,q,size);
            p+= 1 + winend;
            q = p;
            wit->$class->append(wit,res,line);
        }
    }
    if (q < p) {
        B_bytes line;
        NEW_UNFILLED_BYTES(line,p-q);
        memcpy(line->str,q,p-q);
        wit->$class->append(wit,res,line);
    }
    return res;
}

bool B_bytesD_startswith(B_bytes s, B_bytes sub, int64_t start, int64_t end) {
    int64_t st = start;
    int64_t en = end;
    if (fix_start_end(s->nbytes,&st,&en) < 0) return false;
    unsigned char *p = s->str + st;
    if (sub->nbytes > 0 && p+sub->nbytes > s->str+s->nbytes) return false;
    unsigned char *q = sub->str;
    for (int64_t i=0; i<sub->nbytes; i++) {
        if (p >= s->str + en || *p++ != *q++) {
            return false;
        }
    }
    return true;
}


B_bytes B_bytesD_strip(B_bytes s, B_bytes cs) {
    return B_bytesD_lstrip(B_bytesD_rstrip(s,cs),cs);
}

B_bytes B_bytesD_upper(B_bytes s) {
    B_bytes res;
    NEW_UNFILLED_BYTES(res,s->nbytes);
    for (int64_t i=0; i< s->nbytes; i++)
        res->str[i] = ascii_toupper(s->str[i]);

    return res;
}

B_bytes B_bytesD_zfill(B_bytes s, int64_t width) {
    if (width < s->nbytes)
        return B_bytesD_copy(s);
    check_result_len(width);
    int64_t fill = width - s->nbytes;
    B_bytes res;
    NEW_UNFILLED_BYTES(res, width);
    unsigned char *p = s->str;
    unsigned char *q = res->str;
    int64_t hassign = s->nbytes > 0 && (*p == '+' || *p == '-');
    if (hassign) {
        *q = *p;
        q++;
    }
    for (int64_t i = 0; i < fill; i++)
        *q++ = '0';
    memcpy(res->str + hassign + fill, s->str + hassign, s->nbytes - hassign);
    return res;
}

// protocol methods ///////////////////////////////////////////////////

// Ord


bool B_OrdD_bytesD___eq__ (B_OrdD_bytes wit, B_bytes a, B_bytes b) {
    if (a == b)
        return true;
    if (a->nbytes != b->nbytes)
        return false;
    for (int64_t i=0; i < a->nbytes; i++)
        if (a->str[i] != b->str[i])
            return false;
    return true;
}

bool B_OrdD_bytesD___ne__ (B_OrdD_bytes wit, B_bytes a, B_bytes b) {
    return !B_OrdD_bytesD___eq__(wit,a,b);
}

bool B_OrdD_bytesD___lt__ (B_OrdD_bytes wit, B_bytes a, B_bytes b) {
    int64_t minl = a->nbytes<b->nbytes ? a->nbytes : b->nbytes;
    int64_t i=0;
    while (i<minl && a->str[i]==b->str[i]) i++;
    if (i==a->nbytes)
        return i<b->nbytes;
    if (i==b->nbytes)
        return false;
    return a->str[i]<b->str[i];
}

bool B_OrdD_bytesD___le__ (B_OrdD_bytes wit, B_bytes a, B_bytes b){
    return !B_OrdD_bytesD___lt__(wit,b,a);
}

bool B_OrdD_bytesD___gt__ (B_OrdD_bytes wit, B_bytes a, B_bytes b){
    return B_OrdD_bytesD___lt__(wit,b,a);
}

bool B_OrdD_bytesD___ge__ (B_OrdD_bytes wit, B_bytes a, B_bytes b){
    return !B_OrdD_bytesD___lt__(wit,a,b);
}

// Container

// Iterable ///////////////////////////////////////////////////////////////////////////

B_IteratorD_bytes B_IteratorD_bytesG_new(B_bytes str) {
    return $NEW(B_IteratorD_bytes, str);
}

B_NoneType B_IteratorD_bytesD_init(B_IteratorD_bytes self, B_bytes str) {
    self->src = str;
    self->nxt = 0;
    return B_None;
}

B_Iterator $bytesD_U_iter_init(B_IteratorD_bytes iter, B_bytes src) {
    iter->$class = &B_IteratorD_bytesG_methods;
    B_IteratorD_bytesD_init(iter, src);
    return (B_Iterator)iter;
}

void B_IteratorD_bytesD_serialize(B_IteratorD_bytes self,$Serial$state state) {
    $step_serialize(self->src,state);
    $step_serialize(toB_int(self->nxt),state);
}


B_IteratorD_bytes B_IteratorD_bytes$_deserialize(B_IteratorD_bytes res, $Serial$state state) {
    if (!res)
        res = $DNEW(B_IteratorD_bytes,state);
    res->src = (B_bytes)$step_deserialize(state);
    res->nxt = fromB_int((B_int)$step_deserialize(state));
    return res;
}

bool B_IteratorD_bytesD_bool(B_IteratorD_bytes self) {
    return true;
}

B_str B_IteratorD_bytesD_str(B_IteratorD_bytes self) {
    return $FORMAT("<bytes iterator object at %p>", self);
}
static bool B_IteratorD_bytesD_next(B_IteratorD_bytes self, $WORD *out) {
    if (self->nxt >= self->src->nbytes)
        return false;
    *out = (B_value)toB_int(self->src->str[self->nxt++]);
    return true;
}

struct B_IteratorD_bytesG_class B_IteratorD_bytesG_methods = {"B_IteratorD_bytes",UNASSIGNED,($SuperG_class)&B_IteratorG_methods, B_IteratorD_bytesD_init,
                                                        B_IteratorD_bytesD_serialize, B_IteratorD_bytes$_deserialize,
                                                        B_IteratorD_bytesD_bool, B_IteratorD_bytesD_str,  B_IteratorD_bytesD_str,
                                                        B_IteratorD_bytesD_next};

B_Iterator B_ContainerD_bytesD___iter__ (B_ContainerD_bytes wit, B_bytes str) {
    return (B_Iterator)$NEW(B_IteratorD_bytes,str);
}

B_bytes B_ContainerD_bytesD___fromiter__ (B_ContainerD_bytes wit, B_Iterable wit2, $WORD iter) {
    return B_bytesD_join(actBytesFromCStringCopy(""),wit2,iter);
}

int64_t B_ContainerD_bytesD___len__ (B_ContainerD_bytes wit, B_bytes str) {
    return (int64_t)str->nbytes;
}

bool B_ContainerD_bytesD___contains__ (B_ContainerD_bytes wit, B_bytes str, B_int n) {
    if (n->val < 0 || n->val > 255)
        return false;
    bool res = false;
    for (int64_t i=0; i < str->nbytes; i++) {
        if (str->str[i] == (unsigned char)n->val) {
            res = true;
            break;
        }
    }
    return res;
}

bool B_ContainerD_bytesD___containsnot__ (B_ContainerD_bytes wit, B_bytes str, B_int n) {
    return !B_ContainerD_bytesD___contains__(wit, str, n);
}

// ISliceable

int64_t $bytesD_U__getitem__(B_bytes str, int64_t ix) {
    int64_t ix0 = ix < 0 ? str->nbytes + ix : ix;
    if (ix0<0 || ix0 >= str->nbytes)
        RAISE(B_IndexError, ix0, actStrFromCString("getitem: index outside bytesarray"));
    return (int64_t)str->str[ix0];
}

B_int B_ISliceableD_bytesD___getitem__ (B_ISliceableD_bytes wit, B_bytes str, B_int n) {
    return toB_int($bytesD_U__getitem__(str, n->val));
}

B_bytes B_ISliceableD_bytesD___getslice__ (B_ISliceableD_bytes wit, B_bytes str, B_slice slc) {
    int64_t start, stop, step, slen;
    normalize_slice(slc, str->nbytes, &slen, &start, &stop, &step);
    //slice notation has been eliminated and default values applied
    B_bytes res;
    NEW_UNFILLED_BYTES(res,slen);
    int64_t t = start;
    for (int64_t i=0; i<slen; i++) {
        res->str[i] = str->str[t];
        t += step;
    }
    return res;
}

// Times


B_bytes B_TimesD_bytesD___add__ (B_TimesD_bytes wit, B_bytes s, B_bytes t) {
    int64_t nbytes = (int64_t)s->nbytes + t->nbytes;
    check_result_len(nbytes);
    B_bytes res;
    NEW_UNFILLED_BYTES(res, nbytes);
    memcpy(res->str, s->str, s->nbytes);
    memcpy(res->str + s->nbytes, t->str, t->nbytes);
    return res;
}

B_bytes B_TimesD_bytesD___zero__ (B_TimesD_bytes wit) {
    return actBytesFromCStringCopy("");
}

B_bytes B_TimesD_bytesD___mul__ (B_TimesD_bytes wit, B_bytes a, B_int n) {
    int64_t nval = n->val;
    if (nval <= 0 || a->nbytes == 0)
        return actBytesFromCStringCopy("");
    // The count times the length could overflow, so the count is checked
    // against how many copies fit instead
    if (nval > MAX_STR_LEN / a->nbytes)
        RAISE_EXC(&B_str_too_long_error);
    int64_t nbytes = a->nbytes * nval;
    B_bytes res;
    NEW_UNFILLED_BYTES(res, nbytes);
    for (int64_t i = 0; i < nval; i++)
        memcpy(res->str + i * a->nbytes, a->str, a->nbytes);
    return res;
}

// Hashable


B_NoneType B_HashableD_bytesD_hash(B_HashableD_bytes wit, B_bytes a, B_hasher h) {
    zig_hash_wyhash_update(h->_hasher, a->str, a->nbytes);
    return B_None;
}

// Builtin functions involving strings /////////////////////////////////////////////

B_str B_ascii(B_value v) {
    B_str s  = v->$class->__str__(v);
    struct byte_counts bs = byte_count(s->str, s->nbytes);
    //    printf("%d %d %d %d %d %d\n",bs.escaped,bs.squotes,bs.dquotes,bs.printable,bs.non_printable,bs.non_ascii);
    bool use_single_quotes = !(bs.dquotes==0 && bs.squotes>0);
    int64_t escaped_quotes = use_single_quotes ? bs.squotes : bs.dquotes;
    int64_t nbytes = (int64_t)s->nbytes + 2 + bs.escaped + 3 * (int64_t)bs.non_printable + escaped_quotes + 3 * (int64_t)bs.non_ascii;
    check_result_len(nbytes);
    B_str res;
    // Every byte from 127 up is escaped, so the result is ASCII and has as
    // many chars as bytes
    NEW_UNFILLED_STR(res, nbytes, nbytes);
    escape_str(res->str + 1, s->str, res->nbytes - 1, s->nbytes, 255, use_single_quotes, !use_single_quotes, false, false);
    if (use_single_quotes) {
        res->str[0] = '\'';
        res->str[res->nbytes-1] = '\'';
    } else {
        res->str[0] = '"';
        res->str[res->nbytes-1] = '"';
    }
    return res;
}

B_str B_bin(B_Integral wit, $WORD n) {
    long v = wit->$class->__int__(wit,n);
    int sign = v<0;
    int nbits = 1;
    unsigned long u = labs(v);
    if (u & 0xffffffff00000000) {
        u >>= 32; nbits += 32;
    }
    if (u & 0x00000000ffff0000) {
        u >>= 16; nbits += 16;
    }
    if (u & 0x000000000000ff00) {
        u >>= 8; nbits += 8;
    }
    if (u & 0x00000000000000f0) {
        u >>= 4; nbits += 4;
    }
    if (u & 0x000000000000000c) {
        u >>= 2; nbits += 2;
    }
    if (u & 0x0000000000000002) {
        u >>= 1; nbits += 1;
    }
    B_str res;
    int nbytes = sign+2+nbits;
    NEW_UNFILLED_STR(res,nbytes,nbytes);
    unsigned char *p = res->str;
    if (sign) {
        *p = '-'; p++;
    }
    *p = '0'; p++;
    *p = 'b'; p++;
    u = labs(v);
    for (int i = nbits-1; i>=0; i--) {
        *p = u & (1L << i) ? '1' : '0'; p++;
    }
    return res;
}

B_str B_chr(B_Integral wit, $WORD n) {
    int64_t v = wit->$class->__int__(wit,n);
    // Surrogates are not characters and have no UTF-8 encoding
    if (v >=  0x110000 || (v >= 0xd800 && v <= 0xdfff))
        RAISE_EXC(&B_str_invalid_code_point_error);
    if (v >= 0 && v < ASCII_CHAR_TABLE_SIZE)
        return &ascii_char_strs[v];
    unsigned char code[4];
    int nbytes = utf8proc_encode_char((int)v,(unsigned char*)&code);
    if (nbytes==0)
        RAISE_EXC(&B_str_invalid_code_point_error);
    B_str res;
    NEW_UNFILLED_STR(res,1,nbytes);
    for (int i=0; i<nbytes; i++)
        res->str[i] = code[i];
    return res;
}

B_str B_hex(B_Integral wit, $WORD n) {
    unsigned char *hexdigits = (unsigned char *)"0123456789abcdef";
    long v =  wit->$class->__int__(wit,n);
    int sign = v<0;
    int nhexs = 1;
    unsigned long u = labs(v);
    if (u & 0xffffffff00000000) {
        u >>= 32; nhexs += 8;
    }
    if (u & 0x00000000ffff0000) {
        u >>= 16; nhexs += 4;
    }
    if (u & 0x000000000000ff00) {
        u >>= 8; nhexs += 2;
    }
    if (u & 0x00000000000000f0) {
        u >>= 4; nhexs += 1;
    }
    B_str res;
    int nbytes = sign+2+nhexs;
    NEW_UNFILLED_STR(res,nbytes,nbytes);
    unsigned char *p = res->str;
    if (sign) {
        *p = '-'; p++;
    }
    *p = '0'; p++;
    *p = 'x'; p++;
    u = labs(v);
    for (int i = nhexs-1; i>=0; i--) {
        *p = hexdigits[(u>>(4*i)) & 0xf]; p++;
    }
    return res;
}

int64_t B_ord(B_str c) {
    if(c->nchars != 1)
        RAISE_EXC(&B_str_invalid_ord_error);
    int cp;
    int cpnbytes = utf8proc_iterate(c->str,-1,&cp);
    if (cpnbytes < 0)
        RAISE_EXC(&B_str_invalid_ord_error);
    return (int64_t)cp;
}

// Auxiliary function used in __str__ for collections ////////////////////////////

B_str B_strD_join_par(char lpar, B_list elems, char rpar) {
    char *s = ", ";
    int64_t len = elems->length;
    int64_t totchars = 2;  //parens
    int64_t totbytes = 2;
    B_str nxt;
    // The total is checked as it grows, so it can't overflow before it is
    // checked
    for (int64_t i = 0; i < len; i++) {
        nxt = (B_str)elems->data[i];
        totchars += nxt->nchars;
        totbytes += nxt->nbytes;
        check_result_len(totbytes);
    }
    if (len > 1) {
        totchars += (len - 1) * 2; // 2 is length of ", "
        totbytes += (len - 1) * 2;
        check_result_len(totbytes);
    }
    B_str res;
    NEW_UNFILLED_STR(res, totchars, totbytes);
    res->str[0] = lpar;
    res->str[totbytes-1] = rpar;
    if (len > 0) {
        unsigned char *p = res->str+1;
        nxt = elems->data[0];
        memcpy(p,nxt->str,nxt->nbytes);
        p += nxt->nbytes;
        for (int64_t i=1; i<len; i++) {
            nxt = (B_str)elems->data[i];
            memcpy(p,s,2);
            p += 2;
            memcpy(p,nxt->str,nxt->nbytes);
            p += nxt->nbytes;
        }
    }
    return res;
}

B_str $default__str__(B_value self) {
    return $FORMAT("<%s object at %p>", self->$class->$GCINFO, self);
}


B_str $FORMAT(const char *format, ...) {
    va_list args;
    va_start(args, format);

    va_list args_copy;
    va_copy(args_copy, args);
    int size = vsnprintf(NULL, 0, format, args_copy);
    va_end(args_copy);

    if (size < 0) {
        va_end(args);
        RAISE_EXC(&B_str_invalid_format_error);
    }

    char *buffer = (char *)acton_malloc_atomic(size + 1);
    if (buffer == NULL) {
        va_end(args);
        RAISE_EXC(&B_str_format_allocation_failed_error);
    }

    vsnprintf(buffer, size + 1, format, args);
    va_end(args);

    return actStrFromCString(buffer);
}

// Output buffer for $FORMAT_len, grown as needed.
struct format_buf {
    char *data;
    int64_t len;
    int64_t cap;
};

// Make room for n more bytes and the terminator of the result. The result is
// checked as it grows, by lengths and widths of at most MAX_STR_LEN, so the
// sum can't overflow before it is checked.
static void format_reserve(struct format_buf *b, int64_t n) {
    check_result_len(b->len + n);
    if (b->len + n < b->cap)
        return;
    int64_t cap = b->cap * 2;
    if (cap < b->len + n + 1)
        cap = b->len + n + 1;
    char *data = acton_realloc(b->data, cap);
    if (data == NULL)
        RAISE_EXC(&B_str_allocation_failed_error);
    b->data = data;
    b->cap = cap;
}

static void format_append(struct format_buf *b, const char *s, int64_t n) {
    format_reserve(b, n);
    memcpy(b->data + b->len, s, n);
    b->len += n;
}

static void format_pad(struct format_buf *b, int64_t n) {
    if (n <= 0)
        return;
    format_reserve(b, n);
    memset(b->data + b->len, ' ', n);
    b->len += n;
}

// Append s, cut to prec characters and padded with spaces to width characters
// (a negative width or prec means none was given).
static void format_str(struct format_buf *b, B_str s, bool left, int width, int prec) {
    int64_t nchars = s->nchars;
    int64_t nbytes = s->nbytes;
    if (prec >= 0 && prec < nchars) {
        nbytes = skip_chars(s->str, prec, s->nchars == s->nbytes) - s->str;
        nchars = prec;
    }
    if (!left)
        format_pad(b, width - nchars);
    format_append(b, (const char *)s->str, nbytes);
    if (left)
        format_pad(b, width - nchars);
}

// Append one numeric conversion, which spec (like "%-8.3f") describes completely.
static void format_printf(struct format_buf *b, const char *spec, ...) {
    va_list args, args_copy;
    va_start(args, spec);
    va_copy(args_copy, args);
    int n = vsnprintf(NULL, 0, spec, args_copy);
    va_end(args_copy);
    if (n < 0) {
        va_end(args);
        RAISE_EXC(&B_str_invalid_format_error);
    }
    format_reserve(b, n);
    vsnprintf(b->data + b->len, n + 1, spec, args);
    va_end(args);
    b->len += n;
}

// Read the decimal number at *p, if any, and step past it; -1 if there is none.
static int format_count(const char **p, const char *end) {
    int64_t n = -1;
    while (*p < end && **p >= '0' && **p <= '9') {
        n = (n < 0 ? 0 : n) * 10 + (**p - '0');
        if (n > INT_MAX)
            RAISE_EXC(&B_str_invalid_format_error);
        (*p)++;
    }
    return n;
}

static bool format_is(const char *set, char c) {
    return c != '\0' && strchr(set, c) != NULL;
}

// The formatting behind Acton's % operator and interpolated strings. Unlike
// $FORMAT, the format is nbytes long rather than NUL-terminated, and a %s, %r
// or %a argument is a B_str rather than a char *, so NUL bytes are kept in both.
// Width and precision of those conversions count characters; %r and %a insert
// repr() and ascii() of the string. Each other conversion is handed to
// snprintf on its own, with the length modifier the compiler has added (%ld).
B_str $FORMAT_len(const char *format, int64_t nbytes, ...) {
    va_list args;
    va_start(args, nbytes);
    struct format_buf b = {(char *)alloc_data(nbytes + 16), 0, nbytes + 16};
    const char *p = format;
    const char *end = format + nbytes;
    while (p < end) {
        const char *pct = memchr(p, '%', end - p);
        if (pct == NULL) {
            format_append(&b, p, end - p);
            break;
        }
        format_append(&b, p, pct - p);
        p = pct + 1;

        // The spec handed to snprintf, with any * width or precision filled in.
        char spec[64];
        int k = 0;
        spec[k++] = '%';
        bool left = false;
        while (p < end && format_is("#0- +", *p)) {
            left |= *p == '-';
            if (k < 16)
                spec[k++] = *p;
            p++;
        }
        int width;
        if (p < end && *p == '*') {
            width = va_arg(args, int);
            p++;
            if (width < 0) {
                if (width == INT_MIN)
                    RAISE_EXC(&B_str_invalid_format_error);
                width = -width;
                left = true;
                spec[k++] = '-';
            }
        } else
            width = format_count(&p, end);
        int prec = -1;
        if (p < end && *p == '.') {
            p++;
            if (p < end && *p == '*') {
                prec = va_arg(args, int);
                p++;
            } else {
                prec = format_count(&p, end);
                if (prec < 0)
                    prec = 0;
            }
        }
        const char *lenmod = p;
        while (p < end && format_is("hlL", *p))
            p++;
        int nlenmod = p - lenmod < 3 ? p - lenmod : 3;
        if (p == end) {
            va_end(args);
            RAISE_EXC(&B_str_invalid_format_error);
        }
        char conv = *p++;

        if (conv == '%') {
            format_append(&b, "%", 1);
        } else if (format_is("sra", conv)) {
            B_str s = va_arg(args, B_str);
            if (conv == 'r')
                s = B_strD___repr__(s);
            else if (conv == 'a')
                s = B_ascii((B_value)s);
            format_str(&b, s, left, width, prec);
        } else {
            if (width >= 0)
                k += snprintf(spec + k, sizeof spec - k, "%d", width);
            if (prec >= 0)
                k += snprintf(spec + k, sizeof spec - k, ".%d", prec);
            // The compiler passes every integer as an int64_t, which is a
            // long long on some platforms, so it is printed with ll
            bool integer = format_is("diouxX", conv);
            memcpy(spec + k, integer ? "ll" : lenmod, integer ? 2 : nlenmod);
            k += integer ? 2 : nlenmod;
            spec[k++] = conv;
            spec[k] = '\0';
            if (integer)
                format_printf(&b, spec, (long long)va_arg(args, int64_t));
            else if (conv == 'c')
                format_printf(&b, spec, (wint_t)va_arg(args, int64_t));
            else if (format_is("eEfFgG", conv))
                format_printf(&b, spec, va_arg(args, double));
            else {
                va_end(args);
                RAISE_EXC(&B_str_invalid_format_error);
            }
        }
    }
    va_end(args);
    b.data[b.len] = 0;
    return str_from_c(b.data, b.len, false, &B_str_invalid_utf8_error);
}
