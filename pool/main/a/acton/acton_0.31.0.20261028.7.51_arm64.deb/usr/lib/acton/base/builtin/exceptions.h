#include <setjmp.h>

// setjmp/longjmp for try/raise. On macOS and the BSDs, plain setjmp/longjmp
// also save and restore the signal mask, which costs a sigprocmask system
// call on every try entry and every raise (~10x slower exception handling).
// Nothing raises out of a signal handler, so the mask never needs restoring
// and _setjmp/_longjmp, which skip it, are safe. glibc and musl setjmp do not
// save the mask and Windows has none, so use plain setjmp/longjmp there.
#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__DragonFly__)
#define $SETJMP(buf)        _setjmp(buf)
#define $LONGJMP(buf, val)  _longjmp(buf, val)
#else
#define $SETJMP(buf)        setjmp(buf)
#define $LONGJMP(buf, val)  longjmp(buf, val)
#endif

// An exception frame. $PUSH(frame) links a frame that the caller owns, so
// pushing allocates nothing. A try keeps its frame in a local variable of the
// function that runs it, and that function pops the frame with $DROP or $POP
// before it returns, as setjmp requires. Each active try therefore takes
// sizeof(struct JumpBuf) of C stack: 208 bytes on macOS arm64, 216 on x86_64
// Linux and 328 on aarch64 Linux. $RAISE writes the exception in flight
// (xval) and $POP reads it only through jump_top, never through the local
// variable, which keeps it valid after the longjmp without volatile. The GC
// finds it when it scans the thread's stack. The one frame that outlives the
// function that pushed it is the worker loop's (see jump0 in WorkerCtx).
struct JumpBuf;
typedef struct JumpBuf *JumpBuf;
struct JumpBuf {
    jmp_buf buf;
    B_BaseException xval;
    JumpBuf prev;
};

void $RAISE(B_BaseException e);
JumpBuf $PUSH_BUF(JumpBuf frame);
void $DROP();
B_BaseException $POP();
#define $PUSH(frame)        (!$SETJMP($PUSH_BUF(frame)->buf))
#define $PUSHF $PUSH

// File-scope initializer for an exception with a fixed ASCII string literal.
// The exception and its string have static storage; raising only updates the catch
// frame, so they can be shared by all workers. Any other fields must also have
// fixed values; omitted pointer fields are None. Keep per-call payloads in
// separately constructed exceptions.
#define STATIC_EXCEPTION($T, msg) { \
    .$class = &$T ## G_methods, \
    .error_message = &(struct B_str){ \
        &B_strG_methods, sizeof("" msg) - 1, sizeof("" msg) - 1, (unsigned char *)("" msg) \
    } \
}

 
/*
  Exceptions hierarchy in Python 3.8 according to

  https://docs.python.org/3/library/exceptions.html

  BaseException
  +-- SystemExit
  +-- KeyboardInterrupt
  +-- GeneratorExit
  +-- Exception
  +-- StopIteration
  +-- StopAsyncIteration
  +-- ArithmeticError
  |    +-- FloatingPointError              ***
  |    +-- OverflowError
  |    +-- ZeroDivisionError
  +-- AssertionError
  +-- AttributeError
  +-- BufferError                          ***
  +-- EOFError
  +-- ImportError                          ***
  |    +-- ModuleNotFoundError             ***
  +-- LookupError           
  |    +-- IndexError
  |    +-- KeyError
  +-- MemoryError
  +-- NameError                            ***
  |    +-- UnboundLocalError               ***
  +-- OSError
  |    +-- BlockingIOError
  |    +-- ChildProcessError
  |    +-- ConnectionError
  |    |    +-- BrokenPipeError
  |    |    +-- ConnectionAbortedError
  |    |    +-- ConnectionRefusedError
  |    |    +-- ConnectionResetError
  |    +-- FileExistsError
  |    +-- FileNotFoundError
  |    +-- InterruptedError
  |    +-- IsADirectoryError
  |    +-- NotADirectoryError
  |    +-- PermissionError
  |    +-- ProcessLookupError
  |    +-- TimeoutError
  +-- ReferenceError                       ***
  +-- RuntimeError
  |    +-- NotImplementedError
  |    +-- RecursionError
  +-- SyntaxError                          ***
  |    +-- IndentationError
  |         +-- TabError
  +-- SystemError
  +-- TypeError                            ***
  +-- ValueError
  |    +-- UnicodeError
  |         +-- UnicodeDecodeError
  |         +-- UnicodeEncodeError
  |         +-- UnicodeTranslateError
  +-- Warning
  +-- DeprecationWarning
  +-- PendingDeprecationWarning
  +-- RuntimeWarning
  +-- SyntaxWarning
  +-- UserWarning
  +-- FutureWarning
  +-- ImportWarning
  +-- UnicodeWarning
  +-- BytesWarning
  +-- ResourceWarning

  Plus the (hidden) primitive exceptions that implement control flow in the presence of finalizers:

  +-- $SEQ
  +-- $BRK
  +-- $CNT
  +-- $RET
 
*/

struct $SEQ;
struct $BRK;
struct $CNT;
struct $RET;

typedef struct $SEQ *$SEQ;
typedef struct $BRK *$BRK;
typedef struct $CNT *$CNT;
typedef struct $RET *$RET;

struct $SEQG_class {
    char *$GCINFO;
    int $class_id;
    $SuperG_class $superclass;
    B_NoneType (*__init__) ($SEQ);
    void (*__serialize__) ($SEQ, $Serial$state);
    $SEQ (*__deserialize__) ($SEQ, $Serial$state);
    bool (*__bool__) ($SEQ);
    B_str (*__str__) ($SEQ);
    B_str (*__repr__) ($SEQ);
};
struct $SEQ {
    struct $SEQG_class *$class;
    B_str error_message;
};
struct $BRKG_class {
    char *$GCINFO;
    int $class_id;
    $SuperG_class $superclass;
    B_NoneType (*__init__) ($BRK);
    void (*__serialize__) ($BRK, $Serial$state);
    $BRK (*__deserialize__) ($BRK, $Serial$state);
    bool (*__bool__) ($BRK);
    B_str (*__str__) ($BRK);
    B_str (*__repr__) ($BRK);
};
struct $BRK {
    struct $BRKG_class *$class;
    B_str error_message;
};
struct $CNTG_class {
    char *$GCINFO;
    int $class_id;
    $SuperG_class $superclass;
    B_NoneType (*__init__) ($CNT);
    void (*__serialize__) ($CNT, $Serial$state);
    $CNT (*__deserialize__) ($CNT, $Serial$state);
    bool (*__bool__) ($CNT);
    B_str (*__str__) ($CNT);
    B_str (*__repr__) ($CNT);
};
struct $CNT {
    struct $CNTG_class *$class;
    B_str error_message;
};
struct $RETG_class {
    char *$GCINFO;
    int $class_id;
    $SuperG_class $superclass;
    B_NoneType (*__init__) ($RET, B_value);
    void (*__serialize__) ($RET, $Serial$state);
    $RET (*__deserialize__) ($RET, $Serial$state);
    bool (*__bool__) ($RET);
    B_str (*__str__) ($RET);
    B_str (*__repr__) ($RET);
};
struct $RET {
    struct $RETG_class *$class;
    B_str error_message;
    B_value val;
};

extern struct $SEQG_class $SEQG_methods;
extern struct $BRKG_class $BRKG_methods;
extern struct $CNTG_class $CNTG_methods;
extern struct $RETG_class $RETG_methods;

$SEQ $SEQG_new();
$BRK $BRKG_new();
$CNT $CNTG_new();
$RET $RETG_new(B_value);

$WORD $raiseValueError(B_str str);
 
