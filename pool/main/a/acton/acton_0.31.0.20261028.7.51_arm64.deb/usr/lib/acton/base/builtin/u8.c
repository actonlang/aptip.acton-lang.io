/*
 * Copyright (C) 2019-2021 Data Ductus AB
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

static struct B_ZeroDivisionError B_u8_zero_division_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "division by zero");
struct B_ZeroDivisionError B_u8_truediv_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "u8 truediv: division by zero");
struct B_ZeroDivisionError B_u8_floordiv_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "u8 floordiv: division by zero");
struct B_ZeroDivisionError B_u8_mod_zero_error =
    STATIC_EXCEPTION(B_ZeroDivisionError, "u8 mod: division by zero");

// Auxiliary //////////////////////////////////////////////////////////////////////////////

// only called with e>=0.
uint8_t u8_pow(uint8_t a, uint8_t e) {
    if (e == 0) return 1;
    if (e == 1) return a;
    if (e%2 == 0) return int_pow(a*a,e/2);
    return a * int_pow(a*a,e/2);
}

// General methods
///////////////////////////////////////////////////////////////////////

uint8_t B_u8G_new(B_atom a, B_int base) {  // base is optional
    B_bigint b = B_bigintG_new(a, base);
    int sz = b->val.size;
    unsigned long n = sz == 0 ? 0 : b->val.n[0];
    if (sz  > 1 || sz < 0 || (sz==1 && n > 0xff)) {
        char errmsg[1024];
        snprintf(errmsg, sizeof(errmsg), "u8(): value %s out of range for type u8",get_str(&b->val));
        RAISE(B_ValueError, actStrFromCStringCopy(errmsg));
    }
    return n*sz;
}
 
B_NoneType B_u8D___init__(B_u8 self, B_atom a, B_int base){
    self->val = B_u8G_new(a,base);
    return B_None;
}

void B_u8D___serialize__(B_u8 n, $Serial$state state) {
    $val_serialize(U8_ID,&n->val,state);
}

B_u8 B_u8D___deserialize__(B_u8 n, $Serial$state state) {
    return toB_u8((uint8_t)(uintptr_t)$val_deserialize(state));
}

bool B_u8D___bool__(B_u8 n) {
    return n->val != 0;
}

B_str B_u8D___str__(B_u8 n) {
    return $FORMAT("%c",(unsigned char) n->val);
}

B_str B_u8D___repr__(B_u8 n) {
    return $FORMAT("%c", (unsigned char)n->val);
}

B_u8 toB_u8(uint8_t i) {
    B_u8 res = acton_malloc_atomic(sizeof(struct B_u8));
    res->$class = &B_u8G_methods;
    res->val = i;
    return res;
}

uint8_t fromB_u8(B_u8 w) {
    return w->val;
}



// B_IntegralD_u8 /////////////////////////////////////////////////////////////////////////


B_u8 B_IntegralD_u8D___add__(B_IntegralD_u8 wit,  B_u8 a, B_u8 b) {
    return toB_u8(a->val + b->val); 
}

B_u8 B_IntegralD_u8D___zero__(B_IntegralD_u8 wit) {
    return toB_u8(0);
}

B_complex B_IntegralD_u8D___complex__(B_IntegralD_u8 wit, B_u8 a) {
    return toB_complex((double)(a->val));
}

B_u8 B_IntegralD_u8D___fromatom__(B_IntegralD_u8 wit, B_atom a) {
    return toB_u8(B_u8G_new(a,NULL));
}

B_u8 B_IntegralD_u8D___mul__(B_IntegralD_u8 wit,  B_u8 a, B_u8 b) {
    return toB_u8(a->val * b->val);
}  
  
B_u8 B_IntegralD_u8D___pow__(B_IntegralD_u8 wit,  B_u8 a, B_u8 b) {
    uint8_t aval = a->val;
    uint8_t bval = b->val;
    return toB_u8(int_pow(aval,bval));
}

B_u8 B_IntegralD_u8D___neg__(B_IntegralD_u8 wit,  B_u8 a) {
    return toB_u8(-a->val);
}

B_u8 B_IntegralD_u8D___pos__(B_IntegralD_u8 wit,  B_u8 a) {
    return a;
}

$WORD B_IntegralD_u8D_real(B_IntegralD_u8 wit, B_u8 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)(a));
}

$WORD B_IntegralD_u8D_imag(B_IntegralD_u8 wit, B_u8 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_u8(0LL));
}

$WORD B_IntegralD_u8D___abs__(B_IntegralD_u8 wit, B_u8 a, B_Real wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_u8(a->val));
}

B_u8 B_IntegralD_u8D_conjugate(B_IntegralD_u8 wit,  B_u8 a) {
    return a;
}

double B_IntegralD_u8D___float__ (B_IntegralD_u8 wit, B_u8 n) {
    return (double)n->val;
}

$WORD B_IntegralD_u8D___trunc__ (B_IntegralD_u8 wit, B_u8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_u8D___floor__ (B_IntegralD_u8 wit, B_u8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_u8D___ceil__ (B_IntegralD_u8 wit, B_u8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
B_u8 B_IntegralD_u8D___round__ (B_IntegralD_u8 wit, B_u8 n, B_int p) {
    uint8_t nval = n->val;
    int8_t pval = p==NULL ? 0 : fromB_int(p);
    if (pval>=0)
        return n;
    uint8_t p10 = int_pow(10,-pval);
    uint8_t res = nval/p10;
    if (nval%p10 * 2 > p10)
        res++; 
    return toB_u8(res * p10);
}
  
$WORD B_IntegralD_u8D_numerator (B_IntegralD_u8 wit, B_u8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)n);
}
  
$WORD B_IntegralD_u8D_denominator (B_IntegralD_u8 wit, B_u8 n, B_Integral wit2) {
    return wit2->$class->__fromatom__(wit2,(B_atom)toB_u8(1LL));
}
  
int64_t B_IntegralD_u8D___int__ (B_IntegralD_u8 wit, B_u8 n) {
    return n->val;
}

int64_t B_IntegralD_u8D___index__(B_IntegralD_u8 wit, B_u8 n) {
    return n->val;
}

B_tuple B_IntegralD_u8D___divmod__(B_IntegralD_u8 wit, B_u8 a, B_u8 b) {
    uint8_t n = a->val;
    uint8_t d = b->val;
    return $NEWTUPLE(2, toB_u8(n/d), toB_u8(n%d));
}

B_u8 B_IntegralD_u8D___floordiv__(B_IntegralD_u8 wit, B_u8 a, B_u8 b) {
    if (b->val == 0)
        RAISE_EXC(&B_u8_zero_division_error);
    return toB_u8(a->val / b->val);
}

B_u8 B_IntegralD_u8D___mod__(B_IntegralD_u8 wit, B_u8 a, B_u8 b) {
    return toB_u8(a->val % b->val);
}

B_u8 B_IntegralD_u8D___lshift__(B_IntegralD_u8 wit,  B_u8 a, int64_t b) {
    return toB_u8(a->val << b);
}

B_u8 B_IntegralD_u8D___rshift__(B_IntegralD_u8 wit,  B_u8 a, int64_t b) {
    return toB_u8(a->val >> b);
}
 
B_u8 B_IntegralD_u8D___invert__(B_IntegralD_u8 wit,  B_u8 a) {
    return toB_u8(~a->val);
}


// B_LogicalD_IntegralD_u8  ////////////////////////////////////////////////////////////////////////////////////////

B_u8 B_LogicalD_IntegralD_u8D___and__(B_LogicalD_IntegralD_u8 wit,  B_u8 a, B_u8 b) {
    return toB_u8(a->val & b->val);
}
                                                 
B_u8 B_LogicalD_IntegralD_u8D___or__(B_LogicalD_IntegralD_u8 wit,  B_u8 a, B_u8 b) {
    return toB_u8(a->val | b->val);
}
                                                 
B_u8 B_LogicalD_IntegralD_u8D___xor__(B_LogicalD_IntegralD_u8 wit,  B_u8 a, B_u8 b) {
    return toB_u8(a->val ^ b->val);
}  
 
// B_MinusD_IntegralD_u8  ////////////////////////////////////////////////////////////////////////////////////////

 
B_u8 B_MinusD_IntegralD_u8D___sub__(B_MinusD_IntegralD_u8 wit,  B_u8 a, B_u8 b) {
    return toB_u8(a->val - b->val);
}  

// B_DivD_u8  ////////////////////////////////////////////////////////////////////////////////////////

 
B_float B_DivD_u8D___truediv__ (B_DivD_u8 wit, B_u8 a, B_u8 b) {
    if (b->val == 0)
        RAISE_EXC(&B_u8_zero_division_error);
    return toB_float((double)a->val/(double)b->val);
}

// B_OrdD_u8  ////////////////////////////////////////////////////////////////////////////////////////

bool B_OrdD_u8D___eq__ (B_OrdD_u8 wit, B_u8 a, B_u8 b) {
    return a->val == b->val;
}

bool B_OrdD_u8D___ne__ (B_OrdD_u8 wit, B_u8 a, B_u8 b) {
    return a->val != b->val;
}

bool B_OrdD_u8D___lt__ (B_OrdD_u8 wit, B_u8 a, B_u8 b) {
    return a->val < b->val;
}

bool B_OrdD_u8D___le__ (B_OrdD_u8 wit, B_u8 a, B_u8 b) {
    return a->val <= b->val;
}

bool B_OrdD_u8D___gt__ (B_OrdD_u8 wit, B_u8 a, B_u8 b) {
    return a->val > b->val;
}

bool B_OrdD_u8D___ge__ (B_OrdD_u8 wit, B_u8 a, B_u8 b) {
    return a->val >= b->val;
}

// B_HashableD_u8 ///////////////////////////////////////////////////////////////////////////////////////////////////////

B_NoneType B_HashableD_u8D_hash(B_HashableD_u8 wit, B_u8 a, B_hasher h) {
    zig_hash_wyhash_update(h->_hasher, (const uint8_t *)&a->val, sizeof(a->val));
    return B_None;
}
