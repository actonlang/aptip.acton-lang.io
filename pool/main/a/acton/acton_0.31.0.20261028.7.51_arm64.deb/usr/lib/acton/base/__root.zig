const std = @import("std");

const acton = @import("acton.zig");
const gc = @import("rts/gc.zig");

// Both base64 functions build their result with acton.new_bytes so that it
// looks exactly like bytes built by the C runtime, with a real (non-dangling)
// buffer even when the output is empty.
export fn base64Q_encode(data: *acton.bytes) callconv(.c) *acton.bytes {
    const encoder = std.base64.standard.Encoder;
    // For possible Unicode input, bytes and chars may not be 1:1
    const data_len: usize = @intCast(data.nbytes);
    const out_len = encoder.calcSize(data_len);
    const res = acton.new_bytes(data.class, out_len);
    const buffer: []u8 = @constCast(res.str[0..out_len]);
    _ = encoder.encode(buffer, data.str[0..data_len]);
    return res;
}

export fn base64Q_decode(data: *acton.bytes) callconv(.c) *acton.bytes {
    const decoder = std.base64.standard.Decoder;
    // Slice the input by its length for the decoder
    const data_len: usize = @intCast(data.nbytes);
    const data_slice = data.str[0..data_len];
    // And then compute the exact number of bytes we need to decode, without padding
    const out_len = decoder.calcSizeForSlice(data_slice) catch {
        acton.raise_ValueError("Invalid base64 input data");
        unreachable; // raise above does longjmp so this is unreachable
    };
    const res = acton.new_bytes(data.class, out_len);
    const buffer: []u8 = @constCast(res.str[0..out_len]);
    // calcSizeForSlice only validates the length and trailing padding, so
    // decode can still fail on characters outside the alphabet or on
    // misplaced padding.
    decoder.decode(buffer, data_slice) catch {
        acton.raise_ValueError("Invalid base64 input data");
        unreachable;
    };
    return res;
}

export fn stdQ_base64Q_encode(data: *acton.bytes) callconv(.c) *acton.bytes {
    return base64Q_encode(data);
}

export fn stdQ_base64Q_decode(data: *acton.bytes) callconv(.c) *acton.bytes {
    return base64Q_decode(data);
}

export fn zig_crypto_hash_md5_init() callconv(.c) *std.crypto.hash.Md5 {
    // Md5 state is only integers and bytes, so it need not be scanned
    const alloc = gc.atomicAllocator();
    const hasher_ptr = alloc.create(std.crypto.hash.Md5) catch {
        unreachable("OOM while allocating Md5 hasher");
    };
    hasher_ptr.* = std.crypto.hash.Md5.init(.{});

    return hasher_ptr;
}

export fn zig_crypto_hash_md5_update(hasher: *std.crypto.hash.Md5, data: *acton.bytes) callconv(.c) void {
    const len: usize = @intCast(data.nbytes); // destination type from context
    const slice = data.str[0..len];
    hasher.update(slice);
}

export fn zig_crypto_hash_md5_finalize(hasher: *std.crypto.hash.Md5, output: *acton.bytes) callconv(.c) void {
    const digest_len = 16;
    const out_slice: *[16]u8 = @as([*]u8, @ptrCast(@constCast(output.str)))[0..digest_len];
    hasher.final(out_slice);
}

export fn zig_hash_wyhash_init(seed: u64) callconv(.c) *std.hash.Wyhash {
    // Wyhash state is only integers and bytes, so it need not be scanned
    const alloc = gc.atomicAllocator();
    const hasher_ptr = alloc.create(std.hash.Wyhash) catch {
        acton.raise_MemoryError("OOM while allocating Wyhash hasher");
        unreachable; // raise above does longjmp so this is unreachable
    };
    hasher_ptr.* = std.hash.Wyhash.init(seed);

    return hasher_ptr;
}

/// Size of the private Wyhash state used by the C runtime.  The ordinary
/// hasher constructor allocates this state on the GC heap because the
/// resulting Acton object may escape.  B_hash uses this size to reserve
/// suitably aligned automatic storage for its non-escaping hasher.
export fn zig_hash_wyhash_size() callconv(.c) usize {
    return @sizeOf(std.hash.Wyhash);
}

/// Initialize Wyhash in caller-owned storage.  The pointer must have the
/// alignment of std.hash.Wyhash; B_hash supplies max_align_t storage.
export fn zig_hash_wyhash_init_in_place(storage: *anyopaque, seed: u64) callconv(.c) *std.hash.Wyhash {
    const hasher_ptr: *std.hash.Wyhash = @ptrCast(@alignCast(storage));
    hasher_ptr.* = std.hash.Wyhash.init(seed);
    return hasher_ptr;
}

export fn zig_hash_wyhash_update(hasher: *std.hash.Wyhash, ptr: [*]const u8, len: usize) callconv(.c) void {
    hasher.update(ptr[0..len]);
}

export fn zig_hash_wyhash_total_len(hasher: *std.hash.Wyhash) callconv(.c) u64 {
    return hasher.total_len;
}

export fn zig_hash_wyhash_final(hasher: *std.hash.Wyhash) callconv(.c) u64 {
    return hasher.final();
}

export fn zig_hash_wyhash_hash_buffer(seed: u64, ptr: [*]const u8, len: usize) callconv(.c) u64 {
    return std.hash.Wyhash.hash(seed, ptr[0..len]);
}

export fn zig_hash_wyhash_hash(seed: u64, data: *acton.bytes) callconv(.c) u64 {
    const len: usize = @intCast(data.nbytes); // destination type from context
    return zig_hash_wyhash_hash_buffer(seed, data.str, len);
}
