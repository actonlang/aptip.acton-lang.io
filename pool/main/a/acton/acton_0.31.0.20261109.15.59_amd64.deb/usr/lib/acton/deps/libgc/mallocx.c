/*
 * Copyright 1988, 1989 Hans-J. Boehm, Alan J. Demers
 * Copyright (c) 1991-1994 by Xerox Corporation.  All rights reserved.
 * Copyright (c) 1996 by Silicon Graphics.  All rights reserved.
 * Copyright (c) 2000 by Hewlett-Packard Company.  All rights reserved.
 * Copyright (c) 2009-2026 Ivan Maidanski
 *
 * THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
 * OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
 *
 * Permission is hereby granted to use or copy this program
 * for any purpose, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "private/gc_priv.h"

/*
 * These are extra allocation routines that are likely to be less
 * frequently used than those in `malloc.c` file.  They are separate in
 * the hope that the `.o` file will be excluded from statically linked
 * executables.  We should probably break this up further.
 */

#include <string.h>

#ifndef MSWINCE
#  include <errno.h>
#endif

/*
 * Some externally visible but unadvertised variables to allow access
 * to free lists from inlined allocators without include `gc_priv.h` file
 * or introducing dependencies on internal data structure layouts.
 */
#include "private/gc_alloc_ptrs.h"
void **const GC_objfreelist_ptr = GC_objfreelist;
void **const GC_aobjfreelist_ptr = GC_aobjfreelist;
void **const GC_uobjfreelist_ptr = GC_uobjfreelist;
#ifdef GC_ATOMIC_UNCOLLECTABLE
void **const GC_auobjfreelist_ptr = GC_auobjfreelist;
#endif

GC_API int GC_CALL
GC_get_kind_and_size(const void *p, size_t *psize)
{
  const hdr *hhdr = HDR(p);

  if (psize != NULL) {
    *psize = hhdr->hb_sz;
  }
  return hhdr->hb_obj_kind;
}

GC_API GC_ATTR_MALLOC void *GC_CALL
GC_generic_or_special_malloc(size_t lb, int kind)
{
  switch (kind) {
  case PTRFREE:
  case NORMAL:
    return GC_malloc_kind(lb, kind);
  case UNCOLLECTABLE:
#ifdef GC_ATOMIC_UNCOLLECTABLE
  case AUNCOLLECTABLE:
#endif
    return GC_generic_malloc_uncollectable(lb, kind);
  default:
    return GC_generic_malloc_aligned(lb, kind, 0 /* `flags` */, 0);
  }
}

#ifdef GC_REALLOC_NO_FREE
GC_INNER GC_bool GC_realloc_no_free = TRUE;
#else
GC_INNER GC_bool GC_realloc_no_free = FALSE;
#endif

GC_API void GC_CALL
GC_set_realloc_no_free(int value)
{
  GC_realloc_no_free = value != 0;
}

GC_API int GC_CALL
GC_get_realloc_no_free(void)
{
  return (int)GC_realloc_no_free;
}

GC_API void *GC_CALL
GC_realloc(void *p, size_t lb)
{
  hdr *hhdr;
  void *result;
#if defined(_FORTIFY_SOURCE) && defined(__GNUC__) && !defined(__clang__)
  /*
   * Use `cleared_p` instead of `p` as a workaround to avoid passing
   * `alloc_size(lb)` attribute associated with `p` to `memset`
   * (including a `memset` call inside `GC_free`).
   */
  volatile GC_uintptr_t cleared_p = (GC_uintptr_t)p;
#else
#  define cleared_p p
#endif
  size_t sz;      /*< current size in bytes */
  size_t orig_sz; /*< original `sz` (in bytes) */
  int obj_kind;

  if (NULL == p) {
    /* Required by ANSI. */
    return GC_malloc(lb);
  }
  if (0 == lb) /* `&& p != NULL` */ {
#ifndef IGNORE_FREE
    GC_free(p);
#endif
    return NULL;
  }
  hhdr = HDR(HBLKPTR(p));
  sz = hhdr->hb_sz;
  obj_kind = hhdr->hb_obj_kind;
  orig_sz = sz;

  if (sz > MAXOBJBYTES) {
    const struct obj_kind *ok = &GC_obj_kinds[obj_kind];
    word descr = ok->ok_descriptor;

    /* Round it up to the next whole heap block. */
    sz = (sz + HBLKSIZE - 1) & ~(HBLKSIZE - 1);
#if ALIGNMENT > GC_DS_TAGS
    /*
     * An extra byte is not added in case of ignore-off-page allocated
     * objects not smaller than `HBLKSIZE`.
     */
    GC_ASSERT(sz >= HBLKSIZE);
    if (EXTRA_BYTES != 0 && (hhdr->hb_flags & IGNORE_OFF_PAGE) != 0
        && obj_kind == NORMAL)
      descr += ALIGNMENT; /*< or set to 0 */
#endif
    if (ok->ok_relocate_descr) {
      descr += sz;
    }

    /*
     * `GC_realloc` might be changing the block size while
     * `GC_reclaim_block` or `GC_clear_hdr_marks` is examining it.
     * The change to the size field is benign, in that `GC_reclaim`
     * (and `GC_clear_hdr_marks`) would work correctly with either
     * value, since we are not changing the number of objects in
     * the block.  But seeing a half-updated value (though unlikely
     * to occur in practice) could be probably bad.
     * Using unordered atomic accesses on `hb_sz` and `hb_descr`
     * fields would solve the issue.  (The alternate solution might
     * be to initially overallocate large objects, so we do not
     * have to adjust the size in `GC_realloc`, if they still fit.
     * But that is probably more expensive, since we may end up
     * scanning a bunch of zeros during the collection.)
     */
#ifdef AO_HAVE_store
    AO_store(&hhdr->hb_sz, sz);
    AO_store((AO_t *)&hhdr->hb_descr, descr);
#else
    {
      LOCK();
      hhdr->hb_sz = sz;
      hhdr->hb_descr = descr;
      UNLOCK();
    }
#endif

#ifdef MARK_BIT_PER_OBJ
    GC_ASSERT(hhdr->hb_inv_sz == LARGE_INV_SZ);
#else
    GC_ASSERT((hhdr->hb_flags & LARGE_BLOCK) != 0
              && hhdr->hb_map[ANY_INDEX] == 1);
#endif
    if (IS_UNCOLLECTABLE(obj_kind))
      GC_non_gc_bytes += (sz - orig_sz);
    /* Extra area is already cleared by `GC_alloc_large_and_clear`. */
  }
  if (ADD_EXTRA_BYTES(lb) <= sz) {
    if (lb >= (sz >> 1)) {
      if (orig_sz > lb) {
        /* Clear unneeded part of object to avoid bogus pointer tracing. */
        BZERO((ptr_t)cleared_p + lb, orig_sz - lb);
      }
      return p;
    }
    /*
     * Shrink it.  Note: shrinking of large blocks is not implemented
     * efficiently.
     */
    sz = lb;
  }
  result = GC_generic_or_special_malloc((word)lb, obj_kind);
  if (LIKELY(result != NULL)) {
    /*
     * In case of shrink, it could also return original object.
     * But this gives the client warning of imminent disaster.
     */
    BCOPY(p, result, sz);
#ifndef IGNORE_FREE
    /*
     * In the "no free on realloc" mode, a small collectable object is
     * left to the collector, as `GC_free` acquires the allocator lock
     * (while the allocation of the new object usually does not).
     * A big object is still freed: it occupies whole heap blocks, which
     * freeing returns to the heap at once, at the cost of one acquisition
     * of the allocator lock.  An object of a kind with a disclaim
     * procedure is freed too (otherwise the procedure would be called for
     * the old object), as well as any object in the leak detection mode
     * (where the collector does not reclaim unreachable objects).
     */
    if (!GC_realloc_no_free || orig_sz > MAXOBJBYTES
        || IS_UNCOLLECTABLE(obj_kind)
#  ifdef ENABLE_DISCLAIM
        || GC_obj_kinds[obj_kind].ok_disclaim_proc != 0
#  endif
        || GC_find_leak_inner)
      GC_free((ptr_t)cleared_p);
#endif
  }
  return result;
#undef cleared_p
}

GC_API void *GC_CALL
GC_reallocf(void *p, size_t lb)
{
  void *result = GC_realloc(p, lb);

#ifndef IGNORE_FREE
  if (UNLIKELY(NULL == result))
    GC_free(p);
#endif
  return result;
}

#if defined(REDIRECT_MALLOC) && !defined(REDIRECT_MALLOC_IN_HEADER)
#  ifdef REDIRECT_MALLOC_DEBUG
#    include "private/dbg_mlc.h"
#    define REDIRECT_REALLOC_F(p, lb)                                \
      GC_debug_realloc_inner(p, lb, FALSE, TRUE /* `is_redirect` */, \
                             GC_DBG_EXTRAS)
#    define REDIRECT_REALLOCF_F(p, lb)                               \
      GC_debug_realloc_inner(p, lb, TRUE /* `free_on_fail` */, TRUE, \
                             GC_DBG_EXTRAS)
#  else
#    define REDIRECT_REALLOC_F GC_realloc
#    define REDIRECT_REALLOCF_F GC_reallocf
#  endif

GC_API void *
realloc(void *p, size_t lb)
{
  return REDIRECT_REALLOC_F(p, lb);
}

EXTERN_C_BEGIN
GC_API void *aligned_alloc(size_t align, size_t lb);
GC_API void free_aligned_sized(void *p, size_t align, size_t lb);
GC_API void *reallocf(void *p, size_t lb);
EXTERN_C_END

GC_API void *
reallocf(void *p, size_t lb)
{
  return REDIRECT_REALLOCF_F(p, lb);
}

GC_API void *
aligned_alloc(size_t align, size_t lb)
{
  return GC_memalign(align, lb);
}

GC_API void
free_aligned_sized(void *p, size_t align, size_t lb)
{
  UNUSED_ARG(align);
  UNUSED_ARG(lb);
#  ifdef IGNORE_FREE
  UNUSED_ARG(p);
#  else
  GC_free(p); /*< non-debug */
#  endif
}
#endif

GC_API GC_ATTR_MALLOC void *GC_CALL
GC_generic_malloc_ignore_off_page(size_t lb, int kind)
{
  return GC_generic_malloc_aligned(lb, kind, IGNORE_OFF_PAGE,
                                   0 /* `align_m1` */);
}

GC_API GC_ATTR_MALLOC void *GC_CALL
GC_malloc_ignore_off_page(size_t lb)
{
  return GC_generic_malloc_aligned(lb, NORMAL, IGNORE_OFF_PAGE, 0);
}

GC_API GC_ATTR_MALLOC void *GC_CALL
GC_malloc_atomic_ignore_off_page(size_t lb)
{
  return GC_generic_malloc_aligned(lb, PTRFREE, IGNORE_OFF_PAGE, 0);
}

/*
 * Increment `GC_bytes_allocd` from code that does not have direct access
 * to `GC_arrays`.
 */
void GC_CALL
GC_incr_bytes_allocd(size_t n)
{
  GC_bytes_allocd += n;
}

/* The same as `GC_incr_bytes_allocd` but for `GC_bytes_freed`. */
void GC_CALL
GC_incr_bytes_freed(size_t n)
{
  GC_bytes_freed += n;
}

GC_API size_t GC_CALL
GC_get_expl_freed_bytes_since_gc(void)
{
  return (size_t)GC_bytes_freed;
}

#ifndef GC_TL_REFILL_MAX
#  define GC_TL_REFILL_MAX 1
#endif

/*
 * The hard limit of the number of heap blocks taken by a single refill
 * of a thread-local free list.
 */
#define MAX_TL_REFILL_BLOCKS 32

#if GC_TL_REFILL_MAX < 1 || GC_TL_REFILL_MAX > MAX_TL_REFILL_BLOCKS
#  error Wrong GC_TL_REFILL_MAX value
#endif

/*
 * The maximum number of heap blocks taken by a single refill of
 * a thread-local free list.
 */
STATIC unsigned GC_tl_refill_max = GC_TL_REFILL_MAX;

GC_API void GC_CALL
GC_set_tl_refill_max(unsigned value)
{
  GC_ASSERT(value > 0);
  if (UNLIKELY(0 == value))
    value = 1;
  GC_tl_refill_max
      = value < MAX_TL_REFILL_BLOCKS ? value : MAX_TL_REFILL_BLOCKS;
}

GC_API unsigned GC_CALL
GC_get_tl_refill_max(void)
{
  return GC_tl_refill_max;
}

#ifdef THREAD_LOCAL_ALLOC
/*
 * Return the number of heap blocks the current refill of a thread-local
 * free list (with the given refill state) should take at most, and update
 * the state.  The number is doubled at every refill of the same free list
 * within a collection cycle, starting from one, up to `max_blocks`.
 * Thus the free lists of the rarely used sizes stay short, and a thread
 * does not retain much memory on its free lists after the collection.
 */
static size_t
next_tl_refill_blocks(struct GC_tl_refill_s *state, size_t max_blocks)
{
  unsigned char gc_no = (unsigned char)GC_gc_no;
  size_t n_blocks = 1;

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(max_blocks <= MAX_TL_REFILL_BLOCKS);
  if (state->gc_no == gc_no && state->n_blocks > 0) {
    n_blocks = (size_t)state->n_blocks * 2;
    if (n_blocks > max_blocks)
      n_blocks = max_blocks;
  }
  state->gc_no = gc_no;
  state->n_blocks = (unsigned char)n_blocks;
  return n_blocks;
}
#endif

GC_API void GC_CALL
GC_generic_malloc_many(size_t lb_adjusted, int kind, void **result)
{
  void *op;
  void *p;
  void **opp;
  /* The value of `lb_adjusted` converted to granules. */
  size_t lg;
  word my_bytes_allocd = 0;
  struct obj_kind *ok;
  struct hblk **rlh;
  /* The maximum number of heap blocks to take. */
  size_t n_blocks = 1;
#ifdef THREAD_LOCAL_ALLOC
  size_t max_blocks;
  struct GC_tl_refill_s *refill_state = NULL;
#endif

  if (UNLIKELY(!GC_is_initialized))
    GC_init();
  GC_ASSERT(NONNULL_ARG_NOT_NULL(result));
  GC_ASSERT(lb_adjusted != 0 && (lb_adjusted & (GC_GRANULE_BYTES - 1)) == 0);
  GC_ASSERT(kind < MAXOBJKINDS);
  ok = &GC_obj_kinds[kind];
  /*
   * Multiple objects are allocated in the manual VDB mode too.  Their
   * links need no `GC_dirty` call, since the manual VDB mode marks only
   * with the world stopped: the objects are unmarked (or, if freed
   * explicitly while marked, in a dirty block), the free lists are
   * refilled only when they are empty, a collection marks the
   * thread-local free lists directly, and the blocks handed out while a
   * collection is in progress are dirtied (`GC_WBAR_DIRTY_ALLOC()`).
   */
  if (UNLIKELY(lb_adjusted > MAXOBJBYTES)
      || IS_INDIR_PER_OBJ_DESCR(ok->ok_descriptor)) {
    op = GC_generic_malloc_aligned(lb_adjusted - EXTRA_BYTES, kind,
                                   0 /* `flags` */, 0 /* `align_m1` */);
    if (LIKELY(op != NULL))
      obj_link(op) = NULL;
    *result = op;
#ifndef NO_MANUAL_VDB
    if (GC_manual_vdb && GC_is_heap_ptr(result)) {
      GC_dirty_inner(result);
      REACHABLE_AFTER_DIRTY(op);
    }
#endif
    return;
  }

  lg = BYTES_TO_GRANULES(lb_adjusted);
  if (UNLIKELY(get_have_errors()))
    GC_print_all_errors();
  GC_notify_or_invoke_finalizers();
  GC_DBG_COLLECT_AT_MALLOC(lb_adjusted - EXTRA_BYTES);
#ifdef THREAD_LOCAL_ALLOC
  max_blocks = GC_tl_refill_max;
  if (max_blocks > 1) {
    /*
     * Multiple heap blocks are taken only when refilling a thread-local
     * free list of the current thread.
     */
    refill_state = GC_get_tl_refill_state(result);
  }
#endif

  LOCK();
#ifdef THREAD_LOCAL_ALLOC
  if (refill_state != NULL) {
    n_blocks = next_tl_refill_blocks(refill_state, max_blocks);
    /*
     * The free lists of the sizes this thread no longer allocates would
     * otherwise keep up to `max_blocks` heap blocks each indefinitely.
     */
    GC_drop_stale_tl_free_lists();
  }
#endif
  /* Do our share of marking work (proportional to the blocks taken). */
  if (GC_incremental && !GC_dont_gc) {
    GC_collect_a_little_inner(n_blocks);
  }

  /*
   * First see if we can reclaim a page (or up to `n_blocks` pages)
   * of objects waiting to be reclaimed.
   */
  rlh = ok->ok_reclaim_list;
  if (rlh != NULL) {
    hdr *taken[MAX_TL_REFILL_BLOCKS];

    while (rlh[lg] != NULL) {
      size_t i, n;

      for (n = 0; n < n_blocks; n++) {
        hdr *hhdr;

        if (NULL == rlh[lg])
          break;
        hhdr = HDR(rlh[lg]);
        rlh[lg] = hhdr->hb_next;
        GC_ASSERT(hhdr->hb_sz == lb_adjusted);
        hhdr->hb_last_reclaimed = (unsigned short)GC_gc_no;
        taken[n] = hhdr;
#ifndef NO_MANUAL_VDB
        GC_WBAR_DIRTY_ALLOC(hhdr->hb_block, 1);
#endif
      }
      GC_ASSERT(n > 0);
#ifdef PARALLEL_MARK
      if (GC_parallel) {
        GC_signed_word my_bytes_allocd_tmp
            = (GC_signed_word)AO_load(&GC_bytes_allocd_tmp);
        GC_ASSERT(my_bytes_allocd_tmp >= 0);
        /*
         * We only decrement it while holding the allocator lock.
         * Thus, we cannot accidentally adjust it down in more than
         * one thread simultaneously.
         */
        if (my_bytes_allocd_tmp != 0) {
          (void)AO_fetch_and_add(&GC_bytes_allocd_tmp,
                                 (AO_t)(-my_bytes_allocd_tmp));
          GC_bytes_allocd += (word)my_bytes_allocd_tmp;
        }
        GC_fl_builder_enter();
        UNLOCK();

        op = NULL;
        for (i = 0; i < n; i++) {
          op = GC_reclaim_generic(taken[i]->hb_block, taken[i], lb_adjusted,
                                  ok->ok_init, (ptr_t)op, &my_bytes_allocd);
        }
        if (op != NULL) {
          *result = op;
          (void)AO_fetch_and_add(&GC_bytes_allocd_tmp, (AO_t)my_bytes_allocd);
#  ifdef THREAD_SANITIZER
          GC_fl_builder_leave();
          LOCK();
          GC_bytes_found += (GC_signed_word)my_bytes_allocd;
          UNLOCK();
#  else
          /*
           * The resulting `GC_bytes_found` may be inaccurate (as it is
           * updated also by the holder of the allocator lock).  It is
           * updated before `GC_fl_builder_leave()` so that the update
           * cannot happen after the reset of the value by the collector.
           */
          (void)AO_fetch_and_add((volatile AO_t *)&GC_bytes_found,
                                 (AO_t)my_bytes_allocd);
          GC_fl_builder_leave();
#  endif
          (void)GC_clear_stack(NULL);
          return;
        }

        GC_fl_builder_leave();

        /*
         * The allocator lock is needed for access to the reclaim list.
         * We must decrement `GC_fl_builder_count` before reacquiring
         * the allocator lock.  Hopefully this path is rare.
         */
        LOCK();
        rlh = ok->ok_reclaim_list; /*< reload `rlh` after locking */
        if (UNLIKELY(NULL == rlh))
          break;
        continue;
      }
#endif

      op = NULL;
      for (i = 0; i < n; i++) {
        op = GC_reclaim_generic(taken[i]->hb_block, taken[i], lb_adjusted,
                                ok->ok_init, (ptr_t)op, &my_bytes_allocd);
      }
      if (op != NULL) {
        /* We also reclaimed memory, so we need to adjust that count. */
        GC_bytes_found += (GC_signed_word)my_bytes_allocd;
        GC_bytes_allocd += my_bytes_allocd;
        *result = op;
        UNLOCK();
        (void)GC_clear_stack(NULL);
        return;
      }
    }
  }

  /*
   * Next try to use prefix of global free list if there is one.
   * We do not refill it, but we need to use it up before allocating
   * a new block ourselves.  (The prefix is limited by one block since
   * it is found by a walk holding the allocator lock.)
   */
  opp = &ok->ok_freelist[lg];
  op = *opp;
  if (op != NULL) {
    *opp = NULL;
    my_bytes_allocd = 0;
    for (p = op; p != NULL; p = obj_link(p)) {
#ifndef NO_MANUAL_VDB
      GC_WBAR_DIRTY_ALLOC(p, 1);
#endif
      my_bytes_allocd += lb_adjusted;
      if ((word)my_bytes_allocd >= HBLKSIZE) {
        *opp = obj_link(p);
        obj_link(p) = NULL;
        break;
      }
    }
    GC_bytes_allocd += my_bytes_allocd;

  } else {
    /*
     * Next try to allocate a new block (or up to `n_blocks` blocks)
     * worth of objects of this size.
     */
    struct hblk *hbs[MAX_TL_REFILL_BLOCKS];
    GC_bool clear = ok->ok_init || GC_debugging_started;
    size_t i, n = 0;

    /*
     * The collector clears the free lists, and sweeps the blocks, only of
     * the kinds having the reclaim list, thus allocate the latter before
     * the first block of the kind.
     */
    if (LIKELY(ok->ok_reclaim_list != NULL) || GC_alloc_reclaim_list(ok)) {
      for (; n < n_blocks; n++) {
        struct hblk *h = GC_allochblk(lb_adjusted, kind, 0 /* `flags` */,
                                      0 /* `align_m1` */);

        if (NULL == h)
          break;
        if (IS_UNCOLLECTABLE(kind))
          GC_set_hdr_marks(HDR(h));
#ifndef NO_MANUAL_VDB
        GC_WBAR_DIRTY_ALLOC(h, 1);
#endif
        GC_bytes_allocd += HBLKSIZE - (HBLKSIZE % lb_adjusted);
        hbs[n] = h;
      }
    }

    if (n > 0) {
#ifdef PARALLEL_MARK
      if (GC_parallel) {
        GC_fl_builder_enter();
        UNLOCK();

        op = NULL;
        for (i = 0; i < n; i++) {
          op = GC_build_fl(hbs[i], (ptr_t)op, lg, clear);
        }
        *result = op;
        GC_fl_builder_leave();
        (void)GC_clear_stack(NULL);
        return;
      }
#endif

      op = NULL;
      for (i = 0; i < n; i++) {
        op = GC_build_fl(hbs[i], (ptr_t)op, lg, clear);
      }
    } else {
      /*
       * As a last attempt, try allocating a single object.
       * Note that this may trigger a collection or expand the heap.
       */
      op = GC_generic_malloc_inner(lb_adjusted - EXTRA_BYTES, kind,
                                   0 /* `flags` */);
      if (op != NULL)
        obj_link(op) = NULL;
    }
  }

  *result = op;
  UNLOCK();
  (void)GC_clear_stack(NULL);
}

GC_API GC_ATTR_MALLOC void *GC_CALL
GC_malloc_many(size_t lb)
{
  void *result;
  size_t lg, lb_adjusted;

  if (UNLIKELY(0 == lb))
    lb = 1;
#if MAX_EXTRA_BYTES > 0
  if (UNLIKELY(!GC_is_initialized)) {
    /* `EXTRA_BYTES` value might be changed by `GC_init()`. */
    GC_init();
  }
#endif
  lg = ALLOC_REQUEST_GRANS(lb);
  lb_adjusted = GRANULES_TO_BYTES(lg);
  GC_generic_malloc_many(lb_adjusted, NORMAL, &result);
  return result;
}

/*
 * TODO: The debugging variant of `GC_memalign` and friends is tricky
 * and currently missing.  The major difficulty is: `store_debug_info`
 * should return the pointer of the object with the requested alignment
 * (unlike the object header).
 */

GC_API GC_ATTR_MALLOC void *GC_CALL
GC_memalign(size_t align, size_t lb)
{
  size_t align_m1 = align - 1;

  /* Check the alignment argument. */
  if (UNLIKELY(0 == align || (align & align_m1) != 0))
    return NULL;

  /* TODO: Use thread-local allocation. */
  if (align <= GC_GRANULE_BYTES)
    return GC_malloc(lb);
  return GC_malloc_kind_aligned_global(lb, NORMAL, align_m1);
}

GC_API int GC_CALL
GC_posix_memalign(void **memptr, size_t align, size_t lb)
{
  void *p;

  /* Check alignment properly. */
  if (UNLIKELY(align < sizeof(void *) || ((align - 1) & align) != 0)) {
#ifdef MSWINCE
    return ERROR_INVALID_PARAMETER;
#else
    return EINVAL;
#endif
  }

  p = GC_memalign(align, lb);
  if (UNLIKELY(NULL == p)) {
#ifdef MSWINCE
    return ERROR_NOT_ENOUGH_MEMORY;
#else
    return ENOMEM;
#endif
  }
  *memptr = p;
  return 0; /*< success */
}

#ifndef GC_NO_VALLOC
GC_API GC_ATTR_MALLOC void *GC_CALL
GC_valloc(size_t lb)
{
  if (UNLIKELY(!GC_is_initialized))
    GC_init();
  GC_ASSERT(GC_real_page_size != 0);
  return GC_memalign(GC_real_page_size, lb);
}

GC_API GC_ATTR_MALLOC void *GC_CALL
GC_pvalloc(size_t lb)
{
  if (UNLIKELY(!GC_is_initialized))
    GC_init();
  GC_ASSERT(GC_real_page_size != 0);
  lb = SIZET_SAT_ADD(lb, GC_real_page_size - 1) & ~(GC_real_page_size - 1);
  return GC_memalign(GC_real_page_size, lb);
}
#endif /* !GC_NO_VALLOC */

GC_API GC_ATTR_MALLOC char *GC_CALL
GC_strdup(const char *s)
{
  /*
   * Implementation of a variant of `strdup()` that uses the collector
   * to allocate a copy of the string.
   */
  char *copy;
  size_t lb;
  if (s == NULL)
    return NULL;
  lb = strlen(s) + 1;
  copy = (char *)GC_malloc_atomic(lb);
  if (UNLIKELY(NULL == copy)) {
#ifndef MSWINCE
    errno = ENOMEM;
#endif
    return NULL;
  }
  BCOPY(s, copy, lb);
  return copy;
}

GC_API GC_ATTR_MALLOC char *GC_CALL
GC_strndup(const char *str, size_t size)
{
  char *copy;
  /* Note: `str` is expected to be non-`NULL`. */
  size_t len = strlen(str);
  if (UNLIKELY(len > size))
    len = size;
  copy = (char *)GC_malloc_atomic(len + 1);
  if (UNLIKELY(NULL == copy)) {
#ifndef MSWINCE
    errno = ENOMEM;
#endif
    return NULL;
  }
  if (LIKELY(len > 0))
    BCOPY(str, copy, len);
  copy[len] = '\0';
  return copy;
}

#ifdef GC_REQUIRE_WCSDUP
#  include <wchar.h> /*< for `wcslen()` */

GC_API GC_ATTR_MALLOC wchar_t *GC_CALL
GC_wcsdup(const wchar_t *str)
{
  size_t lb = (wcslen(str) + 1) * sizeof(wchar_t);
  wchar_t *copy = (wchar_t *)GC_malloc_atomic(lb);

  if (UNLIKELY(NULL == copy)) {
#  ifndef MSWINCE
    errno = ENOMEM;
#  endif
    return NULL;
  }
  BCOPY(str, copy, lb);
  return copy;
}

#  if !defined(wcsdup) && defined(REDIRECT_MALLOC) \
      && !defined(REDIRECT_MALLOC_IN_HEADER)
GC_API wchar_t *
wcsdup(const wchar_t *str)
{
  return GC_wcsdup(str);
}
#  endif
#endif /* GC_REQUIRE_WCSDUP */

#ifndef CPPCHECK
GC_API void *GC_CALL
GC_malloc_stubborn(size_t lb)
{
  return GC_malloc(lb);
}

GC_API void GC_CALL
GC_change_stubborn(const void *p)
{
  UNUSED_ARG(p);
}
#endif /* !CPPCHECK */

GC_API void GC_CALL
GC_end_stubborn_change(const void *p)
{
  GC_dirty(p); /*< entire object */
}

GC_API void GC_CALL
GC_ptr_store_and_dirty(void *p, const void *q)
{
  *(const void **)p = q;
  GC_dirty(p);
  REACHABLE_AFTER_DIRTY(q);
}
