/*
 * Copyright (c) 1988-1989 Hans-J. Boehm, Alan J. Demers
 * Copyright (c) 1991-1996 by Xerox Corporation.  All rights reserved.
 * Copyright (c) 1996-1999 by Silicon Graphics.  All rights reserved.
 * Copyright (c) 1999-2011 Hewlett-Packard Development Company, L.P.
 * Copyright (c) 2008-2026 Ivan Maidanski
 *
 * THIS MATERIAL IS PROVIDED AS IS, WITH ABSOLUTELY NO WARRANTY EXPRESSED
 * OR IMPLIED.  ANY USE IS AT YOUR OWN RISK.
 *
 * Permission is hereby granted to use or copy this program
 * for any purpose, provided the above notices are retained on all copies.
 * Permission to modify the code and to distribute modified code is granted,
 * provided the above notices are retained, and a notice that the code was
 * modified is included with the above copyright notice.
 */

#include "private/gc_priv.h"

/*
 * Separate free lists are maintained for different sized objects up
 * to `MAXOBJBYTES`.
 * The call `GC_allocobj(lg, kind)` ensures that the free list for the given
 * kind of objects of the given size in granules is a nonempty one.
 * It returns a pointer to the first entry on the free list.
 * In a single-threaded world, `GC_allocobj` may be called to allocate
 * an object of small size `lb` (and `NORMAL` kind) as follows
 * (`GC_generic_malloc_inner` is a wrapper over `GC_allocobj` which also
 * fills in `GC_size_map` if needed):
 *
 * ```
 *   lg = GC_size_map[lb];
 *   op = GC_objfreelist[lg];
 *   if (NULL == op) {
 *     op = GC_generic_malloc_inner(lb, NORMAL, 0);
 *   } else {
 *     GC_objfreelist[lg] = obj_link(op);
 *     GC_bytes_allocd += GRANULES_TO_BYTES((word)lg);
 *   }
 * ```
 *
 * Note that this is very fast if the free list is not empty; it should
 * only involve the execution of 4 or 5 simple instructions.
 * All composite objects on freelists are cleared, except for
 * their first "pointer-sized" word.
 */

/*
 * The allocator uses `GC_allochblk` to allocate large chunks of objects.
 * These chunks all start on addresses that are multiples of `HBLKSIZE`.
 * Each allocated chunk has an associated header, which can be located
 * quickly based on the address of the chunk.  This makes it possible
 * to check quickly whether an arbitrary address corresponds to an object
 * administered by the allocator.  (See `headers.c` file for details.)
 */

/* Number of bytes not intended to be collected. */
word GC_non_gc_bytes = 0;

word GC_gc_no = 0;

#if !defined(GC_DISABLE_INCREMENTAL) && !defined(NO_MANUAL_VDB)
GC_INNER GC_bool GC_final_mark_due = FALSE;
#elif defined(PARALLEL_MARK_DEADLINE)
static GC_bool GC_final_mark_due = FALSE;
#endif

#ifndef NO_CLOCK

GC_API void GC_CALL
GC_start_performance_measurement(void)
{
  GC_measure_performance = TRUE;
}

GC_API unsigned long GC_CALL
GC_get_full_gc_total_time(void)
{
  return GC_full_gc_total_time;
}

GC_API unsigned long GC_CALL
GC_get_full_gc_total_ns_frac(void)
{
  /* Note: the result type matches the type of `GC_timeval_s.tv_nsec`. */
  return GC_full_gc_total_ns_frac;
}

GC_API unsigned long GC_CALL
GC_get_stopped_mark_total_time(void)
{
  return GC_stopped_mark_total_time;
}

#  ifndef MAX_TOTAL_TIME_DIVISOR
/*
 * We shall not use big values here (so "outdated" delay time values would
 * have less impact on "average" delay time value than newer ones).
 */
#    define MAX_TOTAL_TIME_DIVISOR 1000
#  endif

GC_API unsigned long GC_CALL
GC_get_avg_stopped_mark_time_ns(void)
{
  unsigned long total_time;
  unsigned divisor;

  READER_LOCK();
  total_time = (unsigned long)GC_world_stopped_total_time;
  divisor = GC_world_stopped_total_divisor;
  READER_UNLOCK();
  if (0 == divisor) {
    GC_ASSERT(0 == total_time);
    /*
     * No world-stopped collection has occurred since the start of
     * performance measurements.
     */
    return 0;
  }

  /* Halve values to prevent overflow during the multiplication. */
  for (; total_time > ~0UL / (1000UL * 1000); total_time >>= 1) {
    divisor >>= 1;
    if (UNLIKELY(0 == divisor)) {
      /* The actual result is larger than representable value. */
      return ~0UL;
    }
  }

  return total_time * (1000UL * 1000) / divisor;
}

#endif /* !NO_CLOCK */

GC_API int GC_CALL
GC_is_incremental_mode(void)
{
  return (int)GC_incremental;
}

#ifdef THREADS
int GC_parallel = FALSE; /*< parallel collection is off by default */
#endif

#ifdef GC_FULL_FREQ
int GC_full_freq = GC_FULL_FREQ;
#else
/*
 * Every `GC_full_freq + 1` collection is a full collection, whether we
 * need it or not.
 */
int GC_full_freq = 19;
#endif

GC_INNER int GC_gen_full_live_pct = 50;

/* Bytes in use (marked) after the latest full collection, 0 before one. */
STATIC word GC_in_use_after_full = 0;

#ifdef THREAD_LOCAL_ALLOC
GC_INNER GC_bool GC_world_stopped = FALSE;
#endif

STATIC GC_bool GC_disable_automatic_collection = FALSE;

GC_API void GC_CALL
GC_set_disable_automatic_collection(int value)
{
  LOCK();
  GC_disable_automatic_collection = value != 0;
  UNLOCK();
}

GC_API int GC_CALL
GC_get_disable_automatic_collection(void)
{
  int value;

  READER_LOCK();
  value = (int)GC_disable_automatic_collection;
  READER_UNLOCK();
  return value;
}

/*
 * The version macros are now defined in `gc_version.h` file, which is
 * included by `gc.h` file, which, in turn, is included by `gc_priv.h` file.
 */
#ifndef GC_NO_VERSION_VAR
EXTERN_C_BEGIN
extern const GC_VERSION_VAL_T GC_version;
EXTERN_C_END

const GC_VERSION_VAL_T GC_version = ((GC_VERSION_VAL_T)GC_VERSION_MAJOR << 16)
                                    | (GC_VERSION_MINOR << 8)
                                    | GC_VERSION_MICRO;
#endif

GC_API GC_VERSION_VAL_T GC_CALL
GC_get_version(void)
{
  return ((GC_VERSION_VAL_T)GC_VERSION_MAJOR << 16) | (GC_VERSION_MINOR << 8)
         | GC_VERSION_MICRO;
}

GC_API int GC_CALL
GC_get_dont_add_byte_at_end(void)
{
#if MAX_EXTRA_BYTES > 0
  /* This is meaningful only if `GC_all_interior_pointers`. */
  return 0;
#else
  return 1;
#endif
}

/* Some more variables. */

#ifdef GC_DONT_EXPAND
int GC_dont_expand = TRUE;
#else
int GC_dont_expand = FALSE;
#endif

#ifdef GC_FREE_SPACE_DIVISOR
word GC_free_space_divisor = GC_FREE_SPACE_DIVISOR; /*< must be positive */
#else
word GC_free_space_divisor = 3;
#endif

GC_INNER int GC_CALLBACK
GC_never_stop_func(void)
{
  return FALSE;
}

#ifdef GC_TIME_LIMIT
/*
 * We try to keep pause times from exceeding this by much.
 * In milliseconds.
 */
unsigned long GC_time_limit = GC_TIME_LIMIT;
#elif defined(PARALLEL_MARK)
/*
 * The parallel marker cannot be interrupted for now, so the time limit
 * is absent by default.
 */
unsigned long GC_time_limit = GC_TIME_UNLIMITED;
#else
unsigned long GC_time_limit = 15;
#endif

#ifndef NO_CLOCK
/*
 * The nanoseconds add-on to `GC_time_limit` value.
 * Not updated by `GC_set_time_limit()`.
 * Ignored if the value of `GC_time_limit` is `GC_TIME_UNLIMITED`.
 */
STATIC unsigned long GC_time_lim_nsec = 0;

#  define TV_NSEC_LIMIT (1000UL * 1000) /*< amount of nanoseconds in 1 ms */

GC_API void GC_CALL
GC_set_time_limit_tv(struct GC_timeval_s tv)
{
  GC_ASSERT(tv.tv_ms <= GC_TIME_UNLIMITED);
  GC_ASSERT(tv.tv_nsec < TV_NSEC_LIMIT);
  GC_time_limit = tv.tv_ms;
  GC_time_lim_nsec = tv.tv_nsec;
}

GC_API struct GC_timeval_s GC_CALL
GC_get_time_limit_tv(void)
{
  struct GC_timeval_s tv;

  tv.tv_ms = GC_time_limit;
  tv.tv_nsec = GC_time_lim_nsec;
  return tv;
}
#endif /* !NO_CLOCK */

/* Note: accessed holding the allocator lock. */
STATIC GC_stop_func GC_default_stop_func = GC_never_stop_func;

GC_API void GC_CALL
GC_set_stop_func(GC_stop_func stop_func)
{
  GC_ASSERT(NONNULL_ARG_NOT_NULL(stop_func));
  LOCK();
  GC_default_stop_func = stop_func;
  UNLOCK();
}

GC_API GC_stop_func GC_CALL
GC_get_stop_func(void)
{
  GC_stop_func stop_func;

  READER_LOCK();
  stop_func = GC_default_stop_func;
  READER_UNLOCK();
  return stop_func;
}

#ifdef PARALLEL_MARK_DEADLINE
GC_INNER GC_bool GC_parallel_slices = FALSE;

/*
 * Whether a marking with the time limit marks in parallel world-stopped
 * slices until the deadline.  A client stop function is then called
 * between the parallel mark phases, at least once per time limit.
 */
static GC_bool
parallel_slices_on(void)
{
  return GC_parallel_slices && GC_parallel
         && GC_time_limit != GC_TIME_UNLIMITED;
}

/*
 * Whether the marking between the world-stopped marks of a collection
 * runs in world-stopped steps (`GC_parallel_mark_step()`): with the
 * parallel slices, and always in the manual VDB mode, which marks only
 * with the world stopped (a client write barrier has no fence, and
 * a client fills a new object without a barrier), on one thread if the
 * parallel marker is off.
 */
static GC_bool
steps_on(void)
{
  return GC_manual_vdb || parallel_slices_on();
}

/*
 * The slices (world-stopped marks and steps) of the collection in progress,
 * and their longest and total time in microseconds.  Protected by the
 * allocator lock, as the following.
 */
static unsigned n_slices = 0;
static unsigned long longest_slice_us = 0;
static unsigned long total_slice_us = 0;

/*
 * The bytes allocated (`GC_bytes_allocd` plus `GC_bytes_allocd_tmp`) at
 * the latest slice, and at the latest call of `GC_collect_a_little_inner()`
 * while marking, for pacing the steps.
 */
static word allocd_at_slice = 0;
static word allocd_at_call = 0;

/* The bytes to allocate between two steps of the collection in progress. */
static word slice_bytes = 0;

/* The slices of the latest collection whose marking completed. */
static unsigned prev_n_slices = 0;

/*
 * The inputs of the pacing by the memory headroom (see `collector_share()`):
 * the start of the first slice of the collection in progress and the bytes
 * allocated at its end, the end and the length of its latest slice; the time
 * the world was stopped for the latest minor (index 0) and full (index 1)
 * collection whose marking completed; the length of the final mark that
 * completed the latest collection whose marking did not complete in one stop
 * (0 if its first mark completed it); and the bytes allocated and the time
 * the client ran from the start of the window of the allocation rate (see
 * `rate_start_time`), or from the first slice of the latest collection whose
 * marking completed if the finish before it read no clock, until that
 * marking completed.  Protected by the allocator lock, as the following.
 */
static CLOCK_TYPE mark_start_time;
static word allocd_at_mark_start = 0;
static CLOCK_TYPE slice_end_time;
static unsigned long last_slice_us = 0;
static unsigned long prev_mark_us[2] = { 0, 0 };
static unsigned long prev_final_us = 0;
static word prev_allocd = 0;
static unsigned long prev_client_us = 0;

/*
 * The start of the window of the allocation rate (see `end_slice()`) and
 * the bytes allocated then, and the latest sample of the clock and the
 * bytes allocated then, if `finish_timed`: the clock is read at the finish
 * of a collection only with the steps (see `steps_on()`).  Both are the
 * latest finish, where the bytes allocated restart from 0, until the first
 * sample.  A sample is taken between collections once the client allocated
 * `rate_sample_bytes` (an eighth of the allocation volume) since the previous
 * one, and the window then starts at the previous one.  Thus the window
 * starts one to two eighths of the volume before the collection if the
 * client allocated that much since the finish, and the time the client was
 * idle before that does not count as its time.
 */
static CLOCK_TYPE rate_start_time;
static word allocd_at_rate_start = 0;
static CLOCK_TYPE rate_sample_time;
static word allocd_at_rate_sample = 0;
static word rate_sample_bytes = 0;
static GC_bool finish_timed = FALSE;

/*
 * The longest final mark of the collection in progress that was
 * abandoned, or its time limit if that is longer.
 */
static unsigned long abandoned_final_us = 0;

/*
 * The final marks of the collection in progress that were abandoned at
 * the bound of their time limit (see `final_limit_us()`), and the bytes
 * allocated (see `allocd_now()`) when the latest of them was abandoned.
 */
static unsigned n_final_abandoned_at_bound = 0;
static word allocd_at_bound_abandon = 0;

/* The number of the final mark in progress, 0 if none. */
static unsigned final_mark_no = 0;

/* Whether the final mark in progress runs without a time limit. */
static GC_bool final_mark_unlimited = FALSE;

/*
 * Whether the slice in progress completes the marking of the collection in
 * one stop (see `ONE_STOP_SHARE`).
 */
static GC_bool in_one_stop = FALSE;

/*
 * Whether the caller holds the allocator lock until the marking of the
 * collection in progress completes (see `GC_complete_marking()`).
 */
static GC_bool marking_awaited = FALSE;

static word
allocd_now(void)
{
  return GC_bytes_allocd + (word)AO_load(&GC_bytes_allocd_tmp);
}

/*
 * The microseconds from `start` until now, saturated at `~0UL`.  Where
 * `unsigned long` has 32 bits, they would wrap after 2^32 microseconds
 * (71.6 minutes) otherwise, which may pass while the client is idle.
 */
static unsigned long
us_since(CLOCK_TYPE start)
{
  CLOCK_TYPE now;
  unsigned long ms;

  GET_TIME(now);
  ms = MS_TIME_DIFF(now, start);
  if (ms >= ~0UL / 1000)
    return ~0UL;
  return ms * 1000UL + NS_FRAC_TIME_DIFF(now, start) / 1000UL;
}
#endif

#if defined(GC_DISABLE_INCREMENTAL) || defined(NO_CLOCK)
#  define GC_timeout_stop_func GC_default_stop_func
#else
#  ifdef PARALLEL_MARK_DEADLINE
/*
 * The time limit of the world-stopped mark or step in progress in
 * microseconds, raised by the pacing of the steps (see `step_limit_us()`
 * and `final_limit_us()`); if zero, the time limit is the one of
 * `GC_time_limit` and `GC_time_lim_nsec`.  Protected by the allocator
 * lock.
 */
static unsigned long slice_limit_us = 0;

/*
 * Whether the final mark in progress runs at the bound of its time limit
 * (see `final_limit_us()`), where the stop function of the client does not
 * abandon it.  Protected by the allocator lock.
 */
static GC_bool final_mark_bounded = FALSE;
#  else
/* Without the steps, nothing raises the time limit or bounds it. */
#    define slice_limit_us 0UL
#    define final_mark_bounded FALSE
#  endif

/* The time limit of the world-stopped mark or step in progress. */
static void
current_time_limit(unsigned long *pms, unsigned long *pns)
{
  if (LIKELY(0 == slice_limit_us)) {
    *pms = GC_time_limit;
    *pns = GC_time_lim_nsec;
    return;
  }
  *pms = slice_limit_us / 1000UL;
  *pns = slice_limit_us % 1000UL * 1000UL;
}

/*
 * Whether `GC_timeout_stop_func()` returned `TRUE` at the time limit, after
 * `timeout_stop_ms` milliseconds and `timeout_stop_ns` nanoseconds, and the
 * attempt, for `log_timeout_stop()`, which logs it once the world is
 * restarted: a log line written while the world is stopped may wait for
 * a lock held by a stopped thread (e.g. the locale lock taken by `vsnprintf`
 * on macOS).  Protected by the allocator lock.
 */
static GC_bool timeout_stopped = FALSE;
static unsigned long timeout_stop_ms = 0;
static unsigned long timeout_stop_ns = 0;
static int timeout_stop_attempt = 0;

static void
log_timeout_stop(void)
{
  GC_ASSERT(I_HOLD_LOCK());
  if (timeout_stopped) {
    GC_COND_LOG_PRINTF(
        "Abandoning stopped marking after %lu ms %lu ns (attempt %d)\n",
        timeout_stop_ms, timeout_stop_ns, timeout_stop_attempt);
    timeout_stopped = FALSE;
  }
}

STATIC int GC_CALLBACK
GC_timeout_stop_func(void)
{
  CLOCK_TYPE current_time;
  static unsigned count = 0;
  unsigned long time_diff, nsec_diff, limit_ms, limit_ns;

  GC_ASSERT(I_HOLD_LOCK());
  if (!final_mark_bounded && GC_default_stop_func())
    return TRUE;
#  ifdef PARALLEL_MARK_DEADLINE
  if (GC_mark_deadline_reached())
    return TRUE;
#  endif

  if (GC_time_limit == GC_TIME_UNLIMITED || (count++ & 3) != 0)
    return FALSE;

  GET_TIME(current_time);
  time_diff = MS_TIME_DIFF(current_time, GC_start_time);
  nsec_diff = NS_FRAC_TIME_DIFF(current_time, GC_start_time);
#  if defined(CPPCHECK)
  /* Note: GCC reports a warning if `GC_noop1_ptr()` is used here. */
  GC_noop1(ADDR(&nsec_diff));
#  endif
  current_time_limit(&limit_ms, &limit_ns);
  if (time_diff >= limit_ms
      && (time_diff > limit_ms || nsec_diff >= limit_ns)) {
    timeout_stopped = TRUE;
    timeout_stop_ms = time_diff;
    timeout_stop_ns = nsec_diff;
    timeout_stop_attempt = GC_n_attempts;
    return TRUE;
  }

  return FALSE;
}
#endif /* !GC_DISABLE_INCREMENTAL */

#ifdef THREADS
GC_INNER word GC_total_stacksize = 0;
#endif

/* The lowest value returned by `min_bytes_allocd()`. */
static size_t min_bytes_allocd_minimum = 1;

#ifndef GC_ALLOC_BUDGET_PERCENT
#  define GC_ALLOC_BUDGET_PERCENT 0
#endif

GC_INNER word GC_alloc_budget_percent = GC_ALLOC_BUDGET_PERCENT;

GC_API void GC_CALL
GC_set_alloc_budget_percent(GC_word value)
{
  GC_alloc_budget_percent = value;
}

GC_API GC_word GC_CALL
GC_get_alloc_budget_percent(void)
{
  return GC_alloc_budget_percent;
}

#ifndef GC_MEMORY_LIMIT
#  define GC_MEMORY_LIMIT 0
#endif

/* The memory limit set by the client, 0 if none. */
static word explicit_memory_limit = GC_MEMORY_LIMIT;

/* The memory limit found by `GC_init_memory_limit()`, 0 if unknown. */
static word detected_memory_limit = 0;

/* The smaller one of the two limits above, 0 if both are unknown. */
static word memory_limit = GC_MEMORY_LIMIT;

/* Return the smaller one of `a` and `b`, ignoring a zero one. */
static word
min_known_limit(word a, word b)
{
  return 0 == a || (b != 0 && b < a) ? b : a;
}

GC_API void GC_CALL
GC_set_memory_limit(GC_word value)
{
  explicit_memory_limit = value;
  memory_limit = min_known_limit(detected_memory_limit, value);
}

GC_API GC_word GC_CALL
GC_get_memory_limit(void)
{
  return memory_limit;
}

#ifndef GC_HEAP_CEILING_PERCENT
#  define GC_HEAP_CEILING_PERCENT 75
#endif

/*
 * The heap ceiling as a percentage of the memory limit, 0 for no heap
 * ceiling (thus the heap is not sized by the memory limit).
 */
static word heap_ceiling_percent = GC_HEAP_CEILING_PERCENT;

GC_API void GC_CALL
GC_set_heap_ceiling_percent(GC_word value)
{
  heap_ceiling_percent = value;
}

GC_API GC_word GC_CALL
GC_get_heap_ceiling_percent(void)
{
  return heap_ceiling_percent;
}

GC_INNER void
GC_init_memory_limit(void)
{
  word physical = GC_physical_memory_size();
  word cgroup = 0;

#ifdef LINUX
  cgroup = GC_cgroup_memory_limit("/proc/self/cgroup", "/sys/fs/cgroup");
#endif
  detected_memory_limit = min_known_limit(physical, cgroup);
  memory_limit = min_known_limit(detected_memory_limit, explicit_memory_limit);
  GC_COND_LOG_PRINTF("Memory limit %lu MiB (RAM %lu MiB, cgroup %lu MiB,"
                     " explicit %lu MiB), heap ceiling %lu%%\n",
                     (unsigned long)(memory_limit >> 20),
                     (unsigned long)(physical >> 20),
                     (unsigned long)(cgroup >> 20),
                     (unsigned long)(explicit_memory_limit >> 20),
                     (unsigned long)heap_ceiling_percent);
}

/* Return `v * percent / 100` (approximately), saturated on overflow. */
static word
percent_of(word v, word percent)
{
  word q = v / 100;
  word r = v % 100;
  word result, rest;

  if (q > 0 && percent > GC_WORD_MAX / q)
    return GC_WORD_MAX;
  result = q * percent;
  /* `r` is less than 100, thus the following does not overflow. */
  rest = r * (percent / 100) + r * (percent % 100) / 100;
  return result > GC_WORD_MAX - rest ? GC_WORD_MAX : result + rest;
}

GC_API void GC_CALL
GC_set_min_bytes_allocd(size_t value)
{
  GC_ASSERT(value > 0);
  min_bytes_allocd_minimum = value;
}

GC_API size_t GC_CALL
GC_get_min_bytes_allocd(void)
{
  return min_bytes_allocd_minimum;
}

/* Return the size of the stacks to scan (approximately). */
static word
total_stack_size(void)
{
  word stack_size;

  GC_ASSERT(I_HOLD_LOCK());
#ifdef THREADS
  if (GC_has_running_threads()) {
    /* We are multi-threaded... */
    stack_size = GC_total_stacksize;
    /*
     * For now, we just use the value computed during the latest garbage
     * collection.
     */
#  ifdef DEBUG_THREADS
    GC_log_printf("Total stacks size: %lu\n", (unsigned long)stack_size);
#  endif
  } else
#endif
  /* else */ {
#ifdef STACK_NOT_SCANNED
    stack_size = 0;
#elif defined(STACK_GROWS_UP)
    stack_size = (word)(GC_approx_sp() - GC_stackbottom);
#else
    stack_size = (word)(GC_stackbottom - GC_approx_sp());
#endif
  }
  return stack_size;
}

/*
 * Return the number of bytes in the objects found live by the latest
 * collection (both traced and "atomic" ones) plus the size of the roots
 * (including the stacks).
 */
static word
live_bytes(void)
{
  return GC_composite_in_use + GC_atomic_in_use + total_stack_size()
         + GC_root_size;
}

/*
 * If the heap is sized by the memory limit, then the allocation volume
 * between collections is at most this percentage of the distance from
 * the live data to the heap ceiling, thus the heap target covers this
 * percentage of that distance as the live data approaches the ceiling...
 */
#define ROOM_SHARE_PERCENT 50

/*
 * ...but that bound is not less than this percentage of the live data.
 * The heap growth is at least this percentage of the live data too.
 */
#define BUDGET_FLOOR_PERCENT 10

/*
 * Return the heap ceiling in bytes (the percentage of the memory limit),
 * 0 if the memory limit is unknown or the percentage is 0.
 */
static word
heap_ceiling(void)
{
  return percent_of(memory_limit, heap_ceiling_percent);
}

/*
 * Return the minimum number of bytes that must be allocated between
 * collections to amortize the cost of the latter.  Should be nonzero.
 */
static word
min_bytes_allocd(void)
{
  word result;

  GC_ASSERT(I_HOLD_LOCK());
  if (GC_alloc_budget_percent != 0) {
    /*
     * The volume is proportional to the size of the data live at the
     * latest collection (including the roots), independently of how
     * expensive the data is to trace.
     */
    word live = live_bytes();
    word ceiling = heap_ceiling();

    result = percent_of(live, GC_alloc_budget_percent);
    if (ceiling != 0) {
      word room = ceiling > live
                      ? percent_of(ceiling - live, ROOM_SHARE_PERCENT)
                      : 0;
      word min_volume = percent_of(live, BUDGET_FLOOR_PERCENT);

      if (room < min_volume)
        room = min_volume;
      if (result > room)
        result = room;
    }
  } else {
    word stack_size = total_stack_size();
    /*
     * Total size of roots, it includes double stack size, since the stack
     * is expensive to scan.
     */
    word total_root_size = 2 * stack_size + GC_root_size;
    /* Estimate of memory to be scanned during normal collection. */
    word scan_size
        = 2 * GC_composite_in_use + GC_atomic_in_use / 4 + total_root_size;

    result = scan_size / GC_free_space_divisor;
  }
  if (GC_incremental) {
    result /= 2;
  }
  return result > min_bytes_allocd_minimum ? result : min_bytes_allocd_minimum;
}

/*
 * Return the heap size which the heap is grown to at once and not grown
 * beyond (unless a collection does not free enough): the size of the
 * live data plus the allocation volume between collections, if the heap
 * is sized by the memory limit.  Otherwise return 0, also if a shortage
 * of blocks cannot trigger a collection, i.e. if the collections are
 * disabled or in the incremental mode (thus the heap cannot be kept at
 * the target, and the size of the live data counts the objects allocated
 * during the incremental marking).
 */
static word
heap_target(void)
{
  if (0 == GC_alloc_budget_percent || 0 == heap_ceiling() || GC_dont_gc
      || GC_disable_automatic_collection || GC_incremental)
    return 0;
  return SIZET_SAT_ADD(live_bytes(), min_bytes_allocd());
}

/*
 * Return the heap cap: the data live after the latest full collection
 * (including the roots) plus the larger one of `BUDGET_FLOOR_PERCENT` of it
 * and `ROOM_SHARE_PERCENT` of the distance from it to the heap ceiling, but
 * at most the allocation budget percentage of it if there is a budget.
 * With a budget, this is the heap that the memory-aware sizing of the
 * allocation volume (see `min_bytes_allocd()`, before the incremental mode
 * halves it) gives that data.  Without a budget the heap is not sized by the
 * memory limit, but the cap is computed as well.  Return 0 if the memory limit
 * is unknown or the heap ceiling percentage is 0 (thus `heap_ceiling()` is 0).
 */
static word
heap_cap(void)
{
  word ceiling = heap_ceiling();
  word live, room, min_room;

  if (0 == ceiling)
    return 0;
  live = GC_in_use_after_full != 0
             ? SIZET_SAT_ADD(GC_in_use_after_full,
                             SIZET_SAT_ADD(total_stack_size(), GC_root_size))
             : live_bytes();
  room = ceiling > live ? percent_of(ceiling - live, ROOM_SHARE_PERCENT) : 0;
  min_room = percent_of(live, BUDGET_FLOOR_PERCENT);
  if (room < min_room)
    room = min_room;
  if (GC_alloc_budget_percent != 0) {
    word volume = percent_of(live, GC_alloc_budget_percent);

    if (room > volume)
      room = volume;
  }
  return SIZET_SAT_ADD(live, room);
}

/*
 * Return the number of bytes allocated, adjusted for explicit storage
 * management, etc.  This number is used in deciding when to trigger
 * collections.
 */
STATIC word
GC_adj_bytes_allocd(void)
{
  GC_signed_word result;
  GC_signed_word expl_managed = (GC_signed_word)GC_non_gc_bytes
                                - (GC_signed_word)GC_non_gc_bytes_at_gc;

  /*
   * Do not count what was explicitly freed, or newly allocated for
   * explicit management.  Note that deallocating an explicitly managed
   * object should not alter result, assuming the client is playing by
   * the rules.
   */
  result = (GC_signed_word)GC_bytes_allocd + (GC_signed_word)GC_bytes_dropped
           - (GC_signed_word)GC_bytes_freed
           + (GC_signed_word)GC_finalizer_bytes_freed - expl_managed;
  if (result > (GC_signed_word)GC_bytes_allocd) {
    /* Probably a client bug or unfortunate scheduling. */
    result = (GC_signed_word)GC_bytes_allocd;
  }
  /*
   * We count objects enqueued for finalization as though they had been
   * reallocated this round.  Finalization is visible to user.
   * And if we do not count this, we have stability problems for programs
   * that finalize all objects.
   */
  result += (GC_signed_word)GC_bytes_finalized;
  if (result < (GC_signed_word)(GC_bytes_allocd >> 3)) {
    /*
     * Always count at least 1/8 of the allocations.  We do not want to
     * collect too infrequently, since that would inhibit coalescing of
     * free storage blocks.  This also makes us partially robust against
     * client bugs.
     */
    result = (GC_signed_word)(GC_bytes_allocd >> 3);
  }
  return (word)result;
}

/*
 * Clear up a few frames worth of garbage left at the top of the stack.
 * This is used to prevent us from accidentally treating garbage left
 * on the stack by other parts of the collector as roots.
 * This differs from the code in `misc.c` file, which actually tries
 * to keep the stack clear of long-lived, client-generated garbage.
 */
STATIC void
GC_clear_a_few_frames(void)
{
#ifndef CLEAR_STACK_NPTRS
#  define CLEAR_STACK_NPTRS 64 /*< pointers */
#endif
  volatile ptr_t frames[CLEAR_STACK_NPTRS];

  BZERO(CAST_AWAY_VOLATILE_PVOID(frames), sizeof(frames));
}

GC_API void GC_CALL
GC_start_incremental_collection(void)
{
#ifndef GC_DISABLE_INCREMENTAL
  LOCK();
  if (GC_incremental) {
    GC_should_start_incremental_collection = TRUE;
    if (!GC_dont_gc) {
      GC_collect_a_little_inner(1);
    }
  }
  UNLOCK();
#endif
}

GC_INNER GC_bool
GC_should_collect(void)
{
  static word last_min_bytes_allocd, last_gc_no;

  GC_ASSERT(I_HOLD_LOCK());
  if (last_gc_no != GC_gc_no) {
    last_min_bytes_allocd = min_bytes_allocd();
#ifdef PARALLEL_MARK_DEADLINE
    /* The spacing of the samples of the clock (see `rate_start_time`). */
    rate_sample_bytes = last_min_bytes_allocd / 8;
#endif
    last_gc_no = GC_gc_no;
  }
#ifndef GC_DISABLE_INCREMENTAL
  if (GC_should_start_incremental_collection) {
    GC_should_start_incremental_collection = FALSE;
    return TRUE;
  }
#endif
  if (GC_disable_automatic_collection)
    return FALSE;

  if (GC_last_heap_growth_gc_no == GC_gc_no) {
    /* Avoid expanding past limits used by black-listing. */
    return TRUE;
  }

  return GC_adj_bytes_allocd() >= last_min_bytes_allocd;
}

/*
 * Called at start of full collections.  Not called if zero.
 * Called with the allocator lock held.  Not used by the collector itself.
 */
/* `STATIC` */ GC_start_callback_proc GC_start_call_back = 0;

GC_API void GC_CALL
GC_set_start_callback(GC_start_callback_proc fn)
{
  LOCK();
  GC_start_call_back = fn;
  UNLOCK();
}

GC_API GC_start_callback_proc GC_CALL
GC_get_start_callback(void)
{
  GC_start_callback_proc fn;

  READER_LOCK();
  fn = GC_start_call_back;
  READER_UNLOCK();
  return fn;
}

GC_INLINE void
GC_notify_full_gc(void)
{
  if (GC_start_call_back != 0) {
    (*GC_start_call_back)();
  }
}

STATIC GC_bool GC_stopped_mark(GC_stop_func stop_func);
#ifdef PARALLEL_MARK_DEADLINE
STATIC GC_bool GC_parallel_mark_step(GC_bool unlimited);
#endif
STATIC void GC_finish_collection(void);
static void finish_rest(GC_bool full);

#if defined(GC_ASSERTIONS) && defined(THREAD_LOCAL_ALLOC)
void GC_check_tls(void);
#endif

/*
 * Start the marking of the collection in progress with a world-stopped
 * mark, and finish the collection if the marking completes.  If we run
 * out of time, then this turns into an incremental marking.  The time
 * limit counts from `GC_start_time`.
 */
static void
start_mark(void)
{
  /* Allow parallel marking without a timeout or custom stop function. */
  if (GC_stopped_mark(GC_time_limit == GC_TIME_UNLIMITED
                              && GC_default_stop_func == GC_never_stop_func
                          ? GC_never_stop_func
                          : GC_timeout_stop_func)) {
    SAVE_CALLERS_TO_LAST_STACK();
    GC_finish_collection();
  } else if (!GC_is_full_gc) {
    /* Count this as the first attempt. */
    GC_n_attempts++;
  }
}

#ifdef USE_MUNMAP
/* Whether the free blocks old enough are unmapped after a collection. */
#  define UNMAP_ON()                                            \
    (GC_unmap_threshold > 0    /*< memory unmapping enabled? */ \
     && LIKELY(GC_gc_no != 1)) /*< do not unmap during `GC_init` */

/*
 * The age of a free block for the unmapping after a collection counts full
 * collections: a block is old enough once `GC_unmap_threshold` full
 * collections (`MAX_UNMAP_HISTORY` at most) have completed since it was
 * freed, and at least `GC_unmap_threshold` collections in all.  The unmapping
 * also keeps mapped the most bytes in use in heap blocks (the heap size minus
 * the free blocks) at the end of the marking of any collection since the full
 * collection before the oldest one counted.  Thus memory that the client
 * needs again between two full collections (after many minor ones in the
 * generational mode) is not returned to the system and mapped again
 * meanwhile.  When every collection is full, a block is old enough after
 * `GC_unmap_threshold` collections.  The memory kept mapped can then keep
 * a block old enough mapped only after `GC_merge_unmapped()` has unmapped
 * memory in use at a counted collection, and for at most
 * min(`GC_unmap_threshold`, `MAX_UNMAP_HISTORY`) - 1 collections.
 * `GC_gcollect_and_unmap()` (and `GC_force_unmap_on_gcollect`) unmaps every
 * free block freed before its collection (`unmap_all`), and the unmapping
 * before a heap growth (`unmap_before_growth()`) counts no age and keeps
 * nothing mapped.  Below: the collection numbers of the latest
 * `MAX_UNMAP_HISTORY` full collections, most recent first, and for each of
 * them the most bytes in use at the end of the marking of a collection since
 * the full collection before it; the number of entries; the most bytes in use
 * at the end of the marking of a collection since the latest full collection;
 * whether every free block freed before the collection is unmapped.
 * Protected by the allocator lock.
 */
#  define MAX_UNMAP_HISTORY 16
static word full_gc_nos[MAX_UNMAP_HISTORY];
static word full_peaks[MAX_UNMAP_HISTORY];
static unsigned n_full_history = 0;
static word peak_since_full = 0;
static GC_bool unmap_all = FALSE;

/*
 * Note the bytes in use in heap blocks at the end of the marking of the
 * collection numbered `GC_gc_no`, and, if `full`, its number and the most
 * such bytes since the full collection before it.
 */
static void
note_heap_need(GC_bool full)
{
  word in_use = GC_heapsize - GC_large_free_bytes;
  unsigned i;

  GC_ASSERT(I_HOLD_LOCK());
  if (in_use > peak_since_full)
    peak_since_full = in_use;
  if (!full)
    return;
  for (i = MAX_UNMAP_HISTORY - 1; i > 0; i--) {
    full_gc_nos[i] = full_gc_nos[i - 1];
    full_peaks[i] = full_peaks[i - 1];
  }
  full_gc_nos[0] = GC_gc_no;
  full_peaks[0] = peak_since_full;
  peak_since_full = 0;
  if (n_full_history < MAX_UNMAP_HISTORY)
    n_full_history++;
}

#  ifndef GC_NO_DEINIT
GC_INNER void
GC_reset_unmap_history(void)
{
  BZERO(full_gc_nos, sizeof(full_gc_nos));
  BZERO(full_peaks, sizeof(full_peaks));
  n_full_history = 0;
  peak_since_full = 0;
}
#  endif

/*
 * Unmap the free blocks old enough (see `GC_unmap_old()` and above) from
 * the free list `*pindex` on, until `stop_func` returns true.  Return
 * whether each of them is unmapped, or kept mapped since the mapped part of
 * the heap would get smaller than the memory kept mapped.
 */
static GC_bool
unmap_old_blocks(size_t *pindex, GC_stop_func stop_func)
{
  unsigned threshold = GC_unmap_threshold;
  word keep = 0;

  GC_ASSERT(threshold > 0);
  if (!unmap_all) {
    unsigned n_full
        = threshold < MAX_UNMAP_HISTORY ? threshold : MAX_UNMAP_HISTORY;
    word age;
    unsigned i;

    /* Nothing is old enough before so many full collections. */
    if (n_full > n_full_history)
      return TRUE;
    /*
     * A block freed by a collection numbered below that of the oldest
     * full collection counted has been free for `n_full` full ones.  The
     * collection number of a free block is kept in 16 bits
     * (`hb_last_reclaimed`), thus nothing is unmapped while more than
     * 0xffff collections lie between the oldest full one counted and the
     * current one, both included: the comparison modulo 0x10000 would also
     * take blocks freed after the oldest one.
     */
    age = GC_gc_no - full_gc_nos[n_full - 1] + 1;
    if (age > 0xffff)
      return TRUE;
    if (age < threshold)
      age = threshold;
    threshold = age < 0xffff ? (unsigned)age : 0xffff;
    keep = peak_since_full;
    for (i = 0; i < n_full; i++) {
      if (full_peaks[i] > keep)
        keep = full_peaks[i];
    }
  }
  return GC_unmap_old(threshold, keep, pindex, stop_func);
}
#endif

#ifdef PARALLEL_MARK_DEADLINE
static word steps_room(void);

/*
 * Set the allocation volume after which the next step, or the next chunk
 * of the set-up of a full collection, is due: the allocation budget
 * divided by twice the slices of the previous collection (by 8 at least),
 * so that a marking of as many slices completes within half the budget,
 * unless the spacing of the slices (see `slice_gap_passed()`) holds the
 * steps back: where the client allocates the volume in less time than the
 * spacing, the spacing decides when the steps run, and the client allocates
 * more than half the budget during such a marking.  After a slice, at most
 * the headroom of one step (see `steps_room()`).  Neither the volume nor
 * the spacing holds a step back while a caller holds the allocator lock
 * until the marking completes (see `GC_complete_marking()`), or, from
 * `ONE_STOP_SHARE` on, in one stop.
 */
static void
pace_next_slice(void)
{
  allocd_at_slice = allocd_now();
  slice_bytes
      = min_bytes_allocd() / (prev_n_slices > 4 ? 2 * (word)prev_n_slices : 8);
  if (n_slices > 0) {
    word room = steps_room();

    if (room < slice_bytes)
      slice_bytes = room;
  }
}

/*
 * The set-up of a full collection: the blocks left unswept since the
 * previous collection are swept or dropped (see `GC_reclaim_all()`), as
 * the sweep reads the mark bits, then the mark bits of every block are
 * cleared.  With world-stopped steps (see `steps_on()`) and a time limit,
 * the set-up runs in chunks, each holding the allocator lock for at most
 * the time limit, due after the allocation volume between two steps, and
 * at the latest the time limit after the end of the previous chunk (a call of
 * `GC_collect_a_little_inner()` with nothing allocated since the previous one
 * makes a step due, not a chunk).  If the time limit is set to
 * `GC_TIME_UNLIMITED` meanwhile, the next chunk is due at once.  The phases:
 *   - `SETUP_SWEEP`: the blocks of the reclaim lists are swept, also by
 *     the allocator, as the mark bits are still those of the previous
 *     collection;
 *   - `SETUP_CLEAR`: the reclaim lists are empty, thus nothing reads the
 *     mark bits until the marking starts; they are cleared in the
 *     ascending order of the block addresses from `clear_next` (a block
 *     allocated meanwhile gets clear mark bits from the allocator);
 *   - `SETUP_MARK`: the first world-stopped mark of the collection is due.
 * The marker state stays `MS_NONE` until then, and allocation needs no
 * dirty bits, since the first mark of a full collection clears them.
 * Protected by the allocator lock.
 */
#  define SETUP_NONE 0
#  define SETUP_SWEEP 1
#  define SETUP_CLEAR 2
#  define SETUP_MARK 3
static int setup_phase = SETUP_NONE;

/* In the `SETUP_CLEAR` phase, the first block not cleared yet. */
static struct hblk *clear_next = NULL;

/* The end of the latest chunk of the set-up. */
static CLOCK_TYPE setup_chunk_end;

/*
 * The calls of `setup_stop_func()` in the chunk in progress.  It reads the
 * clock at every 4th call, but not before the `SETUP_MIN_CALLS`-th one,
 * so that every chunk makes some progress.
 */
static unsigned setup_stop_calls = 0;
#  define SETUP_MIN_CALLS 4

#  define SETUP_PENDING() (setup_phase != SETUP_NONE)

/* The time limit, in microseconds. */
static unsigned long
time_limit_us(void)
{
  return GC_time_limit * 1000UL + GC_time_lim_nsec / 1000UL;
}

/*
 * The length of the latest slice for the pacing of the slices (see
 * `steps_room()` and `slice_gap_passed()`), in microseconds.  A slice
 * measured as 0 us ended before the clock of the collector advanced by
 * a microsecond: where the clock counts milliseconds (with `GetTickCount64()`
 * or `GetTickCount()` on Windows) or reads the user time of the process
 * (with `BSD_TIME`), a slice that ends before the next tick reads so,
 * however long it ran.  It counts as long as the time limit, the length of
 * a step that ends at it, instead of leaving no room and no gap before the
 * next slice.  Without a time limit, it counts as 0.
 */
static unsigned long
paced_slice_us(void)
{
  if (last_slice_us != 0 || GC_TIME_UNLIMITED == GC_time_limit)
    return last_slice_us;
  return time_limit_us();
}

/*
 * The pacing of the steps by the memory headroom: the marking of
 * a collection must complete before the bytes in use reach the heap cap
 * (see `heap_cap()`).  The share of the time for which the world must be
 * stopped meanwhile (see `collector_share()`), in per mille, sets the
 * spacing of the slices (see `slice_gap_passed()`) and the time limits of
 * the steps and of the final marks (see `step_limit_us()` and
 * `final_limit_us()`).  From `ONE_STOP_SHARE` on, the marking completes in
 * one stop: in one hold of the allocator lock, at most a step and the final
 * mark run without a time limit, each stopping the world, and the finish
 * but its unmapping follows.
 */
#  define HALF_SHARE 500
#  define ONE_STOP_SHARE 900
#  define MAX_SLICE_LIMITS 4

/*
 * The final marks of a collection abandoned at the bound of their time
 * limit before one runs without it (see `final_limit_us()`).
 */
#  ifndef MAX_ABANDONED_AT_BOUND
#    define MAX_ABANDONED_AT_BOUND 4
#  endif

/*
 * Return `a * b / c`, rounded down and saturated.  If `a * b` overflows,
 * this is `q * b` plus `r * b / c`, where `q` and `r` are the quotient and
 * the remainder of `a / c`.  The latter is less than `b` and is computed
 * without overflow, bit by bit of `b` from the highest one: `t` and `rem`
 * are the quotient and the remainder of `r` times the bits of `b` from the
 * highest one down to `bit` divided by `c`.  As `rem` and `r` are less
 * than `c`, doubling `rem` or adding `r` to it gives less than twice `c`,
 * and subtracting `c` once brings it below `c` again.
 */
static word
scale_word(word a, word b, word c)
{
  word q, r, bit, t, rem;

  GC_ASSERT(c > 0);
  if (0 == b || a <= GC_WORD_MAX / b)
    return a * b / c;
  q = a / c;
  if (q > GC_WORD_MAX / b)
    return GC_WORD_MAX;
  r = a % c;
  t = 0;
  rem = 0;
  bit = 1;
  while (bit <= b / 2)
    bit <<= 1;
  for (; bit != 0; bit >>= 1) {
    t <<= 1;
    if (rem >= c - rem) {
      rem -= c - rem;
      t++;
    } else {
      rem += rem;
    }
    if ((b & bit) != 0) {
      if (rem >= c - r) {
        rem -= c - r;
        t++;
      } else {
        rem += r;
      }
    }
  }
  q *= b;
  return q > GC_WORD_MAX - t ? GC_WORD_MAX : q + t;
}

/*
 * Return the world-stopped time, in microseconds, that the marking of
 * a collection of the kind `kind` (minor 0, full 1) takes after
 * `stopped_us` microseconds of it: what the latest collection of that kind
 * took minus that, but at least the time limit, the final mark that
 * completed the previous collection, and the longest final mark of the
 * collection in progress that was abandoned.
 */
static unsigned long
marking_left_us(int kind, unsigned long stopped_us)
{
  unsigned long left
      = prev_mark_us[kind] > stopped_us ? prev_mark_us[kind] - stopped_us : 0;

  if (left < prev_final_us)
    left = prev_final_us;
  if (left < abandoned_final_us)
    left = abandoned_final_us;
  if (left < time_limit_us())
    left = time_limit_us();
  return left;
}

/*
 * Return the bytes the client allocates in `us` microseconds of its time,
 * at its allocation rate: the bytes allocated per microsecond the client
 * ran since the first slice of the collection in progress, or in the window
 * of the allocation rate of the previous collection whose marking completed
 * (see `prev_allocd`) if the client ran for less than the time limit since.
 * Return 0 if the rate is unknown.
 */
static word
client_allocd_in(unsigned long us)
{
  word allocd = 0;
  unsigned long client_us = 0;

  if (n_slices > 0) {
    unsigned long wall_us = us_since(mark_start_time);

    if (allocd_now() > allocd_at_mark_start)
      allocd = allocd_now() - allocd_at_mark_start;
    client_us = wall_us > total_slice_us ? wall_us - total_slice_us : 0;
  }
  if (client_us < time_limit_us()) {
    allocd = prev_allocd;
    client_us = prev_client_us;
  }
  if (0 == client_us)
    return 0;
  return scale_word(allocd, us, client_us);
}

/*
 * Return the share of the time for which the world must be stopped from
 * now on so that the marking of the collection in progress completes
 * before the bytes in use reach the heap cap: need / (need + headroom).
 * The headroom is the heap cap minus the bytes in use (the data in use
 * after the latest collection plus the bytes allocated since).  `need` is
 * what the client allocates (see `client_allocd_in()`) in its share of the
 * time while the marking left (see `marking_left_us()`) stops the world.
 * The share is 0 if the heap cap is 0 (see `heap_cap()`) or the rate is
 * unknown, and 1000 if the bytes in use reach the heap cap.
 */
static unsigned
collector_share(void)
{
  word cap = heap_cap();
  word in_use, headroom, need;

  GC_ASSERT(I_HOLD_LOCK());
  if (0 == cap)
    return 0;
  in_use = SIZET_SAT_ADD(live_bytes(), allocd_now());
  if (in_use >= cap)
    return 1000;
  headroom = cap - in_use;
  need = client_allocd_in(
      marking_left_us(GC_is_full_gc ? 1 : 0, total_slice_us));
  if (0 == need)
    return 0;
  return (unsigned)scale_word(need, 1000, SIZET_SAT_ADD(need, headroom));
}

/*
 * Return the bytes the client may allocate between two slices of the
 * collection in progress: the headroom beyond the need of the marking
 * left (see `collector_share()`) divided by the slices left, i.e. by the
 * marking left divided by the length of the latest slice (see
 * `paced_slice_us()`, at most the time limit, if a microsecond or more,
 * after a final mark, as the slices left are steps), so that the marking
 * completes with the need as the headroom.  From a share of half on this is
 * 0, and only the spacing by the share delays a step.  Return `GC_WORD_MAX`
 * if the heap cap is 0, the time is unlimited, or no marking is left by that
 * estimate (with a time limit under a microsecond).
 */
static word
steps_room(void)
{
  word cap = heap_cap();
  word reserve;
  unsigned long left, slice_us = paced_slice_us();

  if (0 == cap || GC_TIME_UNLIMITED == GC_time_limit)
    return GC_WORD_MAX;
  left = marking_left_us(GC_is_full_gc ? 1 : 0, total_slice_us);
  if (0 == left)
    return GC_WORD_MAX;
  reserve = SIZET_SAT_ADD(SIZET_SAT_ADD(live_bytes(), allocd_now()),
                          client_allocd_in(left));
  if (reserve >= cap)
    return 0;
  if (final_mark_no != 0 && slice_us > time_limit_us() && time_limit_us() > 0)
    slice_us = time_limit_us();
  return scale_word(cap - reserve, slice_us, left);
}

/*
 * Return the time limit of a step at the share `share`, in microseconds:
 * the time limit up to a share of half, then rising linearly to
 * `MAX_SLICE_LIMITS` times it at `ONE_STOP_SHARE`, so that the world is
 * stopped for more of the time in fewer stops.
 */
static unsigned long
step_limit_us(unsigned share)
{
  word limit = time_limit_us();

  if (share <= HALF_SHARE)
    return (unsigned long)limit;
  if (share >= ONE_STOP_SHARE)
    share = ONE_STOP_SHARE;
  return (unsigned long)(limit
                         + scale_word((MAX_SLICE_LIMITS - 1) * limit,
                                      share - HALF_SHARE,
                                      ONE_STOP_SHARE - HALF_SHARE));
}

/*
 * Return the time limit of a final mark at the share `share`, in
 * microseconds, or 0 if it runs without a time limit.  The final mark
 * needs 1.25 times what the final mark that completed the previous
 * collection took, and twice the longest final mark of the collection in
 * progress that was abandoned (or its time limit, if longer, so that the
 * need doubles whatever stopped it, e.g. the stop function of the
 * client).  The limit is the larger one of that need and the limit of
 * a step, but at most `MAX_SLICE_LIMITS` times the time limit (the bound),
 * where the stop function of the client does not stop the final mark.
 * One abandoned at the bound is tried again at it after more steps, until
 * `MAX_ABANDONED_AT_BOUND` final marks of the collection were abandoned
 * there, after which a final mark that needs more than the bound runs
 * without a time limit.  So does one without the steps.  So does one while
 * a caller waits for the marking with the allocator lock held, and one
 * with nothing allocated since the latest final mark abandoned at the
 * bound (e.g. in a loop of `GC_collect_a_little()` calls): the bytes in
 * use do not grow then, thus the share does not rise and a retry has no
 * more room than the one before.
 */
static unsigned long
final_limit_us(unsigned share)
{
  unsigned long limit = step_limit_us(share);
  unsigned long need = prev_final_us + prev_final_us / 4;
  unsigned long bound = MAX_SLICE_LIMITS * time_limit_us();

  /*
   * The need saturates at `~0UL`.  Where `unsigned long` has 32 bits,
   * twice a final mark abandoned after more than 2^31 microseconds (e.g.
   * at the bound of a time limit over 537 seconds) would wrap otherwise,
   * possibly below the bound, and the final marks would then not stop at
   * `MAX_ABANDONED_AT_BOUND` abandoned there.  1.25 times a final mark of
   * more than 3436 seconds would wrap too, and a final mark that needs
   * more than the bound could then run below it.  So for every time limit
   * below `GC_TIME_UNLIMITED`, a collection takes at most two final marks
   * abandoned below the bound, as each at least doubles the need from the
   * time limit on, then at most `MAX_ABANDONED_AT_BOUND` at the bound and
   * one without a time limit, seven with the default
   * `MAX_ABANDONED_AT_BOUND`.
   */
  if (need < prev_final_us || abandoned_final_us > ~0UL / 2)
    need = ~0UL;
  else if (need < 2 * abandoned_final_us)
    need = 2 * abandoned_final_us;
  if (need <= limit)
    return limit;
  if (need <= bound)
    return need;
  if (!steps_on() || marking_awaited
      || n_final_abandoned_at_bound >= MAX_ABANDONED_AT_BOUND
      || (n_final_abandoned_at_bound > 0
          && allocd_now() == allocd_at_bound_abandon))
    return 0;
  return bound;
}

/*
 * Count the final mark in progress, which was abandoned after `us`
 * microseconds, in `abandoned_final_us`: its time limit if that is longer.
 */
static void
raise_abandoned_final(unsigned long us)
{
  unsigned long limit = slice_limit_us != 0 ? slice_limit_us : time_limit_us();

  if (limit < us)
    limit = us;
  if (limit > abandoned_final_us)
    abandoned_final_us = limit;
}

/*
 * Return whether the slice of the share `share` may start: whether the
 * world was stopped for at most that share of the time since the start of
 * the latest slice (of the length of `paced_slice_us()`), or for at most
 * half of it while the share is below half.  The client thus keeps at
 * least half of the time while the heap can still grow toward the cap,
 * and less as the bytes in use approach it.
 */
static GC_bool
slice_gap_passed(unsigned share)
{
  word gap;

  if (share < HALF_SHARE)
    share = HALF_SHARE;
  if (share >= 1000)
    return TRUE;
  gap = scale_word(paced_slice_us(), 1000 - share, share);
  return us_since(slice_end_time) >= gap;
}

/*
 * The stop function of the chunks of the set-up: true once the time limit
 * has passed since `GC_start_time`.
 */
static int GC_CALLBACK
setup_stop_func(void)
{
  CLOCK_TYPE now;
  unsigned long ms, ns;

  if (++setup_stop_calls < SETUP_MIN_CALLS || (setup_stop_calls & 3) != 0)
    return FALSE;
  GET_TIME(now);
  ms = MS_TIME_DIFF(now, GC_start_time);
  ns = NS_FRAC_TIME_DIFF(now, GC_start_time);
  return ms > GC_time_limit || (ms == GC_time_limit && ns >= GC_time_lim_nsec);
}

#  ifdef USE_MUNMAP
/* The start of the unmapping in progress, for `unmap_stop_func()`. */
static CLOCK_TYPE unmap_start_time;

/*
 * The stop function of a bounded unmapping: true once the time limit has
 * passed since `unmap_start_time`.  It is called after each call of
 * `GC_unmap()`, which costs much more than reading the clock.
 */
static int GC_CALLBACK
unmap_stop_func(void)
{
  return us_since(unmap_start_time) >= time_limit_us();
}
#  endif

/*
 * Run a chunk of the pending set-up, from `GC_start_time` until the time
 * limit.  Return whether the set-up is complete.
 */
static GC_bool
run_setup_chunk(void)
{
  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(SETUP_SWEEP == setup_phase || SETUP_CLEAR == setup_phase);
  setup_stop_calls = 0;
  ENTER_GC();
  if (SETUP_SWEEP == setup_phase && GC_reclaim_all(setup_stop_func, TRUE)) {
#  ifdef PARALLEL_MARK
    /*
     * Builders of free lists sweep the blocks they took from the reclaim
     * lists outside the lock.
     */
    if (GC_parallel)
      GC_wait_for_reclaim();
#  endif
    setup_phase = SETUP_CLEAR;
    clear_next = NULL;
  }
  if (SETUP_CLEAR == setup_phase
      && GC_clear_marks_from(&clear_next, setup_stop_func))
    setup_phase = SETUP_MARK;
  EXIT_GC();
  return SETUP_MARK == setup_phase;
}

/* Start the first world-stopped mark of the full collection set up. */
static void
start_full_mark(void)
{
  GC_ASSERT(SETUP_MARK == setup_phase);
  setup_phase = SETUP_NONE;
#  ifdef PARALLEL_MARK
  /* No builder of free lists may run while the world is stopped. */
  if (GC_parallel)
    GC_wait_for_reclaim();
#  endif
  ENTER_GC();
  GC_promote_black_lists();
  GC_end_clear_marks();
  EXIT_GC();
  GC_n_partial_gcs = 0;
  GC_is_full_gc = TRUE;
  start_mark();
}

/*
 * Run the next chunk of the pending set-up.  If the set-up is complete
 * and less than half of the time limit has passed, start the first
 * world-stopped mark of the collection, which keeps the rest of the time
 * limit; otherwise the mark is due like another chunk.
 */
static void
continue_full_setup(void)
{
  GC_ASSERT(I_HOLD_LOCK());
  GET_TIME(GC_start_time);
  if (setup_phase != SETUP_MARK) {
    GC_bool done = run_setup_chunk();
    unsigned long us = us_since(GC_start_time);

    if (!done || 2 * us >= time_limit_us()) {
      GET_TIME(setup_chunk_end);
      pace_next_slice();
      return;
    }
  }
  start_full_mark();
}

/* Whether the next chunk of the pending set-up is due. */
static GC_bool
setup_chunk_due(void)
{
  word allocd = allocd_now();

  return GC_TIME_UNLIMITED == GC_time_limit
         || allocd - allocd_at_slice >= slice_bytes || allocd < allocd_at_slice
         || us_since(setup_chunk_end) >= time_limit_us();
}

GC_INNER void
GC_redo_mark_clearing(void)
{
  GC_ASSERT(I_HOLD_LOCK());
  if (SETUP_CLEAR == setup_phase || SETUP_MARK == setup_phase) {
    setup_phase = SETUP_CLEAR;
    clear_next = NULL;
  }
}

STATIC word GC_clear_fl_marks(ptr_t *pq, GC_bool clear_links,
                              GC_stop_func stop_func);

/*
 * The finish of a collection in chunks.  With world-stopped steps and
 * a time limit (and neither the leak finder nor the write-barrier checker
 * on), the hold of the final mark ends after the finalization, with the
 * free lists of the kinds in use detached (into `pending_fl`) and the
 * reclaim lists emptied.  The allocator then takes objects only from the
 * thread-local free lists (marked by the final mark), from new blocks and
 * from the objects freed explicitly or returned by exiting threads since
 * (marked, or in new blocks); it neither sweeps a block nor hands out an
 * object which the finish takes for a free one.  The rest of the finish
 * runs in chunks, each holding the allocator lock for at most about the
 * time limit; the first one follows in the hold of the final mark if less
 * than half of the time limit has passed since the mark started, and
 * keeps the rest of it:
 *   - `FINISH_CLEAR`: the detached lists are emptied as by
 *     `clear_free_lists()`, from `pending_kind` and `pending_lg`; nothing
 *     else reads them;
 *   - `FINISH_WALK`: the walk of the blocks that starts the sweep, in the
 *     ascending order of the block addresses from `walk_next`
 *     (`GC_start_reclaim_some()`): it skips the blocks set up since the
 *     final mark (all their objects were allocated since), frees the runs
 *     of empty blocks at the end of each chunk, and enqueues the other
 *     blocks on the reclaim lists `pending_rl`, which the allocator gets
 *     when the walk is done; a block freed or set up meanwhile is below
 *     `walk_next` or skipped;
 *   - `FINISH_REST`: the rest of the finish (the logging, the trigger of
 *     the next collection);
 *   - `FINISH_UNMAP`: the unmapping of the free blocks old enough, from
 *     the free list `unmap_list` (see `unmap_old_blocks()`); the allocator
 *     and the heap growth work as without a pending finish meanwhile.
 * The walk (from `FINISH_WALK_START`), the rest and the unmapping each
 * start in the chunk that completes the phase before if less than half of
 * the time limit has passed, else in the next chunk.  Until the
 * unmapping, a chunk is due after a quarter of the allocation volume
 * between two steps, and at the latest a quarter of the time limit after
 * the end of the previous chunk: meanwhile the allocator cannot reuse the
 * memory the collection found free, thus the chunks run closer together
 * than the steps of the marking.  A chunk of the unmapping is due the time
 * limit after the end of the previous one, so that the client keeps at
 * least half of the time.  If the time limit is set to `GC_TIME_UNLIMITED`
 * meanwhile, the next chunk is due at once.  No collection starts while
 * the finish is pending, except that a collection that is due ends the
 * unmapping after its first chunk (the blocks left are unmapped after
 * a later collection); `GC_try_to_collect_inner()` completes the finish at
 * once.  Protected by the allocator lock.
 */
#  define FINISH_NONE 0
#  define FINISH_CLEAR 1
#  define FINISH_WALK_START 2
#  define FINISH_WALK 3
#  define FINISH_REST 4
#  define FINISH_UNMAP 5
static int finish_phase = FINISH_NONE;

#  ifdef USE_MUNMAP
/*
 * In the `FINISH_UNMAP` phase, the free list to resume the unmapping
 * with, and whether a chunk of the unmapping has run.
 */
static size_t unmap_list = 0;
static GC_bool unmap_chunk_ran = FALSE;
#  endif

/* In the `FINISH_WALK` phase, the first block not visited yet. */
static struct hblk *walk_next = NULL;

/* Whether the collection of the pending finish is a full one. */
static GC_bool finish_full = FALSE;

/*
 * The detached free lists, per kind (`NULL` until a finish in chunks
 * needs them), in the layout of `ok_freelist`.  Allocated with
 * `GC_scratch_alloc()`, thus not a root.
 */
static ptr_t *pending_fl[MAXOBJKINDS];

/*
 * The reclaim lists of the walk, per kind, allocated as `pending_fl`,
 * empty except during the walk.
 */
static struct hblk **pending_rl[MAXOBJKINDS];

/* The kind and the size of the next detached list to empty. */
static unsigned pending_kind = 0;
static size_t pending_lg = 1;

#  define FINISH_PENDING() (finish_phase != FINISH_NONE)

/*
 * Whether the finish of the collection that just completed its marking
 * runs in chunks.
 */
static GC_bool
finish_in_chunks(void)
{
  return steps_on() && GC_time_limit != GC_TIME_UNLIMITED
#  ifndef NO_FIND_LEAK
         && !GC_find_leak_inner
#  endif
#  ifndef NO_MANUAL_VDB
         && !GC_WBAR_SWEEPS_ALL()
#  endif
      ;
}

/*
 * Detach the free lists of the kinds in use and empty the reclaim lists.
 * Return false if the storage for the detached lists cannot be allocated
 * (then nothing is changed).
 */
static GC_bool
detach_free_lists(void)
{
  unsigned kind;

  for (kind = 0; kind < GC_n_kinds; kind++) {
    if (NULL == GC_obj_kinds[kind].ok_reclaim_list)
      continue;
    if (NULL == pending_fl[kind]) {
      pending_fl[kind]
          = (ptr_t *)GC_scratch_alloc((MAXOBJGRANULES + 1) * sizeof(ptr_t));
      if (NULL == pending_fl[kind])
        return FALSE;
      BZERO(pending_fl[kind], (MAXOBJGRANULES + 1) * sizeof(ptr_t));
    }
    if (NULL == pending_rl[kind]) {
      pending_rl[kind] = (struct hblk **)GC_scratch_alloc(
          (MAXOBJGRANULES + 1) * sizeof(struct hblk *));
      if (NULL == pending_rl[kind])
        return FALSE;
      BZERO(pending_rl[kind], (MAXOBJGRANULES + 1) * sizeof(struct hblk *));
    }
  }
  for (kind = 0; kind < GC_n_kinds; kind++) {
    struct obj_kind *ok = &GC_obj_kinds[kind];
    size_t lg;

    if (NULL == ok->ok_reclaim_list) {
      /* The kind is not in use; its free lists are kept. */
      for (lg = 1; lg <= MAXOBJGRANULES; lg++) {
        ptr_t q = (ptr_t)ok->ok_freelist[lg];

        if (q != NULL)
          GC_bytes_found
              -= (GC_signed_word)GC_clear_fl_marks(&q, FALSE, (GC_stop_func)0);
      }
      continue;
    }
    for (lg = 1; lg <= MAXOBJGRANULES; lg++) {
      GC_ASSERT(NULL == pending_fl[kind][lg]);
      pending_fl[kind][lg] = (ptr_t)ok->ok_freelist[lg];
      ok->ok_freelist[lg] = NULL;
    }
    BZERO(ok->ok_reclaim_list, (MAXOBJGRANULES + 1) * sizeof(struct hblk *));
  }
  pending_kind = 0;
  pending_lg = 1;
  return TRUE;
}

/*
 * Empty the detached free lists until `stop_func` returns true.  Return
 * whether they are all empty.
 */
static GC_bool
clear_pending_fl(GC_stop_func stop_func)
{
  for (; pending_kind < GC_n_kinds; pending_kind++, pending_lg = 1) {
    ptr_t *fl = pending_fl[pending_kind];
    GC_bool clear_links;

    if (NULL == fl || NULL == GC_obj_kinds[pending_kind].ok_reclaim_list)
      continue;
    clear_links = GC_obj_kinds[pending_kind].ok_descriptor != 0;
    for (; pending_lg <= MAXOBJGRANULES; pending_lg++) {
      if (NULL == fl[pending_lg])
        continue;
      GC_bytes_found -= (GC_signed_word)GC_clear_fl_marks(
          &fl[pending_lg], clear_links, stop_func);
      if (fl[pending_lg] != NULL)
        return FALSE;
    }
  }
  return TRUE;
}

/*
 * Whether less than half of the time limit has passed since
 * `GC_start_time`, or `unlimited`.
 */
static GC_bool
half_limit_left(GC_bool unlimited)
{
  return unlimited || 2 * us_since(GC_start_time) < time_limit_us();
}

#  ifdef USE_MUNMAP
/*
 * Run a chunk of the unmapping of the pending finish until the time limit
 * since `GC_start_time` (or to the end if `unlimited`).  Return whether
 * the unmapping is complete.
 */
static GC_bool
run_unmap_chunk(GC_bool unlimited)
{
  GC_ASSERT(FINISH_UNMAP == finish_phase);
  unmap_chunk_ran = TRUE;
  /* The chunk may have started with other phases. */
  unmap_start_time = GC_start_time;
  /* Unmapping may have been turned off meanwhile. */
  return 0 == GC_unmap_threshold
         || unmap_old_blocks(&unmap_list,
                             unlimited ? GC_never_stop_func : unmap_stop_func);
}
#  endif

/*
 * Run a chunk of the pending finish until the time limit since
 * `GC_start_time` (or to the end if `unlimited`), and without its
 * unmapping unless `unmap`.
 */
static void
run_finish_chunk(GC_bool unlimited, GC_bool unmap)
{
  GC_stop_func stop_func = unlimited ? GC_never_stop_func : setup_stop_func;

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(FINISH_PENDING());
  setup_stop_calls = 0;
  if (FINISH_CLEAR == finish_phase) {
    ENTER_GC();
    if (clear_pending_fl(stop_func))
      finish_phase = FINISH_WALK_START;
    EXIT_GC();
  }
  if (FINISH_WALK_START == finish_phase && half_limit_left(unlimited)) {
    GC_start_reclaim_begin(pending_rl);
    walk_next = NULL;
    finish_phase = FINISH_WALK;
  }
  if (FINISH_WALK == finish_phase) {
#  ifdef PARALLEL_MARK
    /* The walk ends with no builder of free lists running. */
    if (GC_parallel)
      GC_wait_for_reclaim();
#  endif
    ENTER_GC();
    if (GC_start_reclaim_some(&walk_next, stop_func))
      finish_phase = FINISH_REST;
    EXIT_GC();
  }
  if (FINISH_REST == finish_phase && half_limit_left(unlimited)) {
    finish_phase = FINISH_NONE;
    finish_rest(finish_full);
#  ifdef USE_MUNMAP
    if (UNMAP_ON()) {
      finish_phase = FINISH_UNMAP;
      unmap_list = 0;
      unmap_chunk_ran = FALSE;
    }
#  endif
  }
#  ifdef USE_MUNMAP
  if (FINISH_UNMAP == finish_phase && unmap && half_limit_left(unlimited)
      && run_unmap_chunk(unlimited))
    finish_phase = FINISH_NONE;
#  else
  UNUSED_ARG(unmap);
#  endif
  if (FINISH_PENDING()) {
    GET_TIME(setup_chunk_end);
    pace_next_slice();
  }
}

/* Start the pending finish (the caller detached the free lists). */
static void
start_finish_chunks(GC_bool full)
{
  GC_ASSERT(I_HOLD_LOCK());
  finish_phase = FINISH_CLEAR;
  finish_full = full;
  GET_TIME(setup_chunk_end);
  pace_next_slice();
}

/* Whether the next chunk of the pending finish is due. */
static GC_bool
finish_chunk_due(void)
{
  word allocd = allocd_now();

  if (GC_TIME_UNLIMITED == GC_time_limit)
    return TRUE;
#  ifdef USE_MUNMAP
  if (FINISH_UNMAP == finish_phase)
    return us_since(setup_chunk_end) >= time_limit_us();
#  endif
  return allocd - allocd_at_slice >= slice_bytes / 4
         || allocd < allocd_at_slice
         || 4 * us_since(setup_chunk_end) >= time_limit_us();
}

/* Complete the pending finish, if any, at once. */
STATIC void
GC_complete_finish(void)
{
  GC_ASSERT(I_HOLD_LOCK());
  if (FINISH_PENDING()) {
    GET_TIME(GC_start_time);
    run_finish_chunk(TRUE, TRUE);
  }
  GC_ASSERT(!FINISH_PENDING());
}

/*
 * When the final mark of the collection in progress became due (see
 * `GC_final_mark_due`).  Protected by the allocator lock.
 */
static CLOCK_TYPE final_due_since;

#  define FINAL_DUE() GC_final_mark_due

/*
 * Whether the set-up of a full collection, a final mark or the finish of
 * a collection is still to run.
 */
#  define WORK_PENDING() (SETUP_PENDING() || FINAL_DUE() || FINISH_PENDING())
#else
#  define FINAL_DUE() FALSE
#  define FINISH_PENDING() FALSE
#  define WORK_PENDING() FALSE
#endif /* !PARALLEL_MARK_DEADLINE */

/*
 * Initiate a garbage collection.  Choose judiciously between partial,
 * full, and stop-world collections.  Called only if `GC_should_collect()`
 * returned true.
 */
STATIC void
GC_maybe_gc(void)
{
  GC_ASSERT(I_HOLD_LOCK());
  ASSERT_CANCEL_DISABLED();
  if (!GC_incremental) {
    GC_gcollect_inner();
    return;
  }

  GC_ASSERT(!GC_collection_in_progress());
  GC_ASSERT(!WORK_PENDING());
#ifdef PARALLEL_MARK
  if (GC_parallel)
    GC_wait_for_reclaim();
#endif
  if (GC_need_full_gc || GC_n_partial_gcs >= GC_full_freq
#ifndef NO_MANUAL_VDB
      || GC_wbar_need_full
#endif
  ) {
    GC_COND_LOG_PRINTF(
        "***>Full mark for collection #%lu after %lu bytes allocated\n",
        (unsigned long)GC_gc_no + 1, (unsigned long)GC_bytes_allocd);
    GC_notify_full_gc();
#ifdef PARALLEL_MARK_DEADLINE
    if (steps_on() && GC_time_limit != GC_TIME_UNLIMITED) {
      setup_phase = SETUP_SWEEP;
      continue_full_setup();
      return;
    }
#endif
    ENTER_GC();
    GC_promote_black_lists();
    (void)GC_reclaim_all((GC_stop_func)0, TRUE);
    GC_clear_marks();
    EXIT_GC();
    GC_n_partial_gcs = 0;
    GC_is_full_gc = TRUE;
  } else {
    GC_n_partial_gcs++;
  }
#ifndef NO_CLOCK
  if (GC_time_limit != GC_TIME_UNLIMITED)
    GET_TIME(GC_start_time);
#endif
  start_mark();
}

STATIC GC_on_collection_event_proc GC_on_collection_event = 0;

GC_API void GC_CALL
GC_set_on_collection_event(GC_on_collection_event_proc fn)
{
  /* `fn` may be 0 (means no event notifier). */
  LOCK();
  GC_on_collection_event = fn;
  UNLOCK();
}

GC_API GC_on_collection_event_proc GC_CALL
GC_get_on_collection_event(void)
{
  GC_on_collection_event_proc fn;

  READER_LOCK();
  fn = GC_on_collection_event;
  READER_UNLOCK();
  return fn;
}

GC_INNER GC_bool
GC_try_to_collect_inner(GC_stop_func stop_func)
{
#ifndef NO_CLOCK
  CLOCK_TYPE start_time = CLOCK_TYPE_INITIALIZER;
  GC_bool start_time_valid;
#endif

  ASSERT_CANCEL_DISABLED();
  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(GC_is_initialized);
  if (GC_dont_gc || (*stop_func)())
    return FALSE;
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_START);
#ifdef PARALLEL_MARK_DEADLINE
  /* Finish the previous collection. */
  GC_complete_finish();
#endif
  if (GC_incremental && (GC_collection_in_progress() || FINAL_DUE())) {
    GC_COND_LOG_PRINTF(
        "GC_try_to_collect_inner: finishing collection in progress\n");
    /* Just finish collection already in progress. */
    if (!GC_complete_marking(stop_func, 1)) {
      /* TODO: Notify `GC_EVENT_ABANDON`. */
      return FALSE;
    }
#ifdef PARALLEL_MARK_DEADLINE
    GC_complete_finish();
#endif
  }
  GC_notify_full_gc();
#ifndef NO_CLOCK
  start_time_valid = FALSE;
  if ((GC_print_stats | (int)GC_measure_performance) != 0) {
    if (GC_print_stats)
      GC_log_printf("Initiating full world-stop collection!\n");
    start_time_valid = TRUE;
    GET_TIME(start_time);
  }
#endif
  GC_promote_black_lists();
  /*
   * Make sure all blocks have been reclaimed, so sweep routines do not
   * see cleared mark bits.  If we are guaranteed to finish, then this
   * is unnecessary.  In the find-leak case, we have to finish to
   * guarantee that previously unmarked objects are not reported as leaks.
   */
#ifdef PARALLEL_MARK
  if (GC_parallel)
    GC_wait_for_reclaim();
#endif
  ENTER_GC();
  if ((GC_find_leak_inner || stop_func != GC_never_stop_func)
      && !GC_reclaim_all(stop_func, FALSE)) {
    /* Aborted.  So far everything is still consistent. */
    EXIT_GC();
    /* TODO: Notify `GC_EVENT_ABANDON`. */
    return FALSE;
  }
  GC_invalidate_mark_state(); /*< flush mark stack */
  GC_clear_marks();
#ifdef PARALLEL_MARK_DEADLINE
  /*
   * This replaces the pending set-up, if any, and a due final mark, which
   * is left only if the incremental mode was turned off.
   */
  setup_phase = SETUP_NONE;
  GC_final_mark_due = FALSE;
#endif
  SAVE_CALLERS_TO_LAST_STACK();
  GC_is_full_gc = TRUE;
  EXIT_GC();
  if (!GC_stopped_mark(stop_func)) {
    if (!GC_incremental) {
      /*
       * We are partially done and have no way to complete or use
       * current work.  Reestablish invariants as cheaply as possible.
       */
      GC_invalidate_mark_state();
      GC_unpromote_black_lists();
    } else {
      /*
       * We claim the world is already (or still) consistent.
       * We will finish incrementally.
       */
    }
    /* TODO: Notify `GC_EVENT_ABANDON`. */
    return FALSE;
  }
  GC_finish_collection();
#ifdef PARALLEL_MARK_DEADLINE
  /* The caller expects the collection to be finished on return. */
  GC_complete_finish();
#endif
#ifndef NO_CLOCK
  if (start_time_valid) {
    CLOCK_TYPE current_time;
    unsigned long time_diff, ns_frac_diff;

    GET_TIME(current_time);
    time_diff = MS_TIME_DIFF(current_time, start_time);
    ns_frac_diff = NS_FRAC_TIME_DIFF(current_time, start_time);
    if (GC_measure_performance) {
      GC_full_gc_total_time += time_diff; /*< may wrap */
      GC_full_gc_total_ns_frac += (unsigned32)ns_frac_diff;
      if (GC_full_gc_total_ns_frac >= (unsigned32)1000000UL) {
        /* Overflow of the nanoseconds part. */
        GC_full_gc_total_ns_frac -= (unsigned32)1000000UL;
        GC_full_gc_total_time++;
      }
    }
    if (GC_print_stats)
      GC_log_printf("Complete collection took %lu ms %lu ns\n", time_diff,
                    ns_frac_diff);
  }
#endif
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_END);
  return TRUE;
}

/* The default value of `GC_rate`. */
#ifndef GC_RATE
#  define GC_RATE 10
#endif

/*
 * When `GC_collect_a_little_inner()` performs `n_blocks` units of garbage
 * collection work, a unit is intended to touch roughly `GC_rate` pages.
 * (But, every once in a while, we do more than that.)  This needs to be
 * a fairly large number with our current incremental collection strategy,
 * since otherwise we allocate too much during garbage collection, and
 * the cleanup gets expensive.
 */
STATIC unsigned GC_rate = GC_RATE;

GC_API void GC_CALL
GC_set_rate(int value)
{
  GC_ASSERT(value > 0);
  GC_rate = (unsigned)value;
}

GC_API int GC_CALL
GC_get_rate(void)
{
  return (int)GC_rate;
}

/* The default maximum number of prior attempts at world stop marking. */
#ifndef MAX_PRIOR_ATTEMPTS
#  define MAX_PRIOR_ATTEMPTS 3
#endif

/*
 * The maximum number of prior attempts at world stop marking.
 * A value of 1 means that we finish the second time, no matter how long
 * it takes.  Does not count the initial root scan for a full collection.
 * With a time limit, the final marks of an incremental collection follow
 * `MAX_ABANDONED_FINALS` instead or, with the heap cap (see `heap_cap()`)
 * in builds with the parallel marker, `final_limit_us()`.
 */
static int max_prior_attempts = MAX_PRIOR_ATTEMPTS;

GC_API void GC_CALL
GC_set_max_prior_attempts(int value)
{
  GC_ASSERT(value >= 0);
  max_prior_attempts = value;
}

GC_API int GC_CALL
GC_get_max_prior_attempts(void)
{
  return max_prior_attempts;
}

#if !defined(NO_CLOCK) && !defined(GC_DISABLE_INCREMENTAL)
/*
 * The final world-stopped marks of a collection that are abandoned before
 * one runs without the time limit, whatever `max_prior_attempts` is.
 */
#  ifndef MAX_ABANDONED_FINALS
#    define MAX_ABANDONED_FINALS 3
#  endif

/*
 * The final marks of the collection in progress that were abandoned.
 * Protected by the allocator lock.
 */
static unsigned n_final_abandoned = 0;
#endif

/*
 * Disable the thread cancellation around the collection work in
 * `GC_collect_a_little_inner()`.  If `GC_NO_CANCEL_STATE_SKIP` macro is
 * defined, then the cancellation is disabled for the whole call instead.
 */
#ifdef GC_NO_CANCEL_STATE_SKIP
#  define DISABLE_CANCEL_FOR_WORK(state) (void)0
#  define RESTORE_CANCEL_FOR_WORK(state) (void)0
#else
#  define DISABLE_CANCEL_FOR_WORK(state) DISABLE_CANCEL(state)
#  define RESTORE_CANCEL_FOR_WORK(state) RESTORE_CANCEL(state)
#endif

GC_INNER void
GC_collect_a_little_inner(size_t n_blocks)
{
  IF_CANCEL(int cancel_state;)

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(GC_is_initialized);
  /*
   * In the incremental mode, this is called at every refill of
   * a thread-local free list and at every allocation of a large object,
   * thus the thread cancellation (disabling it is a system call on some
   * targets, e.g. Darwin) is disabled only if there is collection work
   * to do, unless `GC_NO_CANCEL_STATE_SKIP` macro is defined.
   */
#ifdef GC_NO_CANCEL_STATE_SKIP
  DISABLE_CANCEL(cancel_state);
#endif
  if (GC_incremental && (GC_collection_in_progress() || FINAL_DUE())) {
    size_t i;
    size_t max_deficit = GC_rate * n_blocks;
    GC_bool stack_empty = FALSE;
#ifdef PARALLEL_MARK_DEADLINE
    unsigned share
        = GC_time_limit != GC_TIME_UNLIMITED ? collector_share() : 0;
    /*
     * Near the heap cap, the marking completes in one stop, which also
     * completes the finish except for the unmapping, so that the memory
     * found free is reused at once instead of the heap growing.
     */
    GC_bool one_stop = steps_on() && !GC_dont_gc && share >= ONE_STOP_SHARE;
#endif

    DISABLE_CANCEL_FOR_WORK(cancel_state);
    ENTER_GC();
#ifdef PARALLEL_MARK_DEADLINE
    if (steps_on()) {
      /*
       * Mark only in world-stopped steps, one per `slice_bytes` allocated,
       * or when nothing was allocated since the previous call (the caller
       * waits for the collection to complete, or the heap is to grow), once
       * the pacing by the memory headroom lets it start (else the heap
       * grows).  If the caller holds the allocator lock until the marking
       * completes, no client takes memory from the allocator meanwhile, and
       * the steps follow each other at once.
       */
      word allocd = allocd_now();
      GC_bool due
          = one_stop || marking_awaited
            || ((allocd - allocd_at_slice >= slice_bytes
                 || allocd < allocd_at_slice || allocd == allocd_at_call)
                && slice_gap_passed(share));

      if (GC_final_mark_due) {
        /*
         * The final mark is due like a step, and at the latest the time
         * limit after the step that emptied the mark stack, once the pacing
         * lets it start.
         */
        if (!GC_dont_gc
            && (due
                || (us_since(final_due_since) >= time_limit_us()
                    && slice_gap_passed(share))))
          stack_empty = TRUE;
      } else if (due) {
        unsigned long limit = step_limit_us(share);
        GC_bool stack_emptied;

        if (limit > time_limit_us() && !one_stop)
          slice_limit_us = limit;
        stack_emptied = GC_parallel_mark_step(one_stop);
        slice_limit_us = 0;
        if (one_stop) {
          /* The final mark follows at once, in the same lock hold. */
          GC_ASSERT(stack_emptied);
          stack_empty = TRUE;
        } else if (stack_emptied) {
          /* The final mark runs in a hold of the allocator lock of its own. */
          GC_final_mark_due = TRUE;
          GET_TIME(final_due_since);
        }
      }
      allocd_at_call = allocd;
    } else
#endif
    /* else */ {
      /* The manual VDB mode marks only with the world stopped. */
      GC_ASSERT(!GC_manual_vdb);
#ifdef PARALLEL_MARK
      if (GC_time_limit != GC_TIME_UNLIMITED)
        GC_parallel_mark_disabled = TRUE;
#endif
      for (i = GC_mark_deficit; i < max_deficit; i++) {
        if (GC_mark_some(NULL)) {
          stack_empty = TRUE;
          break;
        }
      }
#ifdef PARALLEL_MARK
      GC_parallel_mark_disabled = FALSE;
#endif
    }
    EXIT_GC();
    GC_after_marking();

    if (stack_empty && !GC_dont_gc) {
      GC_stop_func stop_func;
      GC_bool done;

      GC_ASSERT(!GC_collection_in_progress());
#ifdef PARALLEL_MARK_DEADLINE
      GC_final_mark_due = FALSE;
#endif
      /* Need to follow up with a full collection. */
      SAVE_CALLERS_TO_LAST_STACK();
#ifdef PARALLEL_MARK
      if (GC_parallel)
        GC_wait_for_reclaim();
#endif
      stop_func = GC_n_attempts >= max_prior_attempts
                          || (GC_time_limit == GC_TIME_UNLIMITED
                              && GC_default_stop_func == GC_never_stop_func)
                      ? GC_never_stop_func
                      : GC_timeout_stop_func;
#if !defined(NO_CLOCK) && !defined(GC_DISABLE_INCREMENTAL)
      if (GC_time_limit != GC_TIME_UNLIMITED) {
        /*
         * The final mark keeps a time limit: one that does not complete in
         * time is abandoned, and the marking continues.  With the pacing by
         * the memory headroom, the limit is the one of `final_limit_us()`,
         * which the need of each abandoned final mark raises up to the
         * bound; after at most `MAX_ABANDONED_AT_BOUND` final marks
         * abandoned at the bound, the next one runs without it.
         * Otherwise, after `MAX_ABANDONED_FINALS` abandoned final marks,
         * the next one runs without it.  Either way, the collection
         * completes.
         */
        stop_func = GC_timeout_stop_func;
#  ifdef PARALLEL_MARK_DEADLINE
        if (heap_cap() != 0) {
          unsigned long limit = final_limit_us(share);

          if (0 == limit) {
            stop_func = GC_never_stop_func;
            if (n_final_abandoned_at_bound > 0 && !one_stop) {
              GC_COND_LOG_PRINTF("Final mark %u of collection #%lu without"
                                 " a time limit, after %u abandoned at the"
                                 " bound\n",
                                 n_final_abandoned + 1,
                                 (unsigned long)GC_gc_no + 1,
                                 n_final_abandoned_at_bound);
            }
          } else if (limit > time_limit_us()) {
            slice_limit_us = limit;
            final_mark_bounded = limit >= MAX_SLICE_LIMITS * time_limit_us();
          }
        } else
#  endif
        /* else */ {
          if (n_final_abandoned >= MAX_ABANDONED_FINALS)
            stop_func = GC_never_stop_func;
        }
      }
#endif
#ifdef PARALLEL_MARK_DEADLINE
      if (one_stop) {
        stop_func = GC_never_stop_func;
        slice_limit_us = 0;
        final_mark_bounded = FALSE;
        in_one_stop = TRUE;
      }
      final_mark_no = n_final_abandoned + 1;
      final_mark_unlimited = stop_func != GC_timeout_stop_func
                             || GC_time_limit == GC_TIME_UNLIMITED;
#endif
#ifndef NO_CLOCK
      if (GC_time_limit != GC_TIME_UNLIMITED
          && stop_func == GC_timeout_stop_func)
        GET_TIME(GC_start_time);
#endif
      done = GC_stopped_mark(stop_func);
#ifdef PARALLEL_MARK_DEADLINE
      if (!done) {
        /* Also where `GC_stopped_mark()` counted no slice. */
        raise_abandoned_final(last_slice_us);
        if (final_mark_bounded) {
          n_final_abandoned_at_bound++;
          allocd_at_bound_abandon = allocd_now();
          GC_COND_LOG_PRINTF("Final mark %u of collection #%lu abandoned at"
                             " the bound, %u of the collection\n",
                             final_mark_no, (unsigned long)GC_gc_no + 1,
                             n_final_abandoned_at_bound);
        }
      }
      slice_limit_us = 0;
      final_mark_bounded = FALSE;
      final_mark_no = 0;
      in_one_stop = FALSE;
#endif
      if (done) {
        GC_finish_collection();
#ifdef PARALLEL_MARK_DEADLINE
        /* The unmapping of the finish stays in chunks. */
        if (one_stop && FINISH_PENDING() && finish_phase != FINISH_UNMAP) {
          GET_TIME(GC_start_time);
          run_finish_chunk(TRUE, FALSE);
        }
#endif
      } else {
#if !defined(NO_CLOCK) && !defined(GC_DISABLE_INCREMENTAL)
        n_final_abandoned++;
#endif
        GC_n_attempts++;
      }
    }
    if (GC_mark_deficit > 0) {
      GC_mark_deficit
          = GC_mark_deficit > max_deficit ? GC_mark_deficit - max_deficit : 0;
    }
    RESTORE_CANCEL_FOR_WORK(cancel_state);
#ifdef PARALLEL_MARK_DEADLINE
#  ifdef USE_MUNMAP
  } else if (FINISH_UNMAP == finish_phase && unmap_chunk_ran && !GC_dont_gc
             && GC_should_collect()) {
    /*
     * A collection that is due ends the unmapping of the previous one
     * after its first chunk.
     */
    DISABLE_CANCEL_FOR_WORK(cancel_state);
    finish_phase = FINISH_NONE;
    GC_maybe_gc();
    RESTORE_CANCEL_FOR_WORK(cancel_state);
#  endif
  } else if (FINISH_PENDING()) {
    /* The finish of a collection proceeds even if collections are disabled. */
    if (finish_chunk_due()) {
      DISABLE_CANCEL_FOR_WORK(cancel_state);
      GET_TIME(GC_start_time);
      run_finish_chunk(FALSE, TRUE);
      RESTORE_CANCEL_FOR_WORK(cancel_state);
    }
  } else if (SETUP_PENDING()) {
    if (!GC_dont_gc && setup_chunk_due()) {
      DISABLE_CANCEL_FOR_WORK(cancel_state);
      continue_full_setup();
      RESTORE_CANCEL_FOR_WORK(cancel_state);
    }
#endif
  } else if (!GC_dont_gc && GC_should_collect()) {
    DISABLE_CANCEL_FOR_WORK(cancel_state);
    GC_maybe_gc();
    RESTORE_CANCEL_FOR_WORK(cancel_state);
#ifdef PARALLEL_MARK_DEADLINE
  } else if (finish_timed && !GC_dont_gc
             && allocd_now() - allocd_at_rate_sample >= rate_sample_bytes) {
    /* The window of the allocation rate moves (see `rate_start_time`). */
    rate_start_time = rate_sample_time;
    allocd_at_rate_start = allocd_at_rate_sample;
    GET_TIME(rate_sample_time);
    allocd_at_rate_sample = allocd_now();
#endif
  }
#ifdef GC_NO_CANCEL_STATE_SKIP
  RESTORE_CANCEL(cancel_state);
#endif
}

GC_INNER GC_bool
GC_complete_marking(GC_stop_func stop_func, size_t n_blocks)
{
  GC_bool done = TRUE;

  GC_ASSERT(I_HOLD_LOCK());
#ifdef PARALLEL_MARK_DEADLINE
  marking_awaited = TRUE;
#endif
  /* A final mark does not run while the collections are disabled. */
  while (GC_incremental
         && (GC_collection_in_progress() || (FINAL_DUE() && !GC_dont_gc))) {
    if ((*stop_func)()) {
      done = FALSE;
      break;
    }
    GC_collect_a_little_inner(n_blocks);
  }
#ifdef PARALLEL_MARK_DEADLINE
  marking_awaited = FALSE;
#endif
  return done;
}

#if !defined(NO_FIND_LEAK) || !defined(SHORT_DBG_HDRS)
GC_INNER void (*GC_check_heap)(void) = 0;
GC_INNER void (*GC_print_all_smashed)(void) = 0;
#endif

GC_API int GC_CALL
GC_collect_a_little(void)
{
  int result;

  if (UNLIKELY(!GC_is_initialized))
    GC_init();
  LOCK();
  /*
   * Note: if the collection is in progress, this may do marking (not
   * stopping the world) even in case of disabled garbage collection.
   */
  GC_collect_a_little_inner(1);
  /*
   * A pending set-up and a due final mark do not run while the collections
   * are disabled, unlike a pending finish.
   */
  result = (int)(GC_collection_in_progress() || FINISH_PENDING()
                 || (WORK_PENDING() && !GC_dont_gc));
  UNLOCK();
  if (GC_debugging_started && !result)
    GC_print_all_smashed();
  return result;
}

#ifdef THREADS
GC_API void GC_CALL
GC_stop_world_external(void)
{
  GC_ASSERT(GC_is_initialized);
  LOCK();
#  ifdef THREAD_LOCAL_ALLOC
  GC_ASSERT(!GC_world_stopped);
#  endif
  ENTER_GC();
  STOP_WORLD();
#  ifdef THREAD_LOCAL_ALLOC
  GC_world_stopped = TRUE;
#  endif
}

GC_API void GC_CALL
GC_start_world_external(void)
{
#  ifdef THREAD_LOCAL_ALLOC
  GC_ASSERT(GC_world_stopped);
  GC_world_stopped = FALSE;
#  else
  GC_ASSERT(GC_is_initialized);
#  endif
  START_WORLD();
  EXIT_GC();
  UNLOCK();
}
#endif /* THREADS */

#ifdef USE_MUNMAP
#  ifndef MUNMAP_THRESHOLD
#    define MUNMAP_THRESHOLD 7
#  endif
GC_INNER unsigned GC_unmap_threshold = MUNMAP_THRESHOLD;

#  define IF_USE_MUNMAP(x) x
#  define COMMA_IF_USE_MUNMAP(x) /* comma */ , x
#else
#  define IF_USE_MUNMAP(x)
#  define COMMA_IF_USE_MUNMAP(x)
#endif /* !USE_MUNMAP */

#ifdef PARALLEL_MARK_DEADLINE
/* The outcomes of a slice, for `end_slice()`. */
#  define SLICE_CONTINUES 0
#  define SLICE_STACK_EMPTY 1 /*< a step emptied the mark stack */
#  define SLICE_DONE 2        /*< the marking of the collection completed */

/*
 * Count a slice of the collection in progress: the world was stopped
 * from `start` until now.  If the marking is complete (`SLICE_DONE`), log
 * the slices of the collection.  Otherwise set when the next step is due
 * (see `pace_next_slice()`).
 */
static void
end_slice(CLOCK_TYPE start, int outcome)
{
  CLOCK_TYPE now;
  unsigned long us;
  GC_bool done = SLICE_DONE == outcome;

  GC_ASSERT(I_HOLD_LOCK());
  GET_TIME(now);
  us = MS_TIME_DIFF(now, start) * 1000UL
       + NS_FRAC_TIME_DIFF(now, start) / 1000UL;
  if (0 == n_slices) {
    mark_start_time = start;
    allocd_at_mark_start = allocd_now();
  }
  slice_end_time = now;
  last_slice_us = us;
  n_slices++;
  if (us > longest_slice_us)
    longest_slice_us = us;
  total_slice_us += us;
  GC_COND_LOG_PRINTF("Slice %u of collection #%lu: world stopped for %lu us,"
                     " %s\n",
                     n_slices, (unsigned long)GC_gc_no + (done ? 0 : 1), us,
                     done                           ? "marking complete"
                     : SLICE_STACK_EMPTY == outcome ? "mark stack empty"
                                                    : "marking continues");
  if (done) {
    unsigned long wall_us = us_since(mark_start_time);

    GC_COND_LOG_PRINTF("Marked collection #%lu in %u slices: longest %lu us,"
                       " total %lu us\n",
                       (unsigned long)GC_gc_no, n_slices, longest_slice_us,
                       total_slice_us);
    prev_mark_us[GC_is_full_gc ? 1 : 0] = total_slice_us;
    /* A collection completed in one stop keeps the need of the previous. */
    if (!in_one_stop)
      prev_final_us = final_mark_no != 0 ? us : 0;
    /*
     * The allocation rate from the start of its window, before the
     * collection, so that it is known even if the marking completed in its
     * first mark.
     */
    if (finish_timed) {
      unsigned long window_us = us_since(rate_start_time);

      prev_allocd = allocd_now() > allocd_at_rate_start
                        ? allocd_now() - allocd_at_rate_start
                        : 0;
      prev_client_us
          = window_us > total_slice_us ? window_us - total_slice_us : 0;
    } else {
      prev_allocd = allocd_now() > allocd_at_mark_start
                        ? allocd_now() - allocd_at_mark_start
                        : 0;
      prev_client_us = wall_us > total_slice_us ? wall_us - total_slice_us : 0;
    }
    abandoned_final_us = 0;
    prev_n_slices = n_slices;
    n_slices = 0;
    longest_slice_us = 0;
    total_slice_us = 0;
  } else {
    /* The pacing of the next step counts an abandoned final mark. */
    if (final_mark_no != 0)
      raise_abandoned_final(us);
    pace_next_slice();
  }
}
#endif

/*
 * We stop the world and mark from all roots.  If `stop_func()` ever
 * returns `TRUE`, we may fail and return `FALSE`.  Increment `GC_gc_no`
 * if we succeed.
 */
STATIC GC_bool
GC_stopped_mark(GC_stop_func stop_func)
{
  ptr_t cold_gc_frame = GC_approx_sp();
  unsigned abandoned_at;
#ifdef PARALLEL_MARK
  /*
   * The value of `abandoned_at` at which a marking with the parallel marker
   * disabled completed, or zero.  Logged once the world is restarted.
   */
  unsigned serial_done_at = 0;
#endif
#ifndef NO_CLOCK
  CLOCK_TYPE start_time = CLOCK_TYPE_INITIALIZER;
  GC_bool start_time_valid = FALSE;
#endif
#ifdef PARALLEL_MARK_DEADLINE
  CLOCK_TYPE slice_start = CLOCK_TYPE_INITIALIZER;
  GC_bool count_slice = GC_parallel_slices;
#endif
#ifndef NO_MANUAL_VDB
  GC_bool roots_first = GC_manual_vdb;
  word roots_pushes_at;
#endif

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(GC_is_initialized);
#if !defined(PARALLEL_MARK_DEADLINE) && !defined(NO_MANUAL_VDB)
  /*
   * Without the steps, the marking of an abandoned world-stopped mark
   * would continue with the world running, which the manual VDB mode
   * does not allow.
   */
  if (GC_manual_vdb)
    stop_func = GC_never_stop_func;
#endif
  ENTER_GC();
#if !defined(REDIRECT_MALLOC) && defined(USE_WINALLOC)
  GC_add_current_malloc_heap();
#endif
#if defined(REGISTER_LIBRARIES_EARLY)
  GC_cond_register_dynamic_libraries();
#endif

#if !defined(GC_NO_FINALIZATION) && !defined(GC_TOGGLE_REFS_NOT_NEEDED)
  GC_process_togglerefs();
#endif

  /* Output blank line for convenience here. */
  GC_COND_LOG_PRINTF(
      "\n--> Marking for collection #%lu after %lu allocated bytes\n",
      (unsigned long)GC_gc_no + 1, (unsigned long)GC_bytes_allocd);
#ifndef NO_CLOCK
  if (GC_PRINT_STATS_FLAG || GC_measure_performance) {
    GET_TIME(start_time);
    start_time_valid = TRUE;
  }
#endif
#ifdef PARALLEL_MARK_DEADLINE
  if (count_slice)
    GET_TIME(slice_start);
#endif
#ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_PRE_STOP_WORLD);
#endif
  STOP_WORLD();
#ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_POST_STOP_WORLD);
#  ifdef THREAD_LOCAL_ALLOC
  GC_world_stopped = TRUE;
#  elif defined(CPPCHECK)
  /* Workaround a warning about adjacent same `if` condition. */
  (void)0;
#  endif
#endif

#ifdef MAKE_BACK_GRAPH
  if (GC_print_back_height) {
    GC_build_back_graph();
  }
#endif

  /* Notify about marking from all roots. */
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_MARK_START);

  /* Minimize junk left in my registers and on the stack. */
  GC_clear_a_few_frames();
  GC_noop6(0, 0, 0, 0, 0, 0);

  GC_initiate_gc();
#ifndef NO_MANUAL_VDB
  roots_pushes_at = GC_roots_pushes;
#endif
#ifdef PARALLEL_MARK
  if (stop_func != GC_never_stop_func) {
#  ifdef PARALLEL_MARK_DEADLINE
    /* Mark in parallel until the time limit. */
    if (stop_func == GC_timeout_stop_func && parallel_slices_on()) {
      unsigned long limit_ms, limit_ns;

      current_time_limit(&limit_ms, &limit_ns);
      GC_set_mark_deadline(limit_ms, limit_ns);
    } else
#  endif
    /* else */ {
      GC_parallel_mark_disabled = TRUE;
    }
  }
#endif
  for (abandoned_at = 1;; abandoned_at++) {
#ifndef NO_MANUAL_VDB
    /*
     * In the manual VDB mode, the dirty bits read (or cleared) by
     * `GC_initiate_gc()` above are followed by the bits for the next read
     * that the root push sets: of the objects the stacks reference, which
     * a client may fill without a barrier after the world restarts, and
     * of the thread-local free lists.  Thus the marking is not abandoned
     * before the roots are pushed.
     */
    if (!roots_first || GC_roots_pushes != roots_pushes_at)
#endif
    {
      if ((*stop_func)())
        break;
    }
    if (GC_mark_some(cold_gc_frame)) {
#ifdef PARALLEL_MARK
      if (GC_parallel && GC_parallel_mark_disabled)
        serial_done_at = abandoned_at;
#endif
      abandoned_at = 0;
      break;
    }
  }
#ifdef PARALLEL_MARK
  GC_parallel_mark_disabled = FALSE;
#endif
#ifdef PARALLEL_MARK_DEADLINE
  if (stop_func == GC_timeout_stop_func)
    GC_clear_mark_deadline();
#endif

#ifndef NO_MANUAL_VDB
  if (UNLIKELY(GC_wbar_verify))
    GC_wbar_after_mark(0 == abandoned_at);
#endif
  if (abandoned_at > 0) {
    /* Give the mutator a chance. */
    GC_mark_deficit = abandoned_at - 1;
    /* TODO: Notify `GC_EVENT_MARK_ABANDON`. */
  } else {
    GC_gc_no++;
#if defined(GC_ASSERTIONS) && defined(THREAD_LOCAL_ALLOC) \
    && !defined(DBG_HDRS_ALL)
    /*
     * Check that the objects on the thread-local free lists are marked,
     * while no thread takes objects from them.
     */
    GC_check_tls();
#endif
    /* Check all debugged objects for consistency. */
    if (GC_debugging_started)
      GC_check_heap();
    if (GC_on_collection_event)
      GC_on_collection_event(GC_EVENT_MARK_END);
  }

#ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_PRE_START_WORLD);
#endif
#ifdef THREAD_LOCAL_ALLOC
  GC_world_stopped = FALSE;
#endif
  START_WORLD();
#ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_POST_START_WORLD);
#endif
#if !defined(GC_DISABLE_INCREMENTAL) && !defined(NO_CLOCK)
  log_timeout_stop();
#endif
#ifdef PARALLEL_MARK_DEADLINE
  if (count_slice)
    end_slice(slice_start, 0 == abandoned_at ? SLICE_DONE : SLICE_CONTINUES);
#endif
#ifdef PARALLEL_MARK
  if (serial_done_at != 0) {
    GC_COND_LOG_PRINTF("Stopped marking done after %u iterations"
                       " with disabled parallel marker\n",
                       serial_done_at - 1);
  }
#endif
#ifndef NO_MANUAL_VDB
  /* Nothing is printed with the world stopped (it may deadlock). */
  if (UNLIKELY(GC_wbar_verify))
    GC_wbar_after_start_world(0 == abandoned_at);
#endif

#ifndef NO_CLOCK
  if (start_time_valid) {
    CLOCK_TYPE current_time;
    unsigned long time_diff, ns_frac_diff;

    /* TODO: Avoid code duplication from `GC_try_to_collect_inner`. */
    GET_TIME(current_time);
    time_diff = MS_TIME_DIFF(current_time, start_time);
    ns_frac_diff = NS_FRAC_TIME_DIFF(current_time, start_time);
    if (GC_measure_performance) {
      GC_stopped_mark_total_time += time_diff; /*< may wrap */
      GC_stopped_mark_total_ns_frac += (unsigned32)ns_frac_diff;
      if (GC_stopped_mark_total_ns_frac >= (unsigned32)1000000UL) {
        GC_stopped_mark_total_ns_frac -= (unsigned32)1000000UL;
        GC_stopped_mark_total_time++;
      }
    }

    if (GC_PRINT_STATS_FLAG || GC_measure_performance) {
      unsigned total_time = GC_world_stopped_total_time;
      unsigned divisor = GC_world_stopped_total_divisor;

      /* Compute new world-stop delay total time. */
      if (total_time > (((unsigned)-1) >> 1)
          || divisor >= MAX_TOTAL_TIME_DIVISOR) {
        /* Halve values if overflow occurs. */
        total_time >>= 1;
        divisor >>= 1;
      }
      total_time += time_diff < (((unsigned)-1) >> 1) ? (unsigned)time_diff
                                                      : ((unsigned)-1) >> 1;
      /* Update old `GC_world_stopped_total_time` and its divisor. */
      GC_world_stopped_total_time = total_time;
      GC_world_stopped_total_divisor = ++divisor;
      if (GC_PRINT_STATS_FLAG && 0 == abandoned_at) {
        GC_ASSERT(divisor != 0);
        GC_log_printf(
            "World-stopped marking took %lu ms %lu ns (%u ms in average)\n",
            time_diff, ns_frac_diff, total_time / divisor);
      }
    }
  }
#endif
  GC_after_marking();

  EXIT_GC();
  if (0 == abandoned_at)
    return TRUE;
  GC_COND_LOG_PRINTF("Abandoned stopped marking after %u iterations\n",
                     abandoned_at - 1);
  return FALSE;
}

#ifdef PARALLEL_MARK_DEADLINE
/*
 * Run a step of the collection in progress (see `steps_on()`): stop the
 * world, mark (in parallel if possible) until the mark stack is empty or,
 * unless `unlimited`, the time limit has passed since the world was
 * stopped, and restart the world.  Unlike `GC_stopped_mark()`, this reads
 * no dirty bits.  Return whether the mark stack is empty (a final mark
 * follows).
 */
STATIC GC_bool
GC_parallel_mark_step(GC_bool unlimited)
{
  ptr_t cold_gc_frame = GC_approx_sp();
  CLOCK_TYPE slice_start;
  GC_bool stack_empty = FALSE;
  unsigned long limit_ms, limit_ns;

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(GC_collection_in_progress());
  GC_ASSERT(steps_on());
  /* Builders of free lists read the mark bits outside the lock. */
  if (GC_parallel)
    GC_wait_for_reclaim();
  GET_TIME(slice_start);
#  ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_PRE_STOP_WORLD);
#  endif
  STOP_WORLD();
#  ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_POST_STOP_WORLD);
#    ifdef THREAD_LOCAL_ALLOC
  GC_world_stopped = TRUE;
#    endif
#  endif
  /*
   * The time limit counts from here, so that the step has it for marking
   * however long stopping the world took.
   */
  GET_TIME(GC_start_time);
  if (!unlimited) {
    current_time_limit(&limit_ms, &limit_ns);
    GC_set_mark_deadline(limit_ms, limit_ns);
  }
  /* Make progress even if `GC_timeout_stop_func()` returns true at once. */
  do {
    if (GC_mark_some(cold_gc_frame)) {
      stack_empty = TRUE;
      break;
    }
  } while (unlimited || !GC_timeout_stop_func());
  GC_clear_mark_deadline();
#  ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_PRE_START_WORLD);
#  endif
#  ifdef THREAD_LOCAL_ALLOC
  GC_world_stopped = FALSE;
#  endif
  START_WORLD();
#  ifdef THREADS
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_POST_START_WORLD);
#  endif
  log_timeout_stop();
  end_slice(slice_start, stack_empty ? SLICE_STACK_EMPTY : SLICE_CONTINUES);
  return stack_empty;
}
#endif

#if !defined(NO_FIND_LEAK) || defined(THREAD_LOCAL_ALLOC)
/*
 * In the manual VDB mode, also dirty the blocks of the objects: they stay
 * marked (only the global free lists are cleared), and one allocated from
 * the list is typically filled without a barrier, being new, so the next
 * minor collection must rescan it.
 */
GC_INNER void
GC_set_fl_marks(ptr_t q)
{
#  ifdef GC_ASSERTIONS
  ptr_t q2;
#  endif
  struct hblk *h = HBLKPTR(q);
  const struct hblk *last_h = h;
  hdr *hhdr;

  GC_ASSERT(q != NULL);
  hhdr = HDR(h);
#  ifndef NO_MANUAL_VDB
  if (GC_manual_vdb)
    GC_wbar_dirty(h);
#  endif
#  ifdef GC_ASSERTIONS
  q2 = (ptr_t)obj_link(q);
#  endif
  for (;;) {
    size_t bit_no = MARK_BIT_NO((size_t)((ptr_t)q - (ptr_t)h), hhdr->hb_sz);

    if (!mark_bit_from_hdr(hhdr, bit_no)) {
      set_mark_bit_from_hdr(hhdr, bit_no);
      INCR_MARKS(hhdr);
    }
    q = (ptr_t)obj_link(q);
    if (NULL == q)
      break;
#  ifdef GC_ASSERTIONS
    /*
     * Detect a cycle in the free list.  The algorithm is to have
     * a "twice faster" iterator over the list which meets the first
     * one in case of a cycle existing in the list.
     */
    if (q2 != NULL) {
      q2 = (ptr_t)obj_link(q2);
      GC_ASSERT(q2 != q);
      if (q2 != NULL) {
        q2 = (ptr_t)obj_link(q2);
        GC_ASSERT(q2 != q);
      }
    }
#  endif

    h = HBLKPTR(q);
    if (UNLIKELY(h != last_h)) {
      last_h = h;
      /* Update `hhdr`. */
      hhdr = HDR(h);
#  ifndef NO_MANUAL_VDB
      if (GC_manual_vdb)
        GC_wbar_dirty(h);
#  endif
    }
  }
}
#endif

#if defined(GC_ASSERTIONS) && defined(THREAD_LOCAL_ALLOC)
/*
 * Check that all mark bits for the free list, whose first entry is
 * `*pfreelist`, are set.  The check is skipped if `*pfreelist` points to
 * a special value.  Called with the world stopped, thus the owner thread
 * does not change the free list (an owner in `GC_do_blocking()` is not
 * stopped, but it does not allocate there, and it cannot return while
 * the allocator lock is held).  The failure is reported without
 * a formatted message, which might wait for a lock held by a stopped
 * thread (e.g. the locale lock on macOS).
 */
void
GC_check_fl_marks(void **pfreelist)
{
  /*
   * A thread sanitizer does not see every way of stopping the world
   * (e.g. `thread_suspend()` on macOS), and might report the walk as
   * a data race with the stores of the owner after the world is
   * restarted, thus the check is skipped then.
   */
#  ifndef THREAD_SANITIZER
  ptr_t p = GC_cptr_load((volatile ptr_t *)pfreelist);

  GC_ASSERT(GC_world_stopped);
  if (ADDR(p) <= HBLKSIZE)
    return;
  for (; p != NULL; p = (ptr_t)obj_link(p)) {
    if (!GC_is_marked(p))
      ABORT("Unmarked local free-list entry");
  }
#  else
  (void)pfreelist;
#  endif
}
#endif /* GC_ASSERTIONS && THREAD_LOCAL_ALLOC */

/*
 * The objects of a free list visited by `GC_clear_fl_marks()` between two
 * calls of its stop function.
 */
#define FL_CLEAR_CHECK 512

/*
 * Clear the mark bits of the free list starting at `*pq`, and its links if
 * `clear_links`, until the end of the list or until `stop_func` (if not
 * zero, called after every `FL_CLEAR_CHECK` objects) returns true.  Set
 * `*pq` to the first object not visited (`NULL` at the end).  Return the
 * number of bytes of the objects visited.
 */
STATIC word
GC_clear_fl_marks(ptr_t *pq, GC_bool clear_links, GC_stop_func stop_func)
{
  ptr_t q = *pq;
  struct hblk *h = HBLKPTR(q);
  const struct hblk *last_h = h;
  hdr *hhdr = HDR(h);
  size_t sz = hhdr->hb_sz; /*< normally set only once */
  word bytes = 0;
  unsigned n = 0;

  for (;;) {
    size_t bit_no = MARK_BIT_NO((size_t)((ptr_t)q - (ptr_t)h), sz);

    if (mark_bit_from_hdr(hhdr, bit_no)) {
      size_t n_marks = hhdr->hb_n_marks;

#ifdef LINT2
      if (0 == n_marks)
        ABORT("hhdr->hb_n_marks cannot be zero");
#else
      GC_ASSERT(n_marks != 0);
#endif
      clear_mark_bit_from_hdr(hhdr, bit_no);
      n_marks--;
#ifdef PARALLEL_MARK
      /* Approximate count, do not decrement to zero! */
      if (n_marks != 0 || !GC_APPROX_MARK_COUNTS()) {
        hhdr->hb_n_marks = n_marks;
      }
#else
      hhdr->hb_n_marks = n_marks;
#endif
    }
    bytes += sz;

    if (clear_links) {
      void **qp = &obj_link(q);

      q = (ptr_t)(*qp);
      *qp = NULL;
    } else {
      q = (ptr_t)obj_link(q);
    }
    if (NULL == q)
      break;
    if (UNLIKELY(++n >= FL_CLEAR_CHECK) && stop_func != 0) {
      n = 0;
      if ((*stop_func)())
        break;
    }

    h = HBLKPTR(q);
    if (UNLIKELY(h != last_h)) {
      last_h = h;
      /* Update `hhdr` and `sz`. */
      hhdr = HDR(h);
      sz = hhdr->hb_sz;
    }
  }
  *pq = q;
  return bytes;
}

#ifndef NO_FIND_LEAK
/* Mark all objects on the free lists for every object kind. */
static void
set_all_fl_marks(void)
{
  unsigned kind;

  for (kind = 0; kind < GC_n_kinds; kind++) {
    size_t lg;

    for (lg = 1; lg <= MAXOBJGRANULES; lg++) {
      ptr_t q = (ptr_t)GC_obj_kinds[kind].ok_freelist[lg];

      if (q != NULL)
        GC_set_fl_marks(q);
    }
  }
}
#endif

/*
 * Empty the free lists of the kinds in use, which the sweep rebuilds, in
 * one pass over each list: clear the mark bit of each object and, for the
 * kinds with a nonzero mark descriptor, its link.  The mark bits are
 * cleared in case they got accidentally marked (or `GC_find_leak` is set
 * and they were intentionally marked, or the objects are uncollectable
 * ones, marked while on a free list).  Note that composite objects on
 * free list are cleared, thus accidentally marking a free list is not
 * a problem; but some objects on the list itself might be marked, and the
 * sweep would not reclaim them.  The links are cleared since a dropped
 * object which waits for the sweep, or is not swept, would keep other
 * objects alive if a stale reference marked it.  The free lists of a kind
 * not in use (with no reclaim list) are kept, with their mark bits
 * cleared.  Return number of bytes on the free lists.
 */
static word
clear_free_lists(void)
{
  unsigned kind;
  word bytes = 0;

  for (kind = 0; kind < GC_n_kinds; kind++) {
    struct obj_kind *ok = &GC_obj_kinds[kind];
    GC_bool drop = ok->ok_reclaim_list != NULL;
    GC_bool clear_links = drop && ok->ok_descriptor != 0;
    size_t lg;

    for (lg = 1; lg <= MAXOBJGRANULES; lg++) {
      ptr_t q = (ptr_t)ok->ok_freelist[lg];

      if (q != NULL) {
        if (drop)
          ok->ok_freelist[lg] = NULL;
        bytes += GC_clear_fl_marks(&q, clear_links, (GC_stop_func)0);
      }
    }
  }
  return bytes;
}

GC_on_heap_resize_proc GC_on_heap_resize = 0;

/* Used for logging only. */
GC_INLINE int
GC_compute_heap_usage_percent(void)
{
  word used = GC_composite_in_use + GC_atomic_in_use + GC_bytes_allocd;
  word heap_sz = GC_heapsize - GC_unmapped_bytes;

  return used >= heap_sz            ? 0
         : used < GC_WORD_MAX / 100 ? (int)((used * 100) / heap_sz)
                                    : (int)(used / (heap_sz / 100));
}

#define GC_DBGLOG_PRINT_HEAP_IN_USE()                                        \
  GC_DBGLOG_PRINTF("In-use heap: %d%% (%lu KiB pointers + %lu KiB other)\n", \
                   GC_compute_heap_usage_percent(),                          \
                   TO_KiB_UL(GC_composite_in_use),                           \
                   TO_KiB_UL(GC_atomic_in_use + GC_bytes_allocd))

/*
 * The start of `GC_finish_collection()` and the end of its finalization,
 * for its log line.  Protected by the allocator lock.
 */
#ifndef NO_CLOCK
static CLOCK_TYPE finish_start_time;
static CLOCK_TYPE finish_finalize_time;
#endif

/*
 * Finish up a collection.  Assumes mark bits are consistent, but the
 * world is otherwise running.  The part after the finalization runs in
 * chunks if `finish_in_chunks()`.
 */
STATIC void
GC_finish_collection(void)
{
  GC_bool full = GC_is_full_gc;

  GC_ASSERT(I_HOLD_LOCK());

#ifndef NO_CLOCK
  if (GC_print_stats)
    GET_TIME(finish_start_time);
#endif
#ifdef USE_MUNMAP
  note_heap_need(full);
#endif
  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_RECLAIM_START);

#ifndef GC_GET_HEAP_USAGE_NOT_NEEDED
  if (GC_bytes_found > 0)
    GC_reclaimed_bytes_before_gc += (word)GC_bytes_found;
#endif
  GC_bytes_found = 0;
#if defined(LINUX) && defined(__ELF__) && !defined(SMALL_CONFIG)
  if (GETENV("GC_PRINT_ADDRESS_MAP") != NULL) {
    GC_print_address_map();
  }
#endif
  COND_DUMP;
#ifndef NO_FIND_LEAK
  if (GC_find_leak_inner) {
    set_all_fl_marks();
    /* This just checks; it does not really reclaim anything. */
    GC_start_reclaim(TRUE);
  }
#endif
#ifndef GC_NO_FINALIZATION
  GC_finalize();
  GC_after_marking();
#endif
#ifndef NO_CLOCK
  if (GC_print_stats)
    GET_TIME(finish_finalize_time);
#endif
#ifdef MAKE_BACK_GRAPH
  if (GC_print_back_height) {
    GC_traverse_back_graph();
  }
#endif

  /*
   * Reset or increment counters for next cycle: what is allocated from
   * now on counts for the next collection.
   */
  GC_n_attempts = 0;
#if !defined(NO_CLOCK) && !defined(GC_DISABLE_INCREMENTAL)
  n_final_abandoned = 0;
#endif
#ifdef PARALLEL_MARK_DEADLINE
  n_final_abandoned_at_bound = 0;
#endif
  GC_is_full_gc = FALSE;
  GC_bytes_allocd_before_gc += GC_bytes_allocd;
  GC_non_gc_bytes_at_gc = GC_non_gc_bytes;
  GC_bytes_allocd = 0;
  GC_bytes_dropped = 0;
  GC_bytes_freed = 0;
  GC_finalizer_bytes_freed = 0;

#ifdef PARALLEL_MARK_DEADLINE
  finish_timed = steps_on();
  if (finish_timed) {
    GET_TIME(rate_sample_time);
    rate_start_time = rate_sample_time;
    allocd_at_rate_sample = 0;
    allocd_at_rate_start = 0;
  }
  if (finish_in_chunks() && detach_free_lists()) {
    start_finish_chunks(full);
    /*
     * The first chunk follows at once if less than half of the time limit
     * has passed since the start of the mark that completed the marking
     * (`GC_start_time`, set if that mark had the time limit), and keeps the
     * rest of it.
     */
    if (half_limit_left(FALSE))
      run_finish_chunk(FALSE, TRUE);
    return;
  }
#endif
  /* Also update the counter of bytes of memory reclaimed. */
  GC_bytes_found -= (GC_signed_word)clear_free_lists();

  GC_VERBOSE_LOG_PRINTF("Bytes recovered before sweep - f.l. count = %ld\n",
                        (long)GC_bytes_found);

  /* Reconstruct free lists to contain everything not marked. */
  GC_start_reclaim(FALSE);
#ifndef NO_MANUAL_VDB
  if (GC_WBAR_SWEEPS_ALL())
    (void)GC_reclaim_all((GC_stop_func)0, FALSE);
#endif
#ifdef USE_MUNMAP
  if (UNMAP_ON()) {
    size_t index = 0;

    (void)unmap_old_blocks(&index, GC_never_stop_func);
  }
#endif
  finish_rest(full);
}

/*
 * The rest of `GC_finish_collection()` after the walk of the blocks: the
 * logging and the trigger of the next collection, for a full collection
 * if `full`.  The unmapping of the free blocks precedes it in a finish at
 * once, and follows it in a finish in chunks.
 */
static void
finish_rest(GC_bool full)
{
  GC_ASSERT(I_HOLD_LOCK());
#ifdef USE_MUNMAP
  GC_ASSERT(GC_heapsize >= GC_unmapped_bytes);
#endif
  GC_ASSERT(GC_our_mem_bytes >= GC_heapsize);
  GC_DBGLOG_PRINTF(
      "GC #%lu freed %ld bytes, heap %lu KiB (" IF_USE_MUNMAP(
          "+ %lu KiB unmapped ") "+ %lu KiB internal)\n",
      (unsigned long)GC_gc_no, (long)GC_bytes_found,
      TO_KiB_UL(GC_heapsize - GC_unmapped_bytes) /*, */
      COMMA_IF_USE_MUNMAP(TO_KiB_UL(GC_unmapped_bytes)),
      TO_KiB_UL(GC_our_mem_bytes - GC_heapsize + sizeof(GC_arrays)));
  GC_DBGLOG_PRINT_HEAP_IN_USE();
  if (GC_PRINT_STATS_FLAG && GC_alloc_budget_percent != 0) {
    word live = live_bytes();
    word volume = min_bytes_allocd();
    /*
     * The volume as a percentage of the live data (the effective budget),
     * rounded to the nearest integer.
     */
    word percent = live < 100 ? 0
                   : volume <= (GC_WORD_MAX - live / 2) / 100
                       ? (volume * 100 + live / 2) / live
                       : volume / (live / 100);

    GC_log_printf("Allocation volume %lu KiB (%lu%% of %lu KiB live),"
                  " heap target %lu KiB\n",
                  TO_KiB_UL(volume), (unsigned long)percent, TO_KiB_UL(live),
                  TO_KiB_UL(heap_target()));
  }
  if (full) {
    GC_used_heap_size_after_full = GC_heapsize - GC_large_free_bytes;
    GC_in_use_after_full = GC_composite_in_use + GC_atomic_in_use;
    GC_need_full_gc = FALSE;
  } else {
    /* The sum may overflow if `GC_alloc_budget_percent` is huge. */
    word min_allocd = min_bytes_allocd();

    GC_need_full_gc = GC_heapsize - GC_used_heap_size_after_full
                      > SIZET_SAT_ADD(min_allocd, GC_large_free_bytes);
    if (!GC_need_full_gc && GC_incremental) {
      /*
       * The marks of the old objects that died since the latest full
       * collection are cleared by a full one only: one is due once the
       * data in use after this collection, counted with the roots as in the
       * heap cap (see `live_bytes()`), exceed the heap cap.
       */
      word cap = heap_cap();

      GC_need_full_gc = cap != 0 && live_bytes() > cap;
    }
    if (!GC_need_full_gc && GC_gen_full_live_pct >= 0 && GC_incremental
        && GC_in_use_after_full != 0) {
      /*
       * A minor collection keeps the marks of the old objects, dead or
       * alive, thus the bytes in use grow by the dead old objects too.
       */
      word in_use = GC_composite_in_use + GC_atomic_in_use;

      GC_need_full_gc
          = in_use > SIZET_SAT_ADD(
                GC_in_use_after_full,
                percent_of(GC_in_use_after_full, (word)GC_gen_full_live_pct));
    }
  }

  if (GC_on_collection_event)
    GC_on_collection_event(GC_EVENT_RECLAIM_END);
#ifndef NO_CLOCK
  if (GC_print_stats) {
    CLOCK_TYPE done_time;

    GET_TIME(done_time);
#  if !defined(SMALL_CONFIG) && !defined(GC_NO_FINALIZATION)
    /* A convenient place to output finalization statistics. */
    GC_print_finalization_stats();
#  endif
    GC_log_printf(
        "Finalize and initiate sweep took %lu ms %lu ns + %lu ms %lu ns\n",
        MS_TIME_DIFF(finish_finalize_time, finish_start_time),
        NS_FRAC_TIME_DIFF(finish_finalize_time, finish_start_time),
        MS_TIME_DIFF(done_time, finish_finalize_time),
        NS_FRAC_TIME_DIFF(done_time, finish_finalize_time));
  }
#elif !defined(SMALL_CONFIG) && !defined(GC_NO_FINALIZATION)
  if (GC_print_stats)
    GC_print_finalization_stats();
#endif
}

/* Note: if `stop_func` is 0, then `GC_default_stop_func` is used instead. */
STATIC GC_bool
GC_try_to_collect_general(GC_stop_func stop_func, GC_bool force_unmap)
{
  GC_bool result;
#ifdef USE_MUNMAP
  unsigned old_unmap_threshold;
#endif
  IF_CANCEL(int cancel_state;)

  if (UNLIKELY(!GC_is_initialized))
    GC_init();
  if (GC_debugging_started)
    GC_print_all_smashed();
  GC_notify_or_invoke_finalizers();
  LOCK();
  if (force_unmap) {
    /*
     * Record current heap size to make heap growth more conservative
     * afterwards (as if the heap is growing from zero size again).
     */
    GC_heapsize_at_forced_unmap = GC_heapsize;
  }
  DISABLE_CANCEL(cancel_state);
#ifdef USE_MUNMAP
  old_unmap_threshold = GC_unmap_threshold;
  if (force_unmap || (GC_force_unmap_on_gcollect && old_unmap_threshold > 0)) {
    /* Unmap as much as possible. */
    GC_unmap_threshold = 1;
    unmap_all = TRUE;
  }
#endif
  /* Minimize junk left in my registers. */
  GC_noop6(0, 0, 0, 0, 0, 0);
  result = GC_try_to_collect_inner(stop_func != 0 ? stop_func
                                                  : GC_default_stop_func);
#ifdef USE_MUNMAP
  /* Restore them. */
  GC_unmap_threshold = old_unmap_threshold;
  unmap_all = FALSE;
#endif
  RESTORE_CANCEL(cancel_state);
  UNLOCK();
  if (result) {
    if (GC_debugging_started)
      GC_print_all_smashed();
    GC_notify_or_invoke_finalizers();
  }
  return result;
}

/* Externally callable routines to invoke full, stop-the-world collection. */

GC_API int GC_CALL
GC_try_to_collect(GC_stop_func stop_func)
{
  GC_ASSERT(NONNULL_ARG_NOT_NULL(stop_func));
  return (int)GC_try_to_collect_general(stop_func, FALSE);
}

GC_API void GC_CALL
GC_gcollect(void)
{
  /*
   * Zero is passed as stop_func to get `GC_default_stop_func` value
   * while holding the allocator lock (to prevent data race).
   */
  (void)GC_try_to_collect_general(0, FALSE);
  if (get_have_errors())
    GC_print_all_errors();
}

GC_API void GC_CALL
GC_gcollect_and_unmap(void)
{
  /* Collect and force memory unmapping to OS. */
  (void)GC_try_to_collect_general(GC_never_stop_func, TRUE);
}

STATIC GC_on_os_get_mem_proc GC_on_os_get_mem = 0;

GC_API void GC_CALL
GC_set_on_os_get_mem(GC_on_os_get_mem_proc fn)
{
  /* `fn` may be 0 (means no event notifier). */
  LOCK();
  GC_on_os_get_mem = fn;
  UNLOCK();
}

GC_API GC_on_os_get_mem_proc GC_CALL
GC_get_on_os_get_mem(void)
{
  GC_on_os_get_mem_proc fn;

  READER_LOCK();
  fn = GC_on_os_get_mem;
  READER_UNLOCK();
  return fn;
}

GC_INNER ptr_t
GC_os_get_mem(size_t bytes)
{
  ptr_t space;
#ifdef USE_PROC_FOR_LIBRARIES
  word i;
#endif

  GC_ASSERT(I_HOLD_LOCK());
  space = (ptr_t)GET_MEM(bytes); /*< `HBLKSIZE`-aligned */
  if (GC_on_os_get_mem)
    (*GC_on_os_get_mem)(space, bytes);
  if (UNLIKELY(NULL == space))
    return NULL;
#ifdef USE_PROC_FOR_LIBRARIES
  /*
   * Add `HBLKSIZE`-aligned `GET_MEM`-generated block to `GC_our_memory`,
   * extending the entry of a block that it adjoins, if any.  The system
   * maps most blocks directly below (`mmap`) or after (`sbrk`) an earlier
   * one, and an entry for every block, the chunks of the scratch memory
   * included, would use up the `MAX_HEAP_SECTS` entries long before the
   * heap reaches the size which they are meant for.
   */
  for (i = 0; i < GC_n_memory; i++) {
    if (ADDR(GC_our_memory[i].hs_start) + GC_our_memory[i].hs_bytes
        == ADDR(space)) {
      GC_our_memory[i].hs_bytes += bytes;
      break;
    }
    if (ADDR(space) + bytes == ADDR(GC_our_memory[i].hs_start)) {
      GC_our_memory[i].hs_start = space;
      GC_our_memory[i].hs_bytes += bytes;
      break;
    }
  }
  if (i == GC_n_memory) {
    if (GC_n_memory >= MAX_HEAP_SECTS)
      ABORT("Too many GC-allocated memory sections: Increase MAX_HEAP_SECTS");
    GC_our_memory[GC_n_memory].hs_start = space;
    GC_our_memory[GC_n_memory].hs_bytes = bytes;
    GC_n_memory++;
  }
#endif
  GC_our_mem_bytes += bytes;
  GC_VERBOSE_LOG_PRINTF("Got %lu bytes from OS\n", (unsigned long)bytes);
  return space;
}

/*
 * Use the chunk of memory starting at `h` of size `sz` as part of the heap.
 * Assumes `h` is `HBLKSIZE`-aligned, `sz` is a multiple of `HBLKSIZE`.
 */
STATIC void
GC_add_to_heap(struct hblk *h, size_t sz)
{
  hdr *hhdr;
  ptr_t endp;
  size_t old_capacity = 0;
  void *old_heap_sects = NULL;
#ifdef GC_ASSERTIONS
  size_t i;
#endif

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(ADDR(h) % HBLKSIZE == 0);
  GC_ASSERT(sz % HBLKSIZE == 0);
  GC_ASSERT(sz > 0);
  GC_ASSERT(GC_all_nils != NULL);

  if (UNLIKELY(GC_n_heap_sects == GC_capacity_heap_sects)) {
    /* Allocate new `GC_heap_sects` with sufficient capacity. */
#ifndef INITIAL_HEAP_SECTS
#  define INITIAL_HEAP_SECTS 32
#endif
    size_t new_capacity
        = GC_n_heap_sects > 0 ? GC_n_heap_sects * 2 : INITIAL_HEAP_SECTS;
    void *new_heap_sects
        = GC_scratch_alloc(new_capacity * sizeof(struct HeapSect));

    if (NULL == new_heap_sects) {
      /* Retry with smaller yet sufficient capacity. */
      new_capacity = GC_n_heap_sects + INITIAL_HEAP_SECTS;
      new_heap_sects
          = GC_scratch_alloc(new_capacity * sizeof(struct HeapSect));
      if (NULL == new_heap_sects)
        ABORT("Insufficient memory for heap sections");
    }
    old_capacity = GC_capacity_heap_sects;
    old_heap_sects = GC_heap_sects;
    /* Transfer `GC_heap_sects` contents to the newly allocated array. */
    if (GC_n_heap_sects > 0)
      BCOPY(old_heap_sects, new_heap_sects,
            GC_n_heap_sects * sizeof(struct HeapSect));
    GC_capacity_heap_sects = new_capacity;
    GC_heap_sects = (struct HeapSect *)new_heap_sects;
    GC_COND_LOG_PRINTF("Grew heap sections array to %lu elements\n",
                       (unsigned long)new_capacity);
  }

  while (UNLIKELY(ADDR(h) <= HBLKSIZE)) {
    /* Cannot handle memory near address zero. */
    ++h;
    sz -= HBLKSIZE;
    if (0 == sz)
      return;
  }
  while (UNLIKELY(ADDR(h) >= GC_WORD_MAX - sz)) {
    /* Prevent overflow when calculating `endp`. */
    sz -= HBLKSIZE;
    if (0 == sz)
      return;
  }
  endp = (ptr_t)h + sz;

  hhdr = GC_install_header(h);
  if (UNLIKELY(NULL == hhdr)) {
    /*
     * This is extremely unlikely. Cannot add it.  This will almost
     * certainly result in a `NULL` returned from the allocator, which
     * is entirely appropriate.
     */
    return;
  }
#ifdef GC_ASSERTIONS
  /* Ensure no intersection between sections. */
  for (i = 0; i < GC_n_heap_sects; i++) {
    ptr_t hs_start = GC_heap_sects[i].hs_start;
    ptr_t hs_end = hs_start + GC_heap_sects[i].hs_bytes;

    GC_ASSERT(!(ADDR_INSIDE((ptr_t)h, hs_start, hs_end)
                || (ADDR_LT(hs_start, endp) && ADDR_GE(hs_end, endp))
                || (ADDR_LT((ptr_t)h, hs_start) && ADDR_LT(hs_end, endp))));
  }
#endif
#ifdef UFFDWP_VDB
  GC_dirty_add_heap_sect((ptr_t)h, sz);
#endif
  GC_heap_sects[GC_n_heap_sects].hs_start = (ptr_t)h;
  GC_heap_sects[GC_n_heap_sects].hs_bytes = sz;
  GC_n_heap_sects++;
  hhdr->hb_block = h;
  hhdr->hb_sz = sz;
  hhdr->hb_flags = 0;
  GC_freehblk(h);
  GC_heapsize += sz;

  if (ADDR_GE((ptr_t)GC_least_plausible_heap_addr, (ptr_t)h)
      || UNLIKELY(NULL == GC_least_plausible_heap_addr)) {
    /*
     * Making it a little smaller than necessary prevents us from
     * getting a false hit from the variable itself.  There is some
     * unintentional reflection here.
     */
    GC_least_plausible_heap_addr = (ptr_t)h - sizeof(ptr_t);
  }
  if (ADDR_LT((ptr_t)GC_greatest_plausible_heap_addr, endp)) {
    GC_greatest_plausible_heap_addr = endp;
  }
#ifdef SET_REAL_HEAP_BOUNDS
  if (ADDR(h) < GC_least_real_heap_addr
      || UNLIKELY(0 == GC_least_real_heap_addr))
    GC_least_real_heap_addr = ADDR(h) - sizeof(ptr_t);
  if (GC_greatest_real_heap_addr < ADDR(endp)) {
#  ifdef INCLUDE_LINUX_THREAD_DESCR
    /* Avoid heap intersection with the static data roots. */
    GC_exclude_static_roots_inner((ptr_t)h, endp);
#  endif
    GC_greatest_real_heap_addr = ADDR(endp);
  }
#endif
  GC_handle_protected_regions_limit();
  if (UNLIKELY(old_capacity > 0)) {
#ifndef GWW_VDB
    /*
     * Recycling may call `GC_add_to_heap()` again but should not cause
     * resizing of `GC_heap_sects`.
     */
    GC_scratch_recycle_no_gww(old_heap_sects,
                              old_capacity * sizeof(struct HeapSect));
#else
    /* TODO: Implement GWW-aware recycling as in `alloc_mark_stack`. */
    GC_noop1_ptr(old_heap_sects);
#endif
  }
}

#ifndef NO_DEBUGGING
void
GC_print_heap_sects(void)
{
  size_t i;

  GC_printf("Total heap size: %lu" IF_USE_MUNMAP(" (%lu unmapped)") "\n",
            (unsigned long)GC_heapsize /*, */
                COMMA_IF_USE_MUNMAP((unsigned long)GC_unmapped_bytes));

  for (i = 0; i < GC_n_heap_sects; i++) {
    ptr_t start = GC_heap_sects[i].hs_start;
    size_t len = GC_heap_sects[i].hs_bytes;
    unsigned nbl = 0;
#  ifndef NO_BLACK_LISTING
    struct hblk *h;

    for (h = (struct hblk *)start; ADDR_LT((ptr_t)h, start + len); h++) {
      if (GC_is_black_listed(h, HBLKSIZE))
        nbl++;
    }
#  endif
    GC_printf("Section %u from %p to %p %u/%lu blacklisted\n", (unsigned)i,
              (void *)start, (void *)&start[len], nbl,
              (unsigned long)divHBLKSZ(len));
  }
}
#endif /* !NO_DEBUGGING */

void *GC_least_plausible_heap_addr = MAKE_CPTR(GC_WORD_MAX);
void *GC_greatest_plausible_heap_addr = NULL;

STATIC word GC_max_heapsize = 0;

GC_API void GC_CALL
GC_set_max_heap_size(GC_word n)
{
  GC_max_heapsize = n;
}

word GC_max_retries = 0;

GC_INNER void
GC_scratch_recycle_inner(void *ptr, size_t sz)
{
  size_t align, page_offset;
  size_t displ = 0;
  size_t recycled_bytes;

  GC_ASSERT(I_HOLD_LOCK());
  if (NULL == ptr)
    return;

  GC_ASSERT(sz != 0);
  GC_ASSERT(GC_page_size != 0);
  /*
   * The recycled region should be aligned both by `HBLKSIZE` and page
   * size, and its size should be a multiple of both.
   */
  align = HBLK_PAGE_SIZE;
  /* TODO: Assert correct memory flags if `GWW_VDB`. */
  page_offset = ADDR(ptr) & (align - 1);
  if (page_offset != 0)
    displ = align - page_offset;
  recycled_bytes = sz > displ ? (sz - displ) & ~(align - 1) : 0;
  GC_COND_LOG_PRINTF("Recycle %lu/%lu scratch-allocated bytes at %p\n",
                     (unsigned long)recycled_bytes, (unsigned long)sz, ptr);
  if (recycled_bytes > 0)
    GC_add_to_heap((struct hblk *)((ptr_t)ptr + displ), recycled_bytes);
}

#ifdef GC_HEAP_GROWTH_DIVISOR
STATIC word GC_heap_growth_divisor = GC_HEAP_GROWTH_DIVISOR;
#else
/* Zero means the maximum heap increment does not depend on heap size. */
STATIC word GC_heap_growth_divisor = 0;
#endif

GC_API void GC_CALL
GC_set_heap_growth_divisor(GC_word value)
{
  GC_heap_growth_divisor = value;
}

GC_API GC_word GC_CALL
GC_get_heap_growth_divisor(void)
{
  return GC_heap_growth_divisor;
}

/*
 * Return the maximum number of blocks by which the heap is expanded
 * beyond the current request.  This is the larger of `MAXHINCR` and the
 * heap size (not counting the part present at the latest forced
 * unmapping) divided by `GC_heap_growth_divisor` (unless the latter is
 * zero).
 */
static word
max_heap_increment(void)
{
  /* Read once: the setter does not acquire the allocator lock. */
  word divisor = GC_heap_growth_divisor;
  word blocks;

  GC_ASSERT(I_HOLD_LOCK());
  if (0 == divisor)
    return MAXHINCR;
  blocks = divHBLKSZ(GC_heapsize - GC_heapsize_at_forced_unmap) / divisor;
  return blocks > MAXHINCR ? blocks : MAXHINCR;
}

GC_INNER GC_bool
GC_expand_hp_inner(word n)
{
  size_t sz;
  struct hblk *space;
  /* Number of bytes by which we expect the heap to expand soon. */
  word expansion_slop, min_allocd, max_increment;

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(GC_page_size != 0);
  if (0 == n)
    n = 1;
  sz = ROUNDUP_PAGESIZE((size_t)n * HBLKSIZE);
  GC_DBGLOG_PRINT_HEAP_IN_USE();
  if (GC_max_heapsize != 0
      && (GC_max_heapsize < (word)sz
          || GC_heapsize > GC_max_heapsize - (word)sz)) {
    /* Exceeded the self-imposed limit. */
    return FALSE;
  }
  space = (struct hblk *)GC_os_get_mem(sz);
  if (UNLIKELY(NULL == space)) {
    WARN("Failed to expand heap by %" WARN_PRIuPTR " KiB\n", sz >> 10);
    return FALSE;
  }
  GC_last_heap_growth_gc_no = GC_gc_no;
  GC_INFOLOG_PRINTF("Grow heap to %lu KiB after %lu bytes allocated\n",
                    TO_KiB_UL(GC_heapsize + sz),
                    (unsigned long)GC_bytes_allocd);

  /*
   * Adjust heap limits generously for black-listing to work better.
   * `GC_add_to_heap()` performs minimal adjustment needed for correctness.
   */
  min_allocd = min_bytes_allocd();
  max_increment = max_heap_increment();
  expansion_slop = max_increment <= divHBLKSZ(GC_WORD_MAX) / 4
                       ? 4 * max_increment * HBLKSIZE
                       : GC_WORD_MAX;
  expansion_slop = SIZET_SAT_ADD(expansion_slop, min_allocd);
  if ((0 == GC_last_heap_addr && (ADDR(space) & SIGNB) == 0)
      || (GC_last_heap_addr != 0 && GC_last_heap_addr < ADDR(space))) {
    /* Assume the heap is growing up. */
    if (LIKELY(expansion_slop < GC_WORD_MAX - sz)
        && LIKELY(ADDR(space) < GC_WORD_MAX - sz - expansion_slop)) {
      ptr_t new_limit = (ptr_t)space + sz + expansion_slop;

      if (ADDR_LT((ptr_t)GC_greatest_plausible_heap_addr, new_limit))
        GC_greatest_plausible_heap_addr = new_limit;
    }
  } else {
    /* Heap is growing down. */
    if (LIKELY(ADDR(space) > SIZET_SAT_ADD(expansion_slop, sizeof(ptr_t)))) {
      ptr_t new_limit = (ptr_t)space - expansion_slop - sizeof(ptr_t);

      if (ADDR_LT(new_limit, (ptr_t)GC_least_plausible_heap_addr))
        GC_least_plausible_heap_addr = new_limit;
    }
  }
  GC_last_heap_addr = ADDR(space);

  GC_add_to_heap(space, sz);
  if (GC_on_heap_resize)
    (*GC_on_heap_resize)(GC_heapsize);

  return TRUE;
}

GC_API int GC_CALL
GC_expand_hp(size_t bytes)
{
  size_t n_blocks = OBJ_SZ_TO_BLOCKS_CHECKED(bytes);
#ifndef NO_WARN_HEAP_GROW_WHEN_GC_DISABLED
  word old_heapsize;
#endif
  GC_bool result;

  if (UNLIKELY(!GC_is_initialized))
    GC_init();
  LOCK();
#ifndef NO_WARN_HEAP_GROW_WHEN_GC_DISABLED
  old_heapsize = GC_heapsize;
#endif
  result = GC_expand_hp_inner(n_blocks);
  if (result) {
    GC_requested_heapsize += bytes;
#ifndef NO_WARN_HEAP_GROW_WHEN_GC_DISABLED
    if (GC_dont_gc) {
      /* Do not call `WARN()` if the heap growth is intentional. */
      GC_ASSERT(GC_heapsize >= old_heapsize);
      GC_heapsize_on_gc_disable += GC_heapsize - old_heapsize;
    }
#endif
  }
  UNLOCK();
  /*
   * Really returns a `GC_bool` value, but the function is externally
   * visible, so that is clumsy.
   */
  return (int)result;
}

/*
 * The minimum value of the ratio of allocated bytes since the latest
 * collection to the amount of finalizers created since that collection
 * which triggers the collection instead heap expansion.  Has no effect
 * in the incremental mode.
 */
#ifdef GC_ALLOCD_BYTES_PER_FINALIZER
STATIC word GC_allocd_bytes_per_finalizer = GC_ALLOCD_BYTES_PER_FINALIZER;
#else
STATIC word GC_allocd_bytes_per_finalizer = 10000;
#endif

GC_API void GC_CALL
GC_set_allocd_bytes_per_finalizer(GC_word value)
{
  GC_allocd_bytes_per_finalizer = value;
}

GC_API GC_word GC_CALL
GC_get_allocd_bytes_per_finalizer(void)
{
  return GC_allocd_bytes_per_finalizer;
}

/*
 * Return the number of blocks to get from the OS to satisfy a request
 * of `needed_blocks` blocks, if the expansion beyond the request is
 * limited by `max_increment` blocks.  `GC_max_heapsize` is not taken
 * into account.
 */
static word
heap_expansion_blocks(word needed_blocks, unsigned flags, word max_increment)
{
  word blocks_to_get;

  GC_ASSERT(I_HOLD_LOCK());
  /* Divide separately to avoid overflow for a huge free-space divisor. */
  blocks_to_get = divHBLKSZ(GC_heapsize - GC_heapsize_at_forced_unmap)
                      / GC_free_space_divisor
                  + needed_blocks;
  if (blocks_to_get > max_increment) {
#ifdef NO_BLACK_LISTING
    UNUSED_ARG(flags);
    blocks_to_get
        = needed_blocks > max_increment ? needed_blocks : max_increment;
#else
    word slop;

    /*
     * Get the minimum required to make it likely that we can satisfy
     * the current request in the presence of black-listing.  This will
     * probably be bigger than `max_increment`.
     */
    if ((flags & IGNORE_OFF_PAGE) != 0) {
      slop = 4;
    } else {
      slop = 2 * divHBLKSZ(BL_LIMIT);
      if (slop > needed_blocks)
        slop = needed_blocks;
    }
    if (needed_blocks + slop > max_increment) {
      blocks_to_get = needed_blocks + slop;
    } else {
      blocks_to_get = max_increment;
    }
#endif
    if (blocks_to_get > divHBLKSZ(GC_WORD_MAX))
      blocks_to_get = divHBLKSZ(GC_WORD_MAX);
  } else if (blocks_to_get < MINHINCR) {
    blocks_to_get = MINHINCR;
  }
  return blocks_to_get;
}

/*
 * Return the number of blocks to get from the OS to satisfy a request
 * of `needed_blocks` blocks if the heap is sized by the memory limit:
 * enough to reach the heap target of `target` bytes, at least the
 * request plus the slop for the black-listing, and at least
 * `BUDGET_FLOOR_PERCENT` of the live data and `MINHINCR`.  The latter
 * keeps the number of heap growths (and of heap sections) logarithmic
 * in the live data size, and, since a shortage of blocks after a heap
 * growth triggers a collection, the volume between collections at that
 * percentage at least.  `GC_max_heapsize` is not taken into account.
 */
static word
target_expansion_blocks(word target, word needed_blocks, unsigned flags)
{
  word heap_blocks = divHBLKSZ(GC_heapsize);
  word target_blocks = divHBLKSZ(target);
  word min_blocks = divHBLKSZ(percent_of(live_bytes(), BUDGET_FLOOR_PERCENT));
  word blocks_to_get
      = heap_expansion_blocks(needed_blocks, flags, needed_blocks);

  if (target_blocks > heap_blocks
      && target_blocks - heap_blocks > blocks_to_get)
    blocks_to_get = target_blocks - heap_blocks;
  if (blocks_to_get < min_blocks)
    blocks_to_get = min_blocks;
  return blocks_to_get > MINHINCR ? blocks_to_get : MINHINCR;
}

/*
 * Tell whether the heap with `needed_blocks` more blocks would exceed the
 * heap target of `target` bytes after at least half of the allocation
 * volume, and at least `BUDGET_FLOOR_PERCENT` of the live data, has been
 * allocated since the latest collection.  Then a collection is due
 * instead of a heap growth.  Before that, the heap grows, so that free
 * space which the allocation cannot use (in partly used blocks of other
 * object sizes, or in runs of free blocks too short for the request, e.g.
 * for large objects in a fragmented heap) does not make the collections
 * more frequent.
 */
static GC_bool
exceeds_heap_target(word target, word needed_blocks)
{
  word wait, min_wait;

  if (divHBLKSZ(GC_heapsize) + needed_blocks <= divHBLKSZ(target))
    return FALSE;
  wait = min_bytes_allocd() / 2;
  min_wait = percent_of(live_bytes(), BUDGET_FLOOR_PERCENT);
  return GC_adj_bytes_allocd() >= (wait > min_wait ? wait : min_wait);
}

#ifdef USE_MUNMAP
/*
 * Unmap every free block before the heap grows.  If the finish of a
 * collection runs in chunks, then the unmapping stops after the time
 * limit, as a chunk of the finish does, and the blocks left stay mapped.
 */
static void
unmap_before_growth(void)
{
  GC_stop_func stop_func = GC_never_stop_func;
  size_t index = 0;

#  ifdef PARALLEL_MARK_DEADLINE
  if (finish_in_chunks()) {
    GET_TIME(unmap_start_time);
    stop_func = unmap_stop_func;
  }
#  endif
  (void)GC_unmap_old(0, 0, &index, stop_func);
}
#endif

GC_INNER GC_bool
GC_collect_or_expand(word needed_blocks, unsigned flags, GC_bool retry)
{
  static word last_fo_entries, last_bytes_finalized;

  GC_bool gc_not_stopped = TRUE;
  word blocks_to_get, fallback_blocks, max_increment, target;
  IF_CANCEL(int cancel_state;)

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(GC_is_initialized);
  DISABLE_CANCEL(cancel_state);
  target = heap_target();
  /*
   * If `exceeds_heap_target()` holds (the heap with the requested blocks
   * would exceed the heap target, after the wait), then the first attempt
   * collects instead of growing the heap, and a retry grows it.  Thus
   * a request causes one collection at most before the heap grows.
   */
  if (!GC_incremental && !GC_dont_gc
      && ((GC_dont_expand && GC_bytes_allocd > 0)
          || (GC_fo_entries > last_fo_entries
              && (last_bytes_finalized | GC_bytes_finalized) != 0
              && (GC_fo_entries - last_fo_entries)
                         * GC_allocd_bytes_per_finalizer
                     > GC_bytes_allocd)
          || GC_should_collect()
          || (target != 0 && !retry && GC_bytes_allocd > 0
              && exceeds_heap_target(target, needed_blocks)))) {
    /*
     * Try to do a full collection using "default" `stop_func` (unless
     * nothing has been allocated since the latest collection or heap
     * expansion is disabled).
     */
    gc_not_stopped = GC_try_to_collect_inner(
        GC_bytes_allocd > 0 && (!GC_dont_expand || !retry)
            ? GC_default_stop_func
            : GC_never_stop_func);
    if (gc_not_stopped || !retry) {
      /*
       * Either the collection has not been aborted or this is the
       * first attempt (in a loop).
       */
      last_fo_entries = GC_fo_entries;
      last_bytes_finalized = GC_bytes_finalized;
      RESTORE_CANCEL(cancel_state);
      return TRUE;
    }
  }

  /*
   * Without a time limit, outside the manual VDB mode (see `steps_on()`),
   * a collection is marked in one world-stopped mark, and a marking is in
   * progress only if a stop function abandoned that mark (or the time
   * limit was lifted during the marking).  The allocation advances such
   * a marking only in its calls of `GC_collect_a_little_inner()` (`GC_rate`
   * units of `GC_mark_some()` per block), and every shortage of blocks
   * until it completes would grow the heap.  Thus the first attempt
   * completes the marking instead, and the caller retries the allocation,
   * which may grow the heap.  If the stop function of the client
   * (`GC_default_stop_func`) stops the completion, then the marking stays
   * in progress, and the heap grows below.
   */
  if (GC_incremental && GC_time_limit == GC_TIME_UNLIMITED && !GC_manual_vdb
      && !GC_dont_gc && !retry && GC_collection_in_progress()
      && GC_complete_marking(GC_default_stop_func, 1)) {
    RESTORE_CANCEL(cancel_state);
    return TRUE;
  }

  max_increment = max_heap_increment();
  blocks_to_get
      = target != 0
            ? target_expansion_blocks(target, needed_blocks, flags)
            : heap_expansion_blocks(needed_blocks, flags, max_increment);
  /*
   * If a scaled expansion is refused by the OS, then try the size which
   * the fixed `MAXHINCR` limit would give, before falling back to the
   * requested size.
   */
  fallback_blocks = max_increment > MAXHINCR
                        ? heap_expansion_blocks(needed_blocks, flags, MAXHINCR)
                        : needed_blocks;

  if (GC_max_heapsize > GC_heapsize) {
    word max_get_blocks = divHBLKSZ(GC_max_heapsize - GC_heapsize);
    if (blocks_to_get > max_get_blocks)
      blocks_to_get
          = max_get_blocks > needed_blocks ? max_get_blocks : needed_blocks;
  }

#ifdef USE_MUNMAP
  /*
   * Return as much memory to the OS as possible before trying to get
   * memory from it, unless an incremental collection is marking: its mark
   * stack may hold ranges of objects freed explicitly since they were
   * pushed (e.g. the old object of a `GC_realloc`), and the next step
   * would read their unmapped blocks.
   */
  if (GC_unmap_threshold > 1 && !GC_collection_in_progress())
    unmap_before_growth();
#endif
  if (!GC_expand_hp_inner(blocks_to_get)
      && (fallback_blocks >= blocks_to_get || fallback_blocks == needed_blocks
          || !GC_expand_hp_inner(fallback_blocks))
      && (blocks_to_get == needed_blocks
          || !GC_expand_hp_inner(needed_blocks))) {
    if (!gc_not_stopped) {
      /* Do not increment `GC_alloc_fail_count` here (and no warning). */
      GC_gcollect_inner();
      GC_ASSERT(0 == GC_bytes_allocd);
    } else if (GC_bytes_allocd > 0 && !GC_dont_gc
               && !GC_disable_automatic_collection) {
      /*
       * The heap cannot grow (e.g. because of `GC_max_heapsize`), but no
       * collection has been attempted above (because the allocation
       * volume which triggers the next one has not been reached yet, or
       * in the incremental mode).  Collect now rather than fail (or count
       * it as a failure).  The next attempt (if any) proceeds as before
       * unless something is allocated in between.
       */
      GC_gcollect_inner();
      GC_ASSERT(0 == GC_bytes_allocd);
    } else if (GC_alloc_fail_count++ < GC_max_retries) {
      WARN("Out of Memory!  Trying to continue...\n", 0);
      GC_gcollect_inner();
    } else {
#ifdef USE_MUNMAP
      GC_ASSERT(GC_heapsize >= GC_unmapped_bytes);
#endif
#if !defined(SMALL_CONFIG) && (CPP_WORDSZ >= 32)
#  define MAX_HEAPSIZE_WARNED_IN_BYTES (5 << 20) /*< 5 MB */

      if (GC_heapsize > (word)MAX_HEAPSIZE_WARNED_IN_BYTES) {
        WARN("Out of Memory! Heap size: %" WARN_PRIuPTR " MiB."
             " Returning NULL!\n",
             (GC_heapsize - GC_unmapped_bytes) >> 20);
      } else
#endif
      /* else */ {
        WARN("Out of Memory! Heap size: %" WARN_PRIuPTR " bytes."
             " Returning NULL!\n",
             GC_heapsize - GC_unmapped_bytes);
      }
      RESTORE_CANCEL(cancel_state);
      return FALSE;
    }
  } else if (GC_alloc_fail_count > 0) {
    GC_COND_LOG_PRINTF("Memory available again...\n");
  }
  RESTORE_CANCEL(cancel_state);
  return TRUE;
}

GC_INNER ptr_t
GC_allocobj(size_t lg, int kind)
{
#define MAX_ALLOCOBJ_RETRIES 3
  int retry_cnt = 0;
  void **flh;
#ifndef GC_DISABLE_INCREMENTAL
  GC_bool tried_minor = FALSE;
#endif

  GC_ASSERT(I_HOLD_LOCK());
  GC_ASSERT(GC_is_initialized);
  if (UNLIKELY(0 == lg))
    return NULL;
  GC_ASSERT(lg <= MAXOBJGRANULES);

  flh = &GC_obj_kinds[kind].ok_freelist[lg];
  while (NULL == *flh) {
    /*
     * Only a few iterations are expected at most, otherwise something
     * is wrong in one of the functions called below.
     */
    if (retry_cnt > MAX_ALLOCOBJ_RETRIES)
      ABORT("Too many retries in GC_allocobj");
#ifndef GC_DISABLE_INCREMENTAL
    if (GC_incremental && GC_time_limit != GC_TIME_UNLIMITED && !GC_dont_gc) {
      /*
       * True incremental mode, not just generational.
       * Do our share of marking work.
       */
      GC_collect_a_little_inner(1);
    }
#endif
    /* Sweep blocks for objects of this size. */
    GC_ASSERT(!GC_is_full_gc || NULL == GC_obj_kinds[kind].ok_reclaim_list
              || NULL == GC_obj_kinds[kind].ok_reclaim_list[lg]);
    GC_continue_reclaim(lg, kind);
#if defined(CPPCHECK)
    GC_noop1_ptr(&flh);
#endif
    if (*flh != NULL)
      break;

    GC_new_hblk(lg, kind);
#if defined(CPPCHECK)
    GC_noop1_ptr(&flh);
#endif
    if (*flh != NULL)
      break;

#ifndef GC_DISABLE_INCREMENTAL
    if (GC_incremental && GC_time_limit == GC_TIME_UNLIMITED && !tried_minor
        && !GC_dont_gc) {
      GC_collect_a_little_inner(1);
      tried_minor = TRUE;
      continue;
    }
#endif
    if (UNLIKELY(!GC_collect_or_expand(1, 0 /* `flags` */, retry_cnt > 0)))
      return NULL;
    retry_cnt++;
  }
  /* Successful allocation; reset failure count. */
  GC_alloc_fail_count = 0;
  return (ptr_t)(*flh);
}
