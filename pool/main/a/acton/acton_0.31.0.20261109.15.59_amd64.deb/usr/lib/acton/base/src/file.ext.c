#define GC_THREADS 1
#include "gc.h"

#include <stdio.h>
#include <string.h>
#include <sys/file.h>

#include <uv.h>
#include "../rts/io.h"
#include "../rts/log.h"
#include "../out/types/file.h"

static struct B_ValueError fileQ_path_nul_error =
    STATIC_EXCEPTION(B_ValueError, "path contains a NUL byte");


void fileQ___ext_init__() {

}

$R fileQ_FSD__pin_affinityG_local (fileQ_FS self, $Cont c$cont) {
    pin_actor_affinity();
    return $R_CONT(c$cont, B_None);
}

// def is_dir(self) -> bool:
bool fileQ_FileStatD_is_dir (fileQ_FileStat self) {
    return S_ISDIR(self->mode);
}

// def is_file(self) -> bool:
bool fileQ_FileStatD_is_file (fileQ_FileStat self) {
    return S_ISREG(self->mode);
}

// def is_symlink(self) -> bool:
bool fileQ_FileStatD_is_symlink (fileQ_FileStat self) {
#if defined(_WIN32) || defined(_WIN64)
    // TODO: do better
    return false;
#else
    return S_ISLNK(self->mode);
#endif
}

// def is_block_device(self) -> bool:
bool fileQ_FileStatD_is_block_device (fileQ_FileStat self) {
    return S_ISBLK(self->mode);
}

// def is_char_device(self) -> bool:
bool fileQ_FileStatD_is_char_device (fileQ_FileStat self) {
    return S_ISCHR(self->mode);
}

// def is_fifo(self) -> bool:
bool fileQ_FileStatD_is_fifo (fileQ_FileStat self) {
#if defined(_WIN32) || defined(_WIN64)
    // TODO: do better
    return false;
#else
    return S_ISFIFO(self->mode);
#endif
}

// def is_socket(self) -> bool:
bool fileQ_FileStatD_is_socket (fileQ_FileStat self) {
#if defined(_WIN32) || defined(_WIN64)
    // TODO: do better
    return false;
#else
    return S_ISSOCK(self->mode);
#endif
}

// Every uv_fs call in this file is synchronous (NULL callback): libuv runs it
// in the calling thread and keeps no pointer to the request once it returns,
// so the requests live on the C stack.

// action def copyfile(src: str, dst: str) -> None:
$R fileQ_FSD_copyfileG_local (fileQ_FS self, $Cont C_cont, B_str src, B_str dst) {
    uv_fs_t req;
    int r = uv_fs_copyfile(get_uv_loop(), &req, actStrToCString(src, &fileQ_path_nul_error), actStrToCString(dst, &fileQ_path_nul_error), 0, NULL);
    if (r < 0) {
        char errmsg[1024] = "Error copying file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, B_None);
}

// action def cwd() -> str:
$R fileQ_FSD_cwdG_local (fileQ_FS self, $Cont C_cont) {
    char cwd[1024];
    size_t size = sizeof(cwd);
    int r = uv_cwd(cwd, &size);
    if (r < 0) {
        char errmsg[1024] = "Error getting cwd: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    return $R_CONT(C_cont, actStrFromCStringCopy(cwd));
}

// action def exepath() -> str:
$R fileQ_FSD_exepathG_local (fileQ_FS self, $Cont C_cont) {
    char exepath[1024];
    size_t size = sizeof(exepath);
    int r = uv_exepath(exepath, &size);
    if (r < 0) {
        char errmsg[1024] = "Error getting exepath: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    return $R_CONT(C_cont, actStrFromCStringCopy(exepath));
}

// action def homedir() -> str:
$R fileQ_FSD_homedirG_local (fileQ_FS self, $Cont C_cont) {
    char homedir[1024];
    size_t size = sizeof(homedir);
    int r = uv_os_homedir(homedir, &size);
    if (r < 0) {
        char errmsg[1024] = "Error getting homedir: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    return $R_CONT(C_cont, actStrFromCStringCopy(homedir));
}

// action def mkdir(filename: str):
$R fileQ_FSD_mkdirG_local (fileQ_FS self, $Cont C_cont, B_str filename) {
    uv_fs_t req;
    int r = uv_fs_mkdir(get_uv_loop(), &req, actStrToCString(filename, &fileQ_path_nul_error), 0777, NULL);
    if (r < 0 && r != UV_EEXIST) {
        char errmsg[1024] = "Error creating directory: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, B_None);
}

// action def mktmpdir(prefix: str=""):
$R fileQ_FSD_mktmpdirG_local (fileQ_FS self, $Cont C_cont, B_str prefix) {
    uv_fs_t req;
    size_t size = 128;
    char *tmpdir;
    int r;

    while (1) {
        tmpdir = (char *)acton_malloc(size);
        size_t requested = size;
        r = uv_os_tmpdir(tmpdir, &requested);
        if (r == UV_ENOBUFS) {
            size = requested;
            continue;
        }
        if (r < 0) {
            char errmsg[1024] = "Error getting temporary directory: ";
            uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
            log_warn(errmsg);
            RAISE(B_OSError, actStrFromCStringCopy(errmsg));
        }
        break;
    }

    const char *cprefix = prefix == B_None ? "" : actStrToCString(prefix, &fileQ_path_nul_error);
    size_t template_size = strlen(tmpdir) + 1 + strlen(cprefix) + 6 + 1;
    char *tpl = (char *)acton_malloc(template_size);
    snprintf(tpl, template_size, "%s/%sXXXXXX", tmpdir, cprefix);

    r = uv_fs_mkdtemp(get_uv_loop(), &req, tpl, NULL);
    if (r < 0) {
        char errmsg[1024] = "Error creating temporary directory: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }

    // libuv stores the resolved path in req.path, not in the template buffer.
    B_str path = actStrFromCStringCopy(req.path);
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, path);
}

// action def listdir(path: str) -> list[str]:
$R fileQ_FSD_listdirG_local (fileQ_FS self, $Cont C_cont, B_str path) {
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    uv_fs_t req;
    B_list res = B_listD_new(0);
    res->length = 0;
    int r = uv_fs_scandir(get_uv_loop(), &req, actStrToCString(path, &fileQ_path_nul_error), 0, NULL);
    if (r < 0) {
        char errmsg[1024] = "Error listing directory: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_dirent_t ent;
    while (uv_fs_scandir_next(&req, &ent) != UV_EOF) {
        wit->$class->append(wit, res, actStrFromCStringCopy(ent.name));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, res);
}

// action def lstat(filename: str) -> FileStat:
$R fileQ_FSD_lstatG_local (fileQ_FS self, $Cont C_cont, B_str filename) {
    uv_fs_t req;
    int r = uv_fs_lstat(get_uv_loop(), &req, actStrToCString(filename, &fileQ_path_nul_error), NULL);
    if (r < 0) {
        char errmsg[1024] = "Error getting file stat: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_stat_t *stat = (uv_stat_t *)req.ptr;
    fileQ_FileStat res = fileQ_FileStatG_new(filename,
                                             (uint64_t)stat->st_dev,
                                             (uint64_t)stat->st_mode,
                                             (uint64_t)stat->st_nlink,
                                             (uint64_t)stat->st_uid,
                                             (uint64_t)stat->st_gid,
                                             (uint64_t)stat->st_rdev,
                                             (uint64_t)stat->st_ino,
                                             (uint64_t)stat->st_size,
                                             (uint64_t)stat->st_blksize,
                                             (uint64_t)stat->st_blocks,
                                             (uint64_t)stat->st_flags,
                                             (uint64_t)stat->st_gen,
                                             stat->st_atim.tv_sec + stat->st_atim.tv_nsec / 1e9,
                                             stat->st_mtim.tv_sec + stat->st_mtim.tv_nsec / 1e9,
                                             stat->st_ctim.tv_sec + stat->st_ctim.tv_nsec / 1e9,
                                             stat->st_birthtim.tv_sec + stat->st_birthtim.tv_nsec / 1e9
                                             );
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, res);
}

// action def rmdir(dirname: str) -> None:
$R fileQ_FSD_rmdirG_local (fileQ_FS self, $Cont C_cont, B_str dirname) {
    uv_fs_t req;
    int r = uv_fs_rmdir(get_uv_loop(), &req, actStrToCString(dirname, &fileQ_path_nul_error), NULL);
    if (r < 0 && r != UV_ENOENT) {
        char errmsg[1024] = "Error removing directory: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, B_None);
}

// action def remove(filename: str) -> None:
$R fileQ_FSD_removeG_local (fileQ_FS self, $Cont C_cont, B_str filename) {
    uv_fs_t req;
    int r = uv_fs_unlink(get_uv_loop(), &req, actStrToCString(filename, &fileQ_path_nul_error), NULL);
    if (r < 0) {
        char errmsg[1024] = "Error removing file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, B_None);
}

// action def rename(src: str, dst: str) -> None:
$R fileQ_FSD_renameG_local (fileQ_FS self, $Cont C_cont, B_str src, B_str dst) {
    uv_fs_t req;
    int r = uv_fs_rename(get_uv_loop(), &req, actStrToCString(src, &fileQ_path_nul_error), actStrToCString(dst, &fileQ_path_nul_error), NULL);
    if (r == UV_ENOENT) {
        uv_fs_req_cleanup(&req);
        RAISE(B_FileNotFoundError, src);
    } else if (r < 0) {
        char errmsg[1024] = "Error renaming file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, B_None);
}

// action def stat(filename: str) -> FileStat:
$R fileQ_FSD_statG_local (fileQ_FS self, $Cont C_cont, B_str filename) {
    uv_fs_t req;
    int r = uv_fs_stat(get_uv_loop(), &req, actStrToCString(filename, &fileQ_path_nul_error), NULL);
    if (r == UV_ENOENT) {
        uv_fs_req_cleanup(&req);
        RAISE(B_FileNotFoundError, filename);
    } else if (r < 0) {
        char errmsg[1024] = "Error getting file stat: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_stat_t *stat = (uv_stat_t *)req.ptr;
    fileQ_FileStat res = fileQ_FileStatG_new(filename,
                                             (uint64_t)stat->st_dev,
                                             (uint64_t)stat->st_mode,
                                             (uint64_t)stat->st_nlink,
                                             (uint64_t)stat->st_uid,
                                             (uint64_t)stat->st_gid,
                                             (uint64_t)stat->st_rdev,
                                             (uint64_t)stat->st_ino,
                                             (uint64_t)stat->st_size,
                                             (uint64_t)stat->st_blksize,
                                             (uint64_t)stat->st_blocks,
                                             (uint64_t)stat->st_flags,
                                             (uint64_t)stat->st_gen,
                                             stat->st_atim.tv_sec + stat->st_atim.tv_nsec / 1e9,
                                             stat->st_mtim.tv_sec + stat->st_mtim.tv_nsec / 1e9,
                                             stat->st_ctim.tv_sec + stat->st_ctim.tv_nsec / 1e9,
                                             stat->st_birthtim.tv_sec + stat->st_birthtim.tv_nsec / 1e9
                                             );
    uv_fs_req_cleanup(&req);
    return $R_CONT(C_cont, res);
}

$R fileQ_FSD_tmpdirG_local (fileQ_FS self, $Cont C_cont) {
    size_t size = 128;
    int r;

    while (1) {
        char *buffer = (char *)acton_malloc(size);
        size_t requested = size;
        r = uv_os_tmpdir(buffer, &requested);
        if (r == UV_ENOBUFS) {
            size = requested;
            continue;
        }
        if (r < 0) {
            char errmsg[1024] = "Error getting temporary directory: ";
            uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
            log_warn(errmsg);
            RAISE(B_OSError, actStrFromCStringCopy(errmsg));
        }
        return $R_CONT(C_cont, actStrFromCString(buffer));
    }
}

$R fileQ_ReadFileD__open_fileG_local (fileQ_ReadFile self, $Cont c$cont) {
    pin_actor_affinity();
    uv_fs_t req;
    int r = uv_fs_open(get_uv_loop(), &req, actStrToCString(self->filename, &fileQ_path_nul_error), UV_FS_O_RDONLY, 0, NULL);
    if (r == UV_ENOENT) {
        uv_fs_req_cleanup(&req);
        RAISE(B_FileNotFoundError, self->filename);
    } else if (r < 0) {
        char errmsg[1024] = "Error opening file for reading: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));

    }
    self->_fd = r;
    uv_fs_req_cleanup(&req);
    return $R_CONT(c$cont, B_None);
}

$R fileQ_ReadFileD__lock_fileG_local (fileQ_ReadFile self, $Cont c$cont) {
#if defined(_WIN32) || defined(_WIN64)
    assert(0 && "fileQ_ReadFileD__lock_fileG_local not implemented on Windows");
#else
    int r = flock(self->_fd, LOCK_EX + LOCK_NB);
    if (r < 0) {
        char errmsg[1024] = "Error locking file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
#endif
    return $R_CONT(c$cont, B_None);
}

$R fileQ_ReadFileD_closeG_local (fileQ_ReadFile self, $Cont c$cont) {
    uv_fs_t req;
    int r = uv_fs_close(get_uv_loop(), &req, (uv_file)self->_fd, NULL);
    if (r < 0) {
        char errmsg[1024] = "Error closing file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(c$cont, B_None);
}

$R fileQ_ReadFileD_readG_local (fileQ_ReadFile self, $Cont c$cont) {
    B_SequenceD_list wit = B_SequenceD_listG_witness;
    uv_fs_t req;
    char buf[1024] = {0};
    uv_buf_t iovec = uv_buf_init(buf, sizeof(buf));
    int r = uv_fs_read(get_uv_loop(), &req, (uv_file)self->_fd, &iovec, 1, -1, NULL);
    B_list res = B_listD_new(0);
    res->length = 0;
    while (r > 0) {
        wit->$class->append(wit, res, actBytesFromCStringLengthCopy(buf,r));
        uv_fs_req_cleanup(&req);
        iovec = uv_buf_init(buf, sizeof(buf));
        r = uv_fs_read(get_uv_loop(), &req, (uv_file)self->_fd, &iovec, 1, -1, NULL);
    }
    if (r < 0) {
        char errmsg[1024] = "Error reading from file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    B_bytes nullb = actBytesFromCStringCopy("");
    B_Iterable wit2 = ((B_Iterable)((B_Collection)B_SequenceD_listG_new()->W_Collection));
    return $R_CONT(c$cont, nullb->$class->join(nullb,wit2,res));
}


$R fileQ_WriteFileD__open_fileG_local (fileQ_WriteFile self, $Cont c$cont) {
    pin_actor_affinity();
    uv_fs_t req;
    int flags = UV_FS_O_RDWR | UV_FS_O_CREAT | (self->append ? UV_FS_O_APPEND : UV_FS_O_TRUNC);
    int r = uv_fs_open(get_uv_loop(), &req, actStrToCString(self->filename, &fileQ_path_nul_error), flags, S_IWUSR|S_IRUSR|S_IRGRP|S_IROTH, NULL);
    if (r < 0) {
        char errmsg[1024] = "Error opening file for writing: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));

    }
    self->_fd = r;
    uv_fs_req_cleanup(&req);
    return $R_CONT(c$cont, B_None);
}

$R fileQ_WriteFileD__lock_fileG_local (fileQ_WriteFile self, $Cont c$cont) {
#if defined(_WIN32) || defined(_WIN64)
    assert(0 && "fileQ_ReadFileD__lock_fileG_local not implemented on Windows");
#else
    int r = flock(self->_fd, LOCK_EX + LOCK_NB);
    if (r < 0) {
        char errmsg[1024] = "Error locking file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
#endif
    return $R_CONT(c$cont, B_None);
}


$R fileQ_WriteFileD_closeG_local (fileQ_WriteFile self, $Cont c$cont) {
    uv_fs_t req;
    int r = uv_fs_close(get_uv_loop(), &req, (uv_file)self->_fd, NULL);
    if (r < 0) {
        char errmsg[1024] = "Error closing file: ";
        uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
        uv_fs_req_cleanup(&req);
        log_warn(errmsg);
        RAISE(B_OSError, actStrFromCStringCopy(errmsg));
    }
    uv_fs_req_cleanup(&req);
    return $R_CONT(c$cont, B_None);
}

$R fileQ_WriteFileD_writeG_local (fileQ_WriteFile self, $Cont c$cont, B_bytes data) {
    uv_fs_t req;
    char *p = (char *)data->str;
    size_t left = data->nbytes;

    // Offset -1 writes at the current position, so each write continues where
    // the previous one ended. A write can write less than asked for, so write
    // until all data is written.
    while (left > 0) {
        uv_buf_t buf = uv_buf_init(p, left);
        int r = uv_fs_write(get_uv_loop(), &req, (uv_file)self->_fd, &buf, 1, -1, NULL);
        uv_fs_req_cleanup(&req);
        if (r < 0) {
            char errmsg[1024] = "Error writing to file: ";
            uv_strerror_r(r, errmsg + strlen(errmsg), sizeof(errmsg)-strlen(errmsg));
            log_warn(errmsg);
            RAISE(B_OSError, actStrFromCStringCopy(errmsg));
        }
        p += r;
        left -= (size_t)r;
    }
    return $R_CONT(c$cont, B_None);
}
